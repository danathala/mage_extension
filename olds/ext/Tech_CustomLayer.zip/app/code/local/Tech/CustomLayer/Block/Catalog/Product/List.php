<?php
class Tech_CustomLayer_Block_Catalog_Product_List extends Mage_Catalog_Block_Product_List
{
}
			