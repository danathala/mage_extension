=== wp comment validation ===
Contributors: ajay3085006
Donate link: https://ajaysharma3085006.wordpress.com/
Tags: comments validation, wordpress comment validation plugin
Requires at least: 3.5
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
wp-comment-validation adds validation for wordpress default comment submission form.


== Description ==

wp-comment-validation can adds custom message for wordpress default comment submission form validation. It is easy to use , just install plugin and validation will be there on the comment submission form on whole site also can be set your own message to display on error just go to  setting page of wp comment validation at left panel in wordpress.


== Installation ==

The plugin can be use just by installing it by wordpress admin or upload manually. 

1. Upload `wp-comment-validation` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. To set custom validation message go to "wp comment validation" in left panel of wordpress. 

== Frequently Asked Questions ==

= How to set custom validation messages ? =

 Go to "wp comment validation" in left panel of wordpress. enter your messages in respective fields.
 and press "Save Changes" button

For more visit blog [wp-comment-validation](https://ajaysharma3085006.wordpress.com/ "wp-comment-validation")



== Screenshots ==

1. User view after installation
2. Admin setting page


== Changelog ==
=0.2=
* Added enable disable for all input seperately

= 0.1 =
* Initial release
* include comment validaion 
* include custom messages


== Upgrade Notice ==

= 0.3 =
for adding more setting options in admin.