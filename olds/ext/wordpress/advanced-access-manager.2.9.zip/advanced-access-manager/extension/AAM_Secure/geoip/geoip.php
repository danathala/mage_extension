<?php
/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
*/

abstract class GeoIP {

    public static function query($ip) {
        
    }

}
