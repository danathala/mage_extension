# WP Plugin Base

Simple wordpress class & structure I use to start all my plugins. Based in WordPress Plugin Boilerplate - https://github.com/tommcfarlin/WordPress-Plugin-Boilerplate/

## Features

* WP Plugin Base use Wordpress settings API
* You can easily create a Settings Page with different sections (displayed in tabs)
* Presupported fields are :heading, paragraph, checkboxs, select, radio, textarea, html, password, button, color, code, sortable, text

This readme is beta, same as plugin that was originally written for Wordpress Social Invitations - http://wp.timersys.com/wordpress-social-invitations/ and I still need to remove some hardcoded code