=== Export/Import custom post and taxonomy type === 

=== Utilities ===
Contributors: Nabajit Roy
Email: nabajitroy@gmail.com
Tags: export import
Requires at least: 3.1
Stable tag: 1.0
Tested up to: 4.1


== Description == 
A must have  tool for Custom Fields and Custom Post Types Creator plugin for exporting/importing custom post types and taxonomies, fast and without any programming knowledge.

== Required  ==
WCK - Custom Fields and Custom Post Types Creator