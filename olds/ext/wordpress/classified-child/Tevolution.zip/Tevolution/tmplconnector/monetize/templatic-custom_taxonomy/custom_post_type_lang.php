<?php
define('CUSTOM_MENU_CAT_LABEL',__('Categories','templatic-admin'));
define('CUSTOM_MENU_CAT_TITLE',__('Categories','templatic-admin'));
define('CUSTOM_MENU_SIGULAR_CAT',__('Category','templatic-admin'));
define('CUSTOM_MENU_CAT_SEARCH',__('Search category','templatic-admin'));
define('CUSTOM_MENU_CAT_POPULAR',__('Popular categories','templatic-admin'));
define('CUSTOM_MENU_CAT_ALL',__('All categories','templatic-admin'));
define('CUSTOM_MENU_CAT_PARENT',__('Parent category','templatic-admin'));
define('CUSTOM_MENU_CAT_PARENT_COL',__('Parent category:','templatic-admin'));
define('CUSTOM_MENU_CAT_EDIT',__('Edit category','templatic-admin'));
define('CUSTOM_MENU_CAT_UPDATE',__('Update category','templatic-admin'));
define('CUSTOM_MENU_CAT_ADDNEW',__('Add new category','templatic-admin'));
define('CUSTOM_MENU_CAT_NEW_NAME',__('New category name','templatic-admin'));
define('CUSTOM_MENU_TAG_LABEL',__('Tags','templatic-admin'));
define('CUSTOM_MENU_TAG_TITLE',__('Tags','templatic-admin'));
define('CUSTOM_MENU_TAG_NAME',__('Tags','templatic-admin'));
define('CUSTOM_MENU_TAG_SEARCH',__('Tags','templatic-admin'));
define('CUSTOM_MENU_TAG_POPULAR',__('Popular tags','templatic-admin'));
define('CUSTOM_MENU_TAG_ALL',__('All tags','templatic-admin'));
define('CUSTOM_MENU_TAG_PARENT',__('Parent tags','templatic-admin'));
define('CUSTOM_MENU_TAG_PARENT_COL',__('Parent tags:','templatic-admin'));
define('CUSTOM_MENU_TAG_EDIT',__('Edit tags','templatic-admin'));
define('CUSTOM_MENU_TAG_UPDATE',__('Update tags','templatic-admin'));
define('CUSTOM_MENU_TAG_ADD_NEW',__('Add new tags','templatic-admin'));
define('CUSTOM_MENU_TAG_NEW_ADD',__('New tag name','templatic-admin'));
define('FLD_REQUIRED_TEXT',__('*','templatic-admin'));

define('GRID_VIEW_TEXT',__('Grid view','templatic-admin'));
define('LIST_VIEW_TEXT',__('List view','templatic-admin'));
?>