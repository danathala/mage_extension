<?php
/**
 * Classified single custom post type template
 *
**/
get_header();
/*do action for display the breadcrumb in between header and container. */
do_action('classified_before_container_breadcrumb'); 
?>
<!-- start content part-->
<div id="content" class="large-9 small-12 columns" role="main"> 

	<?php 
	global $htmlvar_name,$wpdb;
	
	$address=get_post_meta(get_the_ID(),'address',true);
	$website=get_post_meta(get_the_ID(),'website',true);
	$phone=get_post_meta(get_the_ID(),'phone',true);																		
	$email=get_post_meta(get_the_ID(),'email',true);
	
	/* Get heading type to display the custom fields as per selected section.  */
	if(function_exists('tmpl_fetch_heading_post_type')){
	
		$heading_type = tmpl_fetch_heading_post_type(CUSTOM_POST_TYPE_CLASSIFIED);
	}
	
	/* get all the custom fields which select as " Show field on detail page" from back end */
	
	if(function_exists('tmpl_single_page_custom_field')){
		$htmlvar_name = tmpl_single_page_custom_field(CUSTOM_POST_TYPE_CLASSIFIED);
	}else{
		global $htmlvar_name;
	}
	
	
	/* to get the common/context custom fields display by default with current post type */
	if(function_exists('tmpl_single_page_default_custom_field')){
		$tmpl_flds_varname = tmpl_single_page_default_custom_field(CUSTOM_POST_TYPE_CLASSIFIED);
	}

	/*do action for display the breadcrumb  inside the container. */ 
	do_action('classified_inside_container_breadcrumb'); 
	
	/* Loads the sidebar-before-content. */

		if(function_exists('supreme_sidebar_before_content'))
			apply_filters('tmpl_before-content',supreme_sidebar_before_content() ); 
		
		while ( have_posts() ) : the_post(); 
		
		global $post;
     	do_action('classified_before_post_loop'); 
		
	
			  
		?>
        <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>  
          	<?php /* do action for before the post title.*/
			
			do_action('classified_before_post_title');          ?>
          
          	<!-- Title and details start -->
    		<header class="entry-header clearfix">
				<?php do_action('classified_open_entry_header'); ?>
               	<section class="entry-header-title clearfix">
					<div class="entry-header-logo">
						<img src="<?php echo $listing_logo?>" alt="<?php echo $tmpl_flds_varname['listing_logo']['label']; ?>" />
					</div>
					<div class="entry-info">
						<!-- Page Title -->
						<h1 itemprop="name" class="entry-title <?php if($is_edit==1):?>frontend-entry-title <?php endif;?>" <?php if($is_edit==1):?> contenteditable="true"<?php endif;?> >
							<?php do_action('before_title_h1'); the_title(); do_action('after_title_h1');?>
						</h1>	
					</div>
					
					<div class="entry-links-mobile mobile">
					<ul>             		
							<?php if($phone!="" && $tmpl_flds_varname['phone'] || ($is_edit==1 && $tmpl_flds_varname['phone'])):?>
							<li class="phone <?php echo $tmpl_flds_varname['phone']['style_class']; ?>">
								<a href="tel:<?php echo $phone ?>" class="entry-phone frontend_phone listing_custom" <?php if($is_edit==1):?>contenteditable="true" <?php endif;?>><i class="fa fa-phone"></i> <?php echo 'Call';?></a>
							</li>
							<?php endif; 
							
							if(@$email!="" && @$tmpl_flds_varname['email'] || ($is_edit==1 && @$tmpl_flds_varname['email'])):?>
							<li class="email  <?php echo $tmpl_flds_varname['email']['style_class']; ?>">
							<a href="mailto:<?php echo $email; ?>" class="entry-email frontend_email listing_custom" <?php if($is_edit==1):?>contenteditable="true"<?php endif;?>><i class="fa fa-envelope"></i><?php _e('Email',DOMAIN);?></a>
                                                        </li>
							<?php endif; ?>
							

							<?php if($website!="" && $tmpl_flds_varname['website'] || ($is_edit==1)): if(!strstr($website,'http')) $website = 'http://'.$website;?>
							<li class="website <?php echo $tmpl_flds_varname['website']['style_class']; ?>">
								<a target="_blank" id="website" class="frontend_website <?php if($is_edit==1):?>frontend_link<?php endif; ?>" href="<?php echo $website;?>" ><span><i class="fa fa-globe"></i><?php echo $tmpl_flds_varname['website']['label']; ?></span></a>
							</li>
						<?php endif; ?>
							<li class="contact_seller">
								<a id="contact_seller_id" data-reveal-id="contact_seller_div"  href="javascript:void(0);"><span><i class="fa fa-envelope-o"></i><?php _e('Email','classifieds'); ?></span></a>
								<?php contact_seller(); ?>
							</li>
						<?php
							/* Add to fav link for mobile*/
							if(current_theme_supports('tevolution_my_favourites') && ($post->post_status == 'publish' )){
								global $current_user;
								$user_id = $current_user->ID;
								do_action('tmpl_before_addtofav');
								$link.= tmpl_detailpage_favourite_html($user_id,@$post);
								echo $link;
								
							} ?>
					</ul>
					</div> 
					<?php 	do_action('tmpl_classified_info_right'); 
									
							/* call seller details widget above the post */
							$instance = array(
							 'post_type' => array($post_>post_type),
							); 
						  
							/* call the instance search widget */
							the_widget( 'TmplClassifiedSellerDetails', $instance );
						
					?>
                </section>
				

            </header>
            <!-- Title and details end -->

           

			<?php
			/* do action for after the post title.*/
			do_action('classified_after_post_title');  
			
			/* Here to display bedrooms,bathrooms, area buttons  */ 
			do_action('classified_details_display',get_the_ID()); 
			
			?>
			<div class="entry-content">
				   <?php 
					/* do action for before the post content. */
					do_action('classified_before_post_content');     
					/* get the images of classified */
					
					/* to check the image is attached or not */
					if(function_exists('bdw_get_images_plugin'))
					{
						$post_img = bdw_get_images_plugin($post->ID,'large');
					} ?>
					<script type="text/javascript">
					jQuery(function() {
						jQuery('#classified_image_gallery .classified_image a').lightBox();
					});
					</script>
					<!-- Slider and classified informations start -->
					<div class='above-content-tabs slider-wrap clearfix'>
						<?php /* Here it will display the slider */
						do_action('tmpl_classified_info_left'); 
						
						/* Here it will display the slider */
						?>
						
						 
							
					</div>
					<!-- Slider and classified informations end -->
					<?php
						global $post,$htmlvar_name;
						$templatic_settings=get_option('templatic_settings');
						$googlemap_setting=get_option('city_googlemap_setting');
						$post_id = get_the_ID();
						$count_post_id = get_the_ID();
						if(get_post_meta($post_id,'_classified_id',true)){
							$post_id=get_post_meta($post_id,'_classified_id',true);
						}

						$tmpdata = get_option('templatic_settings');	
						$special_offer=get_post_meta($post_id,'proprty_feature',true);
						$facebook=get_post_meta($post_id,'facebook',true);
						$video=get_post_meta($post_id,'video',true);
						$google_plus=get_post_meta($post_id,'google_plus',true);
						$twitter=get_post_meta($post_id,'twitter',true);
						$additional_features=get_post_meta($post_id,'additional_features',true);
						?>
						<dl class="tmpl-accordion" data-accordion>
							<?php
								do_action('dir_before_tabs');
								do_action('dir_start_tabs'); ?>

								
								<dd class="tmpl-accordion-navigation active"><a href="#classified_details" ><?php _e('Info','classifieds');?></a>
									<div id="classified_details" class="content active">
										<?php do_action('show_listing_classified_detail'); ?>
										<!-- Other Property details -->
										<div id="classified_details" class="entry-content">
											<?php do_action('classified_detail_informations'); ?>
											<div id="overview" class="entry-content">
												<?php do_action('templ_post_single_content');       /*do action for single post content */?>
											</div><!-- end .entry-content -->
											<?php 									
											do_action('classified_custom_fields_collection',array('owner_name','post_city_id','price_type','price','classified_tag','google','web_site'));   ?>
										</div>
										<!-- End Property details -->
									</div>
								</dd>
								
								<?php if($video!="" && $tmpl_flds_varname['video'] && $tmpl_flds_varname['video']):?>
								<dd class="tmpl-accordion-navigation active"><a href="#classified_video" ><?php echo $tmpl_flds_varname['video']['label'];?></a>
									<div id="classified_video" class="content active">
										<!--Video Code Start -->
										<?php $embed_video= wp_oembed_get( $video);            
												if($embed_video!=""){
													echo $embed_video;
												}else{
													echo $video;
												}?>
										<!--Video code End -->
									</div>
								</dd>
								<?php endif; ?>
								
								<?php if($templatic_settings['direction_map']=='yes'):?>
								<dd class="tmpl-accordion-navigation"><a href="#direction_map" ><?php _e('Map','classifieds');?></a>
									<div id="direction_map" class="content">
										<!--Map Section Start -->
										<div id="locations_map">
											<?php do_action('classified_single_page_map') ?>
										</div>
										<!--Map Section End -->
									</div>
								</dd>
								<?php endif; 
								/* add action for display before the post comments. */ 
								do_action('tmpl_classified_before_comments'); 
								/* add action for display before the post comments. */ 
								do_action('tmpl_before_comments');
								do_action( 'for_comments' );

								/*Add action for display after the post comments. */
								do_action('tmpl_after_comments');
								do_action('dir_end_mobile_tabs'); ?>
								
						</dl>
						
					<?php	/* do action for after the post content. */
					do_action('classified_after_post_content');     
					
					
					
					/* add action for display the next previous pagination */ 
					do_action('tmpl_single_post_pagination'); ?>
               </div>
               <!--Finish the listing Content -->
              
     			
     		</div>
			<?php
		endwhile;
	wp_reset_query(); 
	
	
	
	do_action( 'after_entry' ); 
	
	
	global $post;
	
    if(function_exists('supreme_sidebar_after_content'))
			apply_filters('tmpl_after-content',supreme_sidebar_after_content()); /* after-content-sidebar use remove filter to don't display it. */ ?>
    
</div><!-- #content -->

<!-- end  content part-->
<?php 
/* Add Gallery Script */
add_action('wp_footer','add_single_slider_script');
function add_single_slider_script()
{
	$post_id = get_the_ID();
	if(get_post_meta($post_id,'_classified_id',true)){
		$post_id=get_post_meta($post_id,'_classified_id',true);
	}
	$slider_more_listing_img = bdw_get_images_plugin($post_id,'tevolution_thumbnail');
	?>
	<script type="text/javascript">
		
		jQuery(function() {
			jQuery('.listing-image a.listing_img').lightBox();
		});

		jQuery(window).load(function()
		{
			jQuery('#silde_gallery').flexslider({
				animation: "slide",
				<?php if(!empty($slider_more_listing_img) && count($slider_more_listing_img)>11):?>
				controlNav: true,
				directionNav: true,
				prevText: '<i class="fa fa-chevron-left"></i>',
				nextText: '<i class="fa fa-chevron-right"></i>',
				<?php 
				else: ?>
				controlNav: false,
				directionNav: false,
				<?php endif; ?>
				animationLoop: false,
				slideshow: false,
				itemWidth: 70,
				itemMargin: 5,
				asNavFor: '#slider'
			  });
			jQuery('#slider').flexslider(
			{
				animation: 'slide',
				slideshow: false,
				direction: "horizontal",
				slideshowSpeed: 7000,
				animationLoop: true,
				startAt: 0,
				smoothHeight: true,
				easing: "swing",
				pauseOnHover: true,
				video: true,
				controlNav: false,
				directionNav: false,
				prevText: '<i class="fa fa-chevron-left"></i>',
				nextText: '<i class="fa fa-chevron-right"></i>',
				start: function(slider)
				{
					jQuery('body').removeClass('loading');
				}
			});
		});
		jQuery(function() {
			jQuery( "#tabs" ).tabs();
		});

		jQuery('#tabs').bind('tabsshow', function(event, ui) {			
					if (ui.panel.id == "locations_map") {	    
						google.maps.event.trigger(Demo.map, 'resize');
						Demo.map.setCenter(Demo.map.center); /* be sure to reset the map center as well*/
						Demo.init();
					}
		});
		jQuery(function() {
			jQuery('#tabs').tabs({
				activate: function(event ,ui){
					/*console.log(event);*/
					var panel=jQuery(".ui-state-active a").attr("href");  
					if(panel=='#locations_map'){
						google.maps.event.trigger(Demo.map, 'resize');
						Demo.map.setCenter(Demo.map.center); /* be sure to reset the map center as well*/
						Demo.init();
					}
				}
			});
		});
	</script>
	<?php
}
get_footer(); ?>