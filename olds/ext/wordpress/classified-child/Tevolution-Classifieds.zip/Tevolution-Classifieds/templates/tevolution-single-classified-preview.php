<?php
/**
 * preview page of classified post type
 *
**/

global $upload_folder_path;
wp_enqueue_script('jquery');
wp_enqueue_script('jquery-ui-tabs');
$current_user = wp_get_current_user();
$cur_post_id = $_REQUEST['cur_post_id'];
$cur_post_type = $_REQUEST['cur_post_type'];
$templatic_settings = get_option('templatic_settings');	
$date_formate=get_option('date_format');
$time_formate=get_option('time_format');

$title=$_REQUEST['post_title'];
$address=$_REQUEST['address'];
$geo_latitude = $_REQUEST['geo_latitude'];
$geo_longitude = $_REQUEST['geo_longitude'];
$map_type =$_REQUEST['map_view'];
$website=$_REQUEST['website'];
$phone=$_REQUEST['phone'];
$listing_logo=$_SESSION['upload_file']['listing_logo'];
$listing_timing=$_REQUEST['listing_timing'];
$email=$_REQUEST['email'];
$special_offer=$_REQUEST['proprty_feature'];
$video=$_REQUEST['video'];
$facebook=$_REQUEST['facebook'];
$google_plus=$_REQUEST['google_plus'];
$twitter=$_REQUEST['twitter'];
$_GET['page']=$_REQUEST['page'] ='preview';
$_SESSION['custom_fields']=$_POST;
global $htmlvar_name,$heading_type,$tmpl_flds_varname;
/* get all the custom fields which select as " Show field on detail page" from back end */

if(function_exists('tmpl_single_page_custom_field')){
	$htmlvar_name = tmpl_single_page_custom_field($cur_post_type);
}else{
	global $htmlvar_name;
}

/* to get the common/context custom fields display by default with current post type */
if(function_exists('tmpl_single_page_default_custom_field')){	
	$tmpl_flds_varname = tmpl_single_page_default_custom_field($cur_post_type);
}
do_action('fetch_classified_preview_field');?>
<!-- start content part-->
<script id="tmpl-foudation" src="<?php echo TEMPL_PLUGIN_URL; ?>js/foundation.min.js"> </script>
<div id="content" class="large-9 small-12 columns singular-classified" role="main"> 
	
	
     <div id="post-<?php the_ID(); ?>" class="classified type-classified classified-type-preview hentry" >       		
      	<?php /* do action for before the post title.*/
			
			do_action('classified_before_post_title');          ?>
          
          	<!-- Title and details start -->
    		<header class="entry-header clearfix">
				<?php do_action('classified_open_entry_header'); ?>
               	<div class="entry-header-title clearfix">
					<div class="entry-header-left">
                    	<div class="spt-left">
							<h1 class="entry-title">
							<?php 
							do_action('before_title_h1');
								echo $title;
							do_action('after_title_h1');
							?>							
							</h1>
							<?php /* Display meta info like categories, date and all */
								do_action('classified_after_title');
							?>
                        </div>
                        <div class="spt-right">
							<?php /*  Display the Post rating */				
							do_action('classified_title_right',get_the_ID()); ?>
                        </div>
                    </div>
					<!-- Show Property type -->
                    <div class="entry-header-right">
                        <?php /* Here to display the classified price */ 
                        do_action('classified_header_right'); ?>
                    </div> 
                </div>
				<?php do_action('classified_close_entry_header'); ?>
            </header>
            <!-- Title and details end -->
			<?php
			/* do action for after the post title.*/
			do_action('classified_after_post_title');  
			
			/* Here to display bedrooms,bathrooms, area buttons  */ 
			do_action('classified_details_display',get_the_ID()); 
			
			?>
			<div class="entry-content">
				   <?php 
					/* do action for before the post content. */
					do_action('classified_before_post_content');     
					/* get the images of classified */
					
					/* to check the image is attached or not */
					if(function_exists('bdw_get_images_plugin'))
					{
						$post_img = bdw_get_images_plugin($post->ID,'large');
					} ?>
					<!-- Slider and classified informations start -->
					<div class='above-content-tabs clearfix'>
						<?php /* Here it will display the slider */
						do_action('tmpl_classified_info_left'); 
						
						/* Here it will display the slider */
						?>
						<?php /* Here it will display the slider */
						do_action('tmpl_classified_info_right'); 
						
						/* Here it will display the classified informations  */
						?>
						 
							
					</div>
					<!-- Slider and classified informations end -->
					<?php
						global $htmlvar_name;						
						$googlemap_setting=get_option('city_googlemap_setting');
						$post_id = get_the_ID();
						$count_post_id = get_the_ID();
						if(get_post_meta($post_id,'_classified_id',true)){
							$post_id=get_post_meta($post_id,'_classified_id',true);
						}
						
						$special_offer=get_post_meta($post_id,'proprty_feature',true);
						$facebook=get_post_meta($post_id,'facebook',true);
						$google_plus=get_post_meta($post_id,'google_plus',true);
						$twitter=get_post_meta($post_id,'twitter',true);
						$additional_features=get_post_meta($post_id,'additional_features',true);
						?>
						
						<ul class="tabs" data-tab role="tablist">
							<?php
							do_action('dir_before_tabs');
							do_action('dir_start_tabs'); ?>
							<li class="tab-title active" role="presentational"><a href="#classified_details"><?php _e('Info','classifieds');?></a></li>
							
							<?php if($video!="" && $tmpl_flds_varname['video'] && $tmpl_flds_varname['video']):?>
							<li class="tab-title" role="presentational"><a href="#classified_video"><?php _e('Video','classifieds');?></a></li>
							<?php endif; ?>

							<?php if($templatic_settings['direction_map']=='yes'):?>
							<li class="tab-title" role="presentational"><a href="#locations_map"><?php _e('Map','classifieds');?></a></li>
							<?php endif; ?>
							
							<?php do_action('dir_end_tabs'); ?>
						</ul>

						<div class="tabs-content">	
							<?php do_action('show_listing_classified_detail'); ?>
								<!-- Other Property details -->
								<section role="tabpanel" aria-hidden="false" class="content active entry-content" id="classified_details">
									<?php do_action('classified_detail_informations'); ?>
									<div id="overview" class="entry-content">
										<?php echo stripslashes($_REQUEST['post_content']);?>
									</div><!-- end .entry-content -->
									<?php 									
									do_action('classified_custom_fields_collection',array('owner_name','post_city_id','price_type','price','classified_tag','google','web_site'));   ?>
								</section>
								<!-- End Property details -->
							<?php if($video!="" && $tmpl_flds_varname['video'] && $tmpl_flds_varname['video']):?>
								<!--Video Code Start -->
								<section role="tabpanel" aria-hidden="false" class="content" id="classified_video">
									<?php echo stripslashes($video);?>
								</section>
								<!--Video code End -->
							<?php endif;
								if($templatic_settings['direction_map']=='yes'):?>
									<!--Map Section Start -->
									<section role="tabpanel" aria-hidden="false" class="content" id="locations_map">
										<div id="classified_location_map" style="width:100%;">
											<div class="classified_location_map" id="classified_location_map_id" style="width:100%;"> 
											<?php
											include_once (TEMPL_MONETIZE_FOLDER_PATH.'templatic-custom_fields/google_map_detail.php');?> 
											</div>  <!-- google map #end -->
										</div>
									</section>
									<!--Map Section End -->
							<?php endif;  ?>
							
						</div>
						
					<?php	/* do action for after the post content. */
					do_action('classified_after_post_content');
					?>
               </div>
               <!--Finish the listing Content -->
              
						
			 <div class="post-meta">  
			  <?php 
			  /* Display selected category and listing tags */
              if(function_exists('directory_post_preview_categories_tags') ){				  
                	echo directory_post_preview_categories_tags($_REQUEST['category'],$_REQUEST['post_tags']);
              } 
			  ?>
			</div>
			
			<div class="classified-page-end clearfix">
				<!-- Property Social Media Coding Start -->
				<?php if(function_exists('tevolution_socialmedia_sharelink')) 
						tevolution_socialmedia_sharelink($post); ?>

				<!-- Property Social Media Coding End -->

				<?php  /* Here to show view counter */
				do_action('classified_after_post_loop'); ?>
			</div>
     </div>
</div>
<!--End content part -->
<script type="text/javascript">
jQuery("ul.tabs li a").live('click',function(){	
	var n=jQuery(this).attr("href")
	if(n=="#locations_map")	{ 
		Demo.init();
	}
 })
</script>