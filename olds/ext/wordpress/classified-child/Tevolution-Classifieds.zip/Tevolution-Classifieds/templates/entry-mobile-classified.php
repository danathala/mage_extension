<?php 
global $post,$htmlvar_name;
do_action('classified_before_post_loop');?>
<article <?php
	if ((get_post_meta($post->ID, 'featured_h', true) == 'h')) {
			  post_class('post featured_post ');
	} else {
			  post_class('post large-4 medium-4 small-6 xsmall-12 columns');
	}
	?>>  
<?php 
	/*do_action before the post image */
	do_action('tmpl_before_category_page_image');           
	do_action('classified_before_category_page_image');           
	
	/* Here to fetch the image */
	do_action('classified_category_page_image');
	
	/*do action after the post image */
	do_action('classified_after_category_page_image'); 
	do_action('tmpl_after_category_page_image');    
	do_action('classified_before_post_entry');?>
	<div class="entry"> 
		   <!--start post type title -->
		   <?php do_action('classified_before_post_title');         /* do action for before the post title.*/ ?>
		   
		   <div class="classified-title">
		   
				<?php /* do action for display the single post title */
				do_action('templ_post_title'); 
				/* do action for display the price */
				do_action('templ_classified_post_title'); 
				?>
		   
		   </div>
		   <?php  /* do action for after the post title.*/
				do_action('classified_after_post_title');  ?>       
		 
			<div class="classified-info">
			<?php
				/*do action for display the post info */ 
			   $address = get_post_meta($post->ID,'address',true);	
			   if($htmlvar_name['address'] && $address !='')
			   {
					do_action('tmpl_before_maddress');
					echo  '<p class="address"><label>'.__('In','classifieds').' </label> '.$address.'</p>' ;
					do_action('tmpl_after_maddress');
				}		
			?>
			</div>
			
			<!-- Start Post Content -->
			<?php
				/* do action for before the post content. */								  
			   do_action('classified_before_post_content');
			   
			   /* do action for after the post content. */
			  
		  ?>
	</div>
	 
</article>
<?php do_action('classified_after_post_loop'); ?>