<?php
global $post,$wp_query,$htmlvar_name;
$wp_query->set('is_ajax_archive',1);
do_action('directory_before_post_loop');
$featured=get_post_meta($post->ID,'featured_c',true);
$classes=($featured=='c')?'featured_c':'';
?>
<div class="post hentry  <?php echo $classes;?>">  
<?php 
    /*do_action before the post image */
    do_action('tmpl_before_category_page_image');           
    do_action('classified_before_category_page_image');           
    
    /* Here to fetch the image */
    do_action('classified_category_page_image');
    
    /*do action after the post image */
    do_action('classified_after_category_page_image'); 
    do_action('tmpl_after_category_page_image');    
    do_action('classified_before_post_entry');?>
    <div class="entry"> 
           <div class="sort-title">
          <?php do_action('classified_before_post_title');         /* do action for before the post title.*/ ?>
          <div class="classified-title">
          <?php /* do action for display the single post title */ do_action('templ_post_title'); ?>
          <div class="show-mobile">
          <?php /* do action for display the price */ do_action('templ_classified_post_title'); ?>
          <?php /* do action for display the date */ do_action('templ_classified_post_date'); ?>
          </div>
                </div>

                <div class="classified-info">
          <?php /*do action for display the post info */ do_action('classified_post_info'); ?>
          </div>

          <!-- Start Post Content -->
          <?php
          /* do action for before the post content. */
          do_action('classified_before_post_content');
          do_action('templ_taxonomy_content');
          /* do action for after the post content. */
          do_action('classified_after_post_content');
          ?>
          <!-- End Post Content -->

          <!-- Show custom fields where show on listing = yes -->
          <?php
          do_action('classified_after_taxonomies');
          /* Here to show the add to favourites,comments and pinpoint  */
          do_action('classified_after_post_entry');
          ?>
          </div>
          <div class="sort-date show-desktop">
          <?php /* do action for display the date */ do_action('templ_classified_post_date'); ?>
          </div>
          <div class="sort-price show-desktop">
          <?php /* do action for display the price */ do_action('templ_classified_post_title'); ?>
          </div>
          <?php  /* do action for after the post title.*/ do_action('classified_after_post_title'); ?>
    </div>
     
</div>
<?php do_action('classified_after_post_loop');
?>