<?php
/*
Plugin Name: Tevolution - Classifieds
Plugin URI: http://templatic.com/
Description: Tevolution - Classified plugin is specially built to turn your site into a powerful classified site.
Version: 1.0.8
Author: Templatic
Author URI: http://templatic.com/
*/
ob_start();
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
define( 'TEVOLUTION_CLASSIFIEDS_VERSION', '1.0.8' );
define('TEVOLUTION_CLASSIFIEDS_SLUG','Tevolution-Classifieds/classifieds.php');
/* Plug in Folder URL*/
define( 'TEVOLUTION_CLASSIFIEDS_URL', plugin_dir_url( __FILE__ ) );
/* Plug in Folder Path */
define( 'TEVOLUTION_CLASSIFIEDS_DIR', plugin_dir_path( __FILE__ ) );
/* Plug-in Root File */
define( 'TEVOLUTION_CLASSIFIEDS_FILE', __FILE__ );
@define( 'TEVOLUTION_CLASSIFIEDS_URL',plugin_dir_url( __FILE__ )  );


/* Load style sheet on front pages */
add_action( 'init', 'tmpl_classifieds_widget_setup' );

add_image_size('adv_detail-main-img',480,480,true);

/* listing page featured thumbnail */
add_image_size('adv_listings-thumb',250,165,true);
/* add_image_size('classified_slider_img_thumb',155,122,true); */



/* Add classifieds css above the directory plugin */
add_action( 'tevolution_css', 'tmpl_add_classifieds_front_stylesheet',14);
			
function tmpl_add_classifieds_front_stylesheet(){

	if ( function_exists('tmpl_wp_is_mobile') &&  !tmpl_wp_is_mobile()) {
		global $tev_css;
			if(!empty($tev_css)){
				$tev_css = array_merge($tev_css,array( plugins_url('css/style.css', __FILE__)));
			}else{
				$tev_css = array( plugins_url('css/style.css', __FILE__));
			}
	}
}

add_action( 'init', 'tmpl_basic_stylesheet',14);

function tmpl_basic_stylesheet(){
	
	if ( !tmpl_wp_is_mobile()){
		
		/* if "allow_url_fopen" is enabled then apply minifiled css otherwise includse seperately */
		$tmpl_is_allow_url_fopen = tmpl_is_allow_url_fopen();
		if(!$tmpl_is_allow_url_fopen){
			wp_enqueue_style( 'tmpl_classified_style', plugins_url('css/style.css', __FILE__) );
		}
		
		/*wp_enqueue_style( 'tmpl_classified_style');	*/
		if(is_single())
		wp_enqueue_style( 'tmpl_classified_print_style', plugins_url('css/print.css', __FILE__) );
	}	
	
}
/* remove header right widget area */
function tmpl_classifieds_widget_setup(){
	$args = array(
	'name'          => __( 'Footer Right', 'classifieds' ),
	'id'            => 'footer_right',
	'description'   => '',
		'class'         => '',
	'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget'  => '</div>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>' );
	register_sidebar($args);
}
/* plug in set up */
if(is_plugin_active('Tevolution/templatic.php'))
{
	/* localization */
	$locale = get_locale();
	
	load_textdomain( 'classifieds', TEVOLUTION_CLASSIFIEDS_DIR.'languages/'.$locale.'.mo' );
	
	/* Include the tevolution plug in main file to use the core functionalities of plug in. */
	if(is_plugin_active('Tevolution/templatic.php') && file_exists(WP_PLUGIN_DIR . '/Tevolution/templatic.php')){
		include_once( WP_PLUGIN_DIR . '/Tevolution/templatic.php');
	}else{
		if(function_exists('dd_admin_notices'))
			add_action('admin_notices','dd_admin_notices');
	}
	/* Bundle Box*/
	if(is_admin() && (isset($_REQUEST['page']) && $_REQUEST['page']=='templatic_system_menu')){
		include(TEVOLUTION_CLASSIFIEDS_DIR."bundle_box.php");	
	}
	
	
	/* file to set up custom post type */
	include_once(TEVOLUTION_CLASSIFIEDS_DIR.'classifieds/classified.php'); 	
	
	/* classifieds widget file */
	include_once(TEVOLUTION_CLASSIFIEDS_DIR.'functions/widgets.php'); 
	
	if((is_admin() && strstr($_SERVER['REQUEST_URI'],'/wp-admin/' )) && !defined('DOING_AJAX')){
		
		/* classifieds filters for search & sorting  */
		
		include_once(TEVOLUTION_CLASSIFIEDS_DIR.'functions/admin_functions.php'); 
	}else{
	
		/* file to set up custom templates and functions */
	
		include_once(TEVOLUTION_CLASSIFIEDS_DIR.'functions/classifieds_functions.php');

		/* file to set up custom templates and functions */
	
		include_once(TEVOLUTION_CLASSIFIEDS_DIR.'functions/classifieds_templates.php'); 
		
		/* classifieds filters for search & sorting  */
		include_once(TEVOLUTION_CLASSIFIEDS_DIR.'functions/classifieds_filters.php'); 
		
		/* classifieds filters for search & sorting  */
		include_once(TEVOLUTION_CLASSIFIEDS_DIR.'functions/classifieds_filters_functions.php');
	
	}
	
}else{
	add_action('admin_notices','tmpl_classifieds_admin_notices');
}
/* Show the notice if tevolution classifieds plug in is not activated. */

function tmpl_classifieds_admin_notices(){
	echo '<div class="error"><p>' . __('You have not activated the base plug in <b>Tevolution</b>. Please activate it to use Tevolution-Classifieds plug in.','classifieds'). '</p></div>';
}
/*action to include sample data file*/
add_action('admin_init','insert_classified_sample_data',20);
function insert_classified_sample_data()
{
	remove_action( 'after_plugin_row_Tevolution-Classifieds/classifieds.php', 'wp_plugin_update_row' ,10, 2 );
	/* file to insert classified listing and set up widget in its sidebar */
	if(is_admin() && (isset($_REQUEST['classified_dummy']) && $_REQUEST['classified_dummy']!='')){
		include(TEVOLUTION_CLASSIFIEDS_DIR."classifieds/classified_auto_install_xml.php");	
	}
}
/* classifieds right widget area */
add_action('before-footer-content','tmpl_classifieds_footer');
/* footer right widget area */
function tmpl_classifieds_footer(){ 
	if(is_active_sidebar('footer_right')){ 
		dynamic_sidebar('footer_right');
	}
}

/* Compatibility with front end editor */

add_filter('frontend_supported_post_type','tmpl_frontend_supported_post_type');

function tmpl_frontend_supported_post_type($post_types){
	
	return array_merge(array('classified'),$post_types);
}

$included_files = get_included_files();

foreach ($included_files as $filename) {
	if(strstr($filename,'Tevolution-Classifieds'))
	{
		/*echo $filename."<br/>";*/
	}
}

register_activation_hook(__FILE__, 'tmpl_classified_plugin_activate');

/* Hook to Insert the options on plugin activation */
function tmpl_classified_plugin_activate(){
	global $wpdb;
	$templatic_settings=get_option('templatic_settings');
	$settings=array('sorting_option' => array('title_alphabetical','date_asc','date_desc','random','rating','reviews','title_asc','title_desc','classifieds_price_low_high','classifieds_price_high_low'),'default_page_view'=>'listview','home_listing_type_value'=>array('classified'));
	
	if(empty($templatic_settings))
	{
		update_option('templatic_settings',$settings);	
	}else{
		update_option('templatic_settings',array_merge($templatic_settings,$settings));
	}
	/* add rule for urls */
	$tevolution_taxonomies_data1 = get_option('tevolution_taxonomies_rules_data');
	$tevolution_taxonomies_data1['tevolution_single_post_add']['classified'] = 'classified';
	update_option('tevolution_taxonomies_rules_data',$tevolution_taxonomies_data1);
	if(function_exists('tevolution_taxonimies_flush_event'))
		tevolution_taxonimies_flush_event();
	/* Delete Tevolution query catch on permalink update  changes */
	$wpdb->query($wpdb->prepare("DELETE FROM $wpdb->options WHERE option_name like '%s'",'%_tevolution_quer_%' ));
	update_option('classified_redirect_activation','Active');
}
/*
 * Plugin Deactivation hook
 */
register_deactivation_hook(__FILE__,'unregister_classified_fields');
function unregister_classified_fields(){
	 $post_type = get_option("templatic_custom_post");
	 $taxonomy = get_option("templatic_custom_taxonomy");
	 $tag = get_option("templatic_custom_tags");
	 $taxonomy_slug = $post_type['classified']['slugs'][0];
	 $tag_slug = $post_type['classified']['slugs'][1];
	 /*unset classified post type and its taxonomy at the time of plugin deactivation*/
	 unset($post_type['classified']);
	 unset($taxonomy[$taxonomy_slug]);
	 unset($tag[$tag_slug]);
	 update_option("templatic_custom_post",$post_type);
	 update_option("templatic_custom_taxonomy",$taxonomy);
	 update_option("templatic_custom_tags",$tag);
	 update_option('tevolution_classifieds','');
	 
	 delete_option('hide_classified_ajax_notification');
	 delete_option('property_custom_fields_insert');
	 delete_option('event_manager_redirect_activation');
	 delete_option('property_location_post_type');
}

/*
 * Update tevolution plugin version after templatic member login
 */
add_action('wp_ajax_classified','classified_update_login');
function classified_update_login()
{
	check_ajax_referer( 'classified', '_ajax_nonce' );
	$plugin_dir = rtrim( plugin_dir_path(__FILE__), '/' );
	require_once( $plugin_dir .  '/templatic_login.php' );
	exit;
}

add_action( 'init', 'classified_register_image_sizes' );
function classified_register_image_sizes(){	
	add_image_size( 'clasified-thumb', 250, 165, true );
}
/*save ad_id while save classified*/
add_action('save_post_classified','save_classified_data');
function save_classified_data($post_id)
{
	if(get_post_meta($post_id,'ad_id',true) == '' || get_post_meta($post_id,'ad_id',true) <= 0)
	{
		update_post_meta($post_id,'ad_id',rand(1000, 9999).$post_id);
	}
}
?>