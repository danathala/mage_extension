<?php

/* ajax request for filter properties */
add_action('wp_ajax_tmpl_filter_classified','tmpl_filter_classified');
add_action('wp_ajax_nopriv_tmpl_filter_classified','tmpl_filter_classified');

/* get city name by id */
add_action('wp_ajax_tmpl_get_classified_city','tmpl_get_classified_city');
add_action('wp_ajax_nopriv_tmpl_get_classified_city','tmpl_get_classified_city');


/* get category name by id */
add_action('wp_ajax_tmpl_get_classified_category_name','tmpl_get_classified_category_name');
add_action('wp_ajax_nopriv_tmpl_get_classified_category_name','tmpl_get_classified_category_name');


/* show classified filter on map */
add_action('wp_ajax_tmpl_filter_locations_map','tmpl_filter_locations_map');
add_action('wp_ajax_nopriv_tmpl_filter_locations_map','tmpl_filter_locations_map');

/*
	Get city name from id to display on clear filters box on top on the content 
*/
function tmpl_get_classified_city()
{
	global $wpdb;
	$multicity_table = $wpdb->prefix . "multicity";	
	$cityinfo = $wpdb->get_results("SELECT * FROM $multicity_table where $multicity_table.city_id = '".$_REQUEST['cid']."' order by cityname ASC");
	echo $cityinfo[0]->cityname;
	exit;
}

/*
	Get category name name from id to display on clear filters box on top on the content 
*/
function tmpl_get_classified_category_name()
{
	echo tmpl_get_classified_category_by_ID($_REQUEST['catid'],'classifiedscategory');
	exit;
}

/*
	To display the filter results on map
*/
function tmpl_filter_locations_map()
{
	global $wp_query,$wpdb,$current_cityinfo,$htmlvar_name;
	if(function_exists('tmpl_get_category_list_customfields')){
		$htmlvar_name = tmpl_get_category_list_customfields(CUSTOM_POST_TYPE_CLASSIFIED);
	}else{
		global $htmlvar_name;
	}
	$posttype = (isset($_REQUEST['posttype']) && $_REQUEST['posttype'] != '') ? $_REQUEST['posttype'] : '';
	 		
	$queried_object = get_queried_object();   /* currently-queried object */
	$term_id = $queried_object->term_id;  

	/*$wp_query->set('post_type', array($posttype));*/
	$per_page=get_option('posts_per_page'); /* post per page */
	
	 /* get page number. if there is no page number then set page number to 1 */
	$paged = (isset($_REQUEST['page_num']) && $_REQUEST['page_num'] != '') ? $_REQUEST['page_num'] : 1;
	
	if(isset($_REQUEST['term_id']) && $_REQUEST['term_id']!=""){  /* if term id exist then show result according to term */
		$taxonomies = get_object_taxonomies( (object) array( 'post_type' => $posttype ,'public'   => true, '_builtin' => true ));	
		$args=array(
				 'post_type'      => $posttype,
				 'posts_per_page' => $per_page,
				 'post_status'    => 'publish',
				 'paged' 		  => $paged,
				 'tax_query'      => array(
										  array(
											 'taxonomy' => $taxonomies[0],
											 'field'    => 'id',
											 'terms'    => explode(',',$_REQUEST['term_id']),
											 'operator' => 'IN'
										  )
									   ),
				);
		
	}else{      /* else show all result */
		$args=array(
				 'post_type'      => $posttype,
				 'posts_per_page' => $per_page,
				 'paged' 		  => $paged,
				 'post_status'    => 'publish',
				 );
	}
	
	if(is_plugin_active('Tevolution-LocationManager/location-manager.php'))
	{
		add_filter('posts_join','tevolution_favourites_post_join',12);
		add_filter('posts_where', 'tmpl_classified_location_multicity_where');
	}
	
	/* When search using search widget/template the filters apply from following hook */ 
	add_filter( 'posts_where' , 'tmpl_search_classified_filter_where'); 
	/* filter for order by  */
	/*add_filter('posts_orderby', 'tmpl_search_filter_orderby',13);*/

	if(is_plugin_active('sitepress-multilingual-cms/sitepress.php')){
		add_filter('posts_where', 'tmpl_search_language');
	}
	

	/* end for remove filter */	
	
	$post_details = new WP_Query($args);	
	
	if(is_plugin_active('sitepress-multilingual-cms/sitepress.php')){
		remove_filter('posts_where', 'tmpl_location_multicity_where');
		remove_filter('posts_join','tevolution_favourites_post_join',12);
	}
	
	
	if ($post_details->have_posts()) :
		while ( $post_details->have_posts() ) : $post_details->the_post();
			$ID =get_the_ID();				
			$title = get_the_title($ID);
			$plink = get_permalink($ID);
			$lat = get_post_meta($ID,'geo_latitude',true);
			$lng = get_post_meta($ID,'geo_longitude',true);					
			$address = stripcslashes(str_replace($srcharr,$replarr,(get_post_meta($ID,'address',true))));
			$contact = str_replace($srcharr,$replarr,(get_post_meta($ID,'phone',true)));
			$website = get_post_meta($ID,'website',true);
			/*Fetch the image for display in map */
			if ( has_post_thumbnail()){
				$post_img = wp_get_attachment_image_src( get_post_thumbnail_id(), 'thumbnail');						
				$post_images=$post_img[0];
			}else{
				$post_img = bdw_get_images_plugin($ID,'thumbnail');					
				$post_images = $post_img[0]['file'];
			}
			
			$imageclass='';
			if($post_images)
				$post_image='<div class=map-item-img><img src='.$post_images.' width=150 height=150/></div>';
			else{
				$post_image='';
				$imageclass='no_map_image';
			}
			
			$taxonomies = get_object_taxonomies( (object) array( 'post_type' => $posttype,'public'   => true, '_builtin' => true ));
			$cat_args = array(
						'taxonomy'=>$taxonomies[0],
						'orderby' => 'name', 				
						'hierarchical' => 'true',
						'title_li'=>''
					);	
			$r = wp_parse_args( $cat_args);	
			$catname_arr=get_categories( $r );
			foreach($catname_arr as $cat)
			{
				
				if(isset($_REQUEST['term_id']) && $_REQUEST['term_id']!="")
				{
					
					if($_REQUEST['term_id'] == $cat->term_id)
					{

						if($cat->term_icon != '')
							$term_icon=$cat->term_icon;
						else
							$term_icon=apply_filters('tmpl_default_map_icon',TEVOLUTION_PAGE_TEMPLATES_URL.'images/pin.png');
								
					}
				}
				else
					{
					    if($cat->term_icon)
							$term_icon=$cat->term_icon;
						else
							$term_icon=apply_filters('tmpl_default_map_icon',TEVOLUTION_PAGE_TEMPLATES_URL.'images/pin.png');
					}
				
				
			}
			
			$image_class=($post_image)?'map-image' :'';
			$comment_count= count(get_comments(array('post_id' => $ID)));
			$review=($comment_count <=1 )? __('review','classifieds'):__('reviews','classifieds');	
			
			if(($lat && $lng )&& !in_array($ID,$pids))
			{ 	
				$retstr ='{';
				$retstr .= '"name":"'.$title.'",';
				$retstr .= '"location": ['.$lat.','.$lng.'],';
				$retstr .= '"message":"<div class=\"google-map-info '.$image_class.'\"><div class=map-inner-wrapper><div class=\"map-item-info '.$imageclass.'\">'.$post_image;
				$retstr .= '<h6><a href='.$plink.' class=ptitle><span>'.$title.'</span></a></h6>';							
				if($address){$retstr .= '<p class=address>'.$address.'</p>';}
				if($contact){$retstr .= '<p class=contact>'.$contact.'</p>';}
				if($website){$retstr .= '<p class=website><a href= '.$website.'>'.$website.'</a></p>';}
				if($templatic_settings['templatin_rating']=='yes'){
					$rating=draw_rating_star_plugin(get_post_average_rating(get_the_ID()));
					$retstr .= '<div class=map_rating>'.str_replace('"','',$rating).' <span><a href='.$plink.'#comments>'.$comment_count.' '.$review.'</a></span></div>';
				}else{
					$retstr .= apply_filters('show_map_multi_rating',get_the_ID(),$plink,$comment_count,$review);
				}
				$retstr .= '</div></div></div>';
				$retstr .= '",';
				$retstr .= '"icons":"'.$term_icon.'",';
				$retstr .= '"pid":"'.$ID.'"';
				$retstr .= '}';
				$content_data[] = $retstr;
				$j++;
			}	
			
			$pids[]=$ID;
		endwhile;
		wp_reset_query();	
		
	endif;
	if($content_data)	
		$catinfo_arr= '{"markers":['.implode(',',$content_data)."]}";
				
	if($content_data)
	{		
		echo $catinfo_arr;
	}else
	{
		echo '{"markers":[]}';
	}
	exit;
}

/*
	get the results after filter 
*/
function tmpl_filter_classified()
{
	global $wp_query,$wpdb,$current_cityinfo,$wp_query,$htmlvar_name;
	if(function_exists('tmpl_get_category_list_customfields')){
		$htmlvar_name = tmpl_get_category_list_customfields(CUSTOM_POST_TYPE_CLASSIFIED);
	}else{
		global $htmlvar_name;
	}
	$posttype = (isset($_REQUEST['posttype']) && $_REQUEST['posttype'] != '') ? $_REQUEST['posttype'] : '';
	 		
	$queried_object = get_queried_object();   /* currently-queried object */
	$term_id = $queried_object->term_id;  

	$per_page=get_option('posts_per_page'); /* post per page */
	
	 /* get page number. if there is no page number then set page number to 1 */
	$paged = (isset($_REQUEST['page_num']) && $_REQUEST['page_num'] != '') ? $_REQUEST['page_num'] : 1;
	
	 /* get page number. if there is no page number then set page number to 1 */
	$paged = (isset($_REQUEST['page_num']) && $_REQUEST['page_num'] != '') ? $_REQUEST['page_num'] : 1;
	if(isset($_REQUEST['term_id']) && $_REQUEST['term_id']!="" && !isset($_REQUEST['is_tag']) && !$_REQUEST['is_tag']){  
		/* if term id exist then show result according to term */
		$taxonomies = get_object_taxonomies( (object) array( 'post_type' => $posttype ,'public'   => true, '_builtin' => true ));	
		$args=array(
				 'post_type'      => $posttype,
				 'posts_per_page' => $per_page,
				 'post_status'    => 'publish',
				 'paged' 		  => $paged,
				 'tax_query'      => array(
										  array(
											 'taxonomy' => $taxonomies[0],
											 'field'    => 'id',
											 'terms'    => explode(',',$_REQUEST['term_id']),
											 'operator' => 'IN'
										  )
									   ),
				);
		
	}elseif(isset($_REQUEST['term_id']) && $_REQUEST['term_id']!="" && isset($_REQUEST['is_tag']) && $_REQUEST['is_tag'] == 1){  
		/* if term id exist then show result according to term */
		$taxonomies = get_object_taxonomies( (object) array( 'post_type' => $posttype ,'public'   => true, '_builtin' => true ));	
		$args=array(
				 'post_type'      => $posttype,
				 'posts_per_page' => $per_page,
				 'post_status'    => 'publish',
				 'paged' 		  => $paged,
				 'tax_query'      => array(
										  array(
											 'taxonomy' => $taxonomies[1],
											 'field'    => 'id',
											 'terms'    => explode(',',$_REQUEST['term_id']),
											 'operator' => 'IN'
										  )
									   ),
				);
		
	}else{      /* else show all result */
		$args=array(
				 'post_type'      => $posttype,
				 'posts_per_page' => $per_page,
				 'paged' 		  => $paged,
				 'post_status'    => 'publish',
				 );
	}
	
	if(is_plugin_active('Tevolution-LocationManager/location-manager.php'))
	{
		add_filter('posts_join','tevolution_favourites_post_join',12);
		add_filter('posts_where', 'tmpl_classified_location_multicity_where');
	}
	
	/* When search using search widget/template the filters apply from following hook */ 
	add_filter( 'posts_where' , 'tmpl_search_classified_filter_where'); 
	/* filter for order by  */
	add_filter('posts_orderby', 'tmpl_classified_manager_filter_orderby',15);

	if(is_plugin_active('sitepress-multilingual-cms/sitepress.php')){
		add_filter('posts_where', 'tmpl_search_language');
	}
	

	/* end for remove filter */	
	
	$post_details = new WP_Query($args);	
	$post_details->request;
	
	if(is_plugin_active('sitepress-multilingual-cms/sitepress.php')){
		remove_filter('posts_where', 'tmpl_location_multicity_where');
		remove_filter('posts_join','tevolution_favourites_post_join',12);
	}
	
	
	if ($post_details->have_posts()){
		
		while ( $post_details->have_posts() ) : $post_details->the_post();
		
			/* 
			   loads template part for search result - loads template if it is available in theme otherwise it loads the template from perticuler plugins.
			   And template name should be "content-{your-posttype}.php"
			*/
			
			if(function_exists('tmpl_wp_is_mobile') && tmpl_wp_is_mobile()){
				if (locate_template('entry-mobile-' . $posttype . '.php') != ''){
					get_template_part('entry-mobile', $posttype);
				}else{
					do_action('get_template_part_tevolution-search','entry-mobile',$posttype);
				}
			}else{
				if (locate_template('entry-' . $posttype . '.php') != ''){
					get_template_part('entry', $posttype);
				}else{
					do_action('get_template_part_tevolution-search','entry',$posttype);
				}
			}
			
		endwhile;
		wp_reset_query();
	}else{ /* No results found */ ?>
        <p class='nodata_msg'><?php _e( 'Apologies, but no results were found for the requested archive.', 'classifieds' ); ?></p> <?php
		/* No results found */
	}
	
	if($post_details->max_num_pages !=1):
	?>
     <div id="listpagi">
          <div class="pagination pagination-position">
                <?php 
				wp_reset_query();
                $big = 999999999;
				
					echo paginate_links( array(
							'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
							'format' => '/page/%#%',
							'current' => max( 1, $paged ),
							'total' => $post_details->max_num_pages,
							'before_page_number' => '<strong>',
							'after_page_number' => '</strong>',
							'prev_text'    => '<strong>'.__('Previous','classifieds').'</strong>',
							'next_text'    => '<strong>'.__('Next','classifieds').'</strong>',
							'type'         => 'plain',
						) );
                ?>
          </div>
     </div>
     <?php endif;
	
	exit;

}


/*	filter properties by search options */
function tmpl_search_classified_filter_where($where)
{
	global $wpdb;
	$posttype = $_REQUEST['posttype'];
	
	if(isset($_POST))
	{
		$qry = "select p.ID from $wpdb->postmeta pm ,$wpdb->posts p where p.ID = pm.post_id AND  p.post_status = 'publish' AND p.post_type IN ('$posttype')";
			
			foreach($_POST as  $key=>$value){
				if($value != '' && !empty($value))
				{
					if($key != 'action' && $key != 'posttype' && $key != 'pagetype' && $key != 'classified_type' && $key != 'price' && $key != 'term_id' && $key != 'pcity_name' && $key != 'post_city_id' && $key != 'pcat_name' && $key != 'page_num' && $key != 'device'&& $key != 'sortby' && $key != 'alpha_sort' && $key != 'csortby' && $key != 'price' && $key != 'cprice' && $key != 'class_price')
					{
						echo $key;
						if($key == 'classified_tag' && $key != 'cprice')
						{
							$value = str_replace(",","','",implode(',',$value));
							if(!empty($value))
								$qry .= " AND ( p.ID in (select pm.post_id from $wpdb->postmeta pm where pm.meta_key='$key' and (pm.meta_value IN ('$value') )))";
						}elseif($key == 'price_type'){
	
							if(!empty($value) && is_array($value)){
								$value = str_replace(",","','",implode(',',$value));
							}
							$qry .= " AND ( p.ID in (select pm.post_id from $wpdb->postmeta pm where pm.meta_key='$key' and (pm.meta_value IN ('$value') )))";
						}else
						{
							$qry .= " AND ( p.ID in (select pm.post_id from $wpdb->postmeta pm where pm.meta_key='$key' and (pm.meta_value = \"$value\" )))";
						}
						
					}
					if($key == 'post_city_id' && @$_REQUEST['zones_id'] == ''){
						$qry .= " AND p.ID in (select pm.post_id from $wpdb->postmeta pm where pm.meta_key ='post_city_id' and FIND_IN_SET( ".$value.", pm.meta_value ))";
					}elseif($key == 'post_city_id' && @$_REQUEST['zones_id'] != ''){
						$qry .= " AND (p.ID in (select pm.post_id from $wpdb->postmeta pm where pm.meta_key ='post_city_id' and FIND_IN_SET( ".$value.", pm.meta_value )) OR p.ID in (select pm.post_id from $wpdb->postmeta pm where pm.meta_key ='zone_id' and FIND_IN_SET( ".$_REQUEST['zones_id'].", pm.meta_value )))";
					}
					elseif($key == 'zones_id')
					{
						$qry .= " AND ( p.ID in (select pm.post_id from $wpdb->postmeta pm where pm.meta_key='$key' and (pm.meta_value = \"$value\" )))";
					}
					
				}
			}
			
		$qry .= " GROUP BY p.ID";

		$fquery = $wpdb->get_col($qry);
		
		$all_srch_filter_arr = $fquery;
		
	}
	if((isset($_REQUEST['class_price']) && $_REQUEST['class_price'] == 1) && (isset($_REQUEST['price']) && $_REQUEST['price'] != ''))
	{
		$value = explode('-',$_REQUEST['price']);
		$price_low = trim($value[0]);
		$price_high = trim($value[1]);
		$price_classified = $wpdb->get_col("select pm.post_id from $wpdb->postmeta pm where pm.meta_key='price' and pm.meta_value BETWEEN $price_low+0 AND $price_high+0 ");
		$all_srch_filter_arr = array_intersect($price_classified,$all_srch_filter_arr);
	}

	
	/* filter by post categories and return array of post id results */
	if((isset($_REQUEST['classified_type']) && $_REQUEST['classified_type'] != '' && !empty($_REQUEST['classified_type'])) || (isset($_REQUEST['term_id']) && $_REQUEST['term_id'] != '')) 
	{	
		global $wp_query;
		
		if(isset($_REQUEST['classified_type']) && $_REQUEST['classified_type'] != '')
			$scat = $_REQUEST['classified_type'];
		else
		    $scat = $_REQUEST['term_id'];  	
		
		if(is_tax() || $_REQUEST['term_id']){
			$scat1 = $_REQUEST['term_id'];
			$taxonomy_names = get_object_taxonomies( CUSTOM_POST_TYPE_CLASSIFIED );
				if(isset($_REQUEST['is_tag']) && $_REQUEST['is_tag'] ==1){
					$subcategories = get_categories('&child_of='.$scat1.'&hide_empty=0&type='.CUSTOM_POST_TYPE_CLASSIFIED.'&taxonomy='.$taxonomy_names[1]); 
				}else{
					$subcategories = get_categories('&child_of='.$scat1.'&hide_empty=0&type='.CUSTOM_POST_TYPE_CLASSIFIED.'&taxonomy='.$taxonomy_names[0]); 
				}
				foreach ($subcategories as $subcategory) {
				  $subscat[] = $subcategory->term_id;
				}
			if( count($subscat)> 0)	
				$scat = implode(',',$subscat).','.$scat1;	
			else
				$scat = $scat1;	
		}
		if(is_search() || is_archive())
		{
			$scat = $_REQUEST['classified_type'];
		}	
		
		
		$cats = $wpdb->get_col("select tr.object_id from $wpdb->terms c,$wpdb->term_taxonomy tt,$wpdb->term_relationships tr,$wpdb->posts p where c.term_id=tt.term_id and c.term_id IN ($scat) and  tt.term_taxonomy_id=tr.term_taxonomy_id and tr.object_id=p.ID and p.post_status = 'publish' and p.post_type IN ('".$posttype."') group by  p.ID");
	
		 /* get the resulted id */
		 if(!empty($cats)){
			$all_srch_filter_arr = array_intersect($cats,$all_srch_filter_arr);	
		
		 }else{
			$all_srch_filter_arr = $all_srch_filter_arr;
		 }
		 
		

	}
	/* sort by alphabets */
	if(isset($_REQUEST['alpha_sort']) && $_REQUEST['alpha_sort'] != '' && $_REQUEST['alpha_sort'] != 'undefined' && $_REQUEST['alpha_sort'] != 'All')
	{
			$where .= "  AND $wpdb->posts.post_title like '".$_REQUEST['alpha_sort']."%'";
	}
	/* arrange keys of resulted array */
	$final_srch_arr = array_values($all_srch_filter_arr);
	$final_srch_ids = implode(',',$final_srch_arr);

	/*  Execute where only if array is not empty */
	if(!empty($final_srch_ids))
		$where .= " AND ($wpdb->posts.ID in ($final_srch_ids))";
	else
		$where .= " AND ($wpdb->posts.ID in ('0'))";	/* if empty then set result post id to zero */
	

	/* if Search from current city is enable then filter within a default city */	
	$post_types1 = array();
	foreach(get_option('location_post_type') as $post_types){
		$posttypes = explode(',',$post_types);
		$post_types1[] = $posttypes[0];
	}

	if(is_plugin_active('Tevolution-LocationManager/location-manager.php') && in_array('classified',$post_types1) && (empty($_REQUEST['post_city_id']) && empty($_REQUEST['zones_id'])) && !empty($final_srch_ids) && !empty($_SESSION['post_city_id'])){
		$where .= " AND $wpdb->posts.ID in (select pm.post_id from $wpdb->postmeta pm where pm.meta_key ='post_city_id' and FIND_IN_SET( ".$_SESSION['post_city_id'].", pm.meta_value ))";	
	}
	
	
	return $where;	
}

/*	find from current city  */
function tmpl_classified_location_multicity_where($where){
	global $wpdb,$country_table,$zones_table,$multicity_table,$city_log_table,$current_cityinfo,$wp_query;	
	$city_slug=get_option('location_multicity_slug');	
	$multi_city=($city_slug)? $city_slug : 'city';
	/* latest post -page start */
	if(is_home() ){
		if(strstr($_SERVER['REQUEST_URI'],'/'.$multi_city.'/')){
			$current_city = explode('/'.$multi_city.'/',$_SERVER['REQUEST_URI']);	
	
			if(strstr($current_city[1],'/')){
				$current_city = explode('/',$current_city[1]);
				$current_city = str_replace('/','',$current_city[0]);
			}else{
				$current_city = str_replace('/','',$current_city[1]);
			}
			$wp_query->set('city',$current_city);				
		}
		$multicity_table = $wpdb->prefix . "multicity";	
		if($wpdb->get_var("SHOW TABLES LIKE '$multicity_table'") == $multicity_table) {
			if(strstr($_SERVER['REQUEST_URI'],'/'.$multi_city.'/')){			
				$sql="SELECT * FROM $multicity_table where city_slug='".get_query_var('city')."'";
			}elseif(isset($_SESSION['post_city_id']) && $_SESSION['post_city_id']!=''){
				if(get_query_var('city')!='')
					$sql=$wpdb->prepare("SELECT * FROM $multicity_table where city_slug=%s",get_query_var('city'));
				else
					$sql=$wpdb->prepare("SELECT * FROM $multicity_table where city_id=%d",$_SESSION['post_city_id']);
				
			}else{			
				$sql="SELECT * FROM $multicity_table where is_default=1";		
			}
		}
		$default_city = $wpdb->get_results($sql);
		$default_city_id=$default_city[0]->city_id;
		
		$where .= " AND $wpdb->posts.ID in (select pm.post_id from $wpdb->postmeta pm where pm.meta_key ='post_city_id' and FIND_IN_SET( ".$default_city_id.", pm.meta_value ))";
	/* latest post -page end */
	}else{ 
		if($current_cityinfo['city_id']!='' && $current_cityinfo['city_id']!=0){		
			$where .= " AND $wpdb->posts.ID in (select pm.post_id from $wpdb->postmeta pm where pm.meta_key ='post_city_id' and FIND_IN_SET( ".$current_cityinfo['city_id'].", pm.meta_value ))";
		} 
		if(isset($_REQUEST['radius']) && $_REQUEST['radius'] !=''){
		
		}
	}
	
	return $where;
}

/* add filter block below title */
add_action('classified_after_subcategory','add_classified_filters',1);
function add_classified_filters()
{
	echo '<div id="CselectedFilters" class="filter-options cfilter_list_wrap filter_list_wrap clearfix">';
		echo '<div class="flit-opt-cols1">';
			echo '<a class="clear-filter-link" id="cclear_filter" href="javascript:void(0)">';
			_e('Clear All Filters','classifieds');
			echo '</a>';
		echo '</div>';
	echo '</div>';
}
/* 
	to get the category name form  category id , pass the taxonomy and category id in argument
*/
function tmpl_get_classified_category_by_ID( $cat_ID,$texonomy ) {
      $cat_ID = (int) $cat_ID;
      $category = get_term( $cat_ID, $texonomy );
	
	        if ( is_wp_error( $category ) )
               return $category;

	        return ( $category ) ? $category->name : '';
}
?>