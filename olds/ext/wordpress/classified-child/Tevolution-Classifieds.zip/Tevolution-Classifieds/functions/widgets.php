<?php 
/* Classified widgets */
add_action('widgets_init','tmpl_register_classified_widgets');

function tmpl_register_classified_widgets(){
	register_widget( 'TmplClassifiedFilters_Widget');
	register_widget( 'TmplClassifiedSellerDetails');
	register_widget( 'TmplClassifiedRelatedList');
	register_widget( 'TmplClassifiedPopularList');
	
}

/* Script to pass default values when no values pass in search fields */
function tmpl_classified_search_script(){ ?>
	<script type="text/javascript">
		jQuery(function(){
			var pickerOpts = {						
				showOn: "both",
				dateFormat: 'yy-mm-dd',
				buttonText: '<i class="fa fa-calendar"></i>',
				monthNames: objectL11tmpl.monthNames,
				monthNamesShort: objectL11tmpl.monthNamesShort,
				dayNames: objectL11tmpl.dayNames,
				dayNamesShort: objectL11tmpl.dayNamesShort,
				dayNamesMin: objectL11tmpl.dayNamesMin,
				isRTL: objectL11tmpl.isRTL,
			};	
			jQuery("#sdate").datepicker(pickerOpts);
		});
	</script>
<?php	}



/* Classified related listing widget start */
class TmplClassifiedRelatedList extends WP_Widget {
	function TmplClassifiedRelatedList() {
	
		$widget_ops = array('classname' => 'widget tmpl-classified-related', 'description' => __('Related Classifeids for detail page sidebar.','classifieds') );		
		$this->WP_Widget('TmplClassifiedRelatedList', __('T &rarr; Similar Classifeids','classifieds'), $widget_ops);
	}
	function widget($args, $instance) {
		global $wp_locale;
		extract($args, EXTR_SKIP);
		$title = apply_filters('widget_title', $instance['title']);
		$desc1 = empty($instance['desc1']) ? '' : apply_filters('widget_desc1', $instance['desc1']);

		global $post;
		if(is_single())
		{
			echo $before_widget;
			/*add action for display the related post list. */
			echo "<h3>"; echo $title; echo "</h3>";
			echo "<section id='loop_classified_taxonomy' class='loop_classified_taxonomy'>";
				do_action('tmpl_related_classified');
			echo "</section>"; 
			echo $after_widget;
		}
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;		
		$instance['title'] = strip_tags($new_instance['title']);
		return $instance;
	}
	function form($instance) {
		/* widget form in back end */
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 't1' => '', 't2' => '', 't3' => '',  'img1' => '', 'desc1' => '' ) );		
		$title = (strip_tags($instance['title'])) ? strip_tags($instance['title']) : __("Classified Search",'classifieds'); 
		
		?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title','classifieds'); ?>: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></label></p>
<?php
	}
}
/* Classified search widget end*/

/*
	Classified Filters Widget
*/
class TmplClassifiedFilters_Widget extends WP_Widget {
	
	/*
	 * Register widget with WordPress.
	 */	
	function __construct() {
		$widget_ops = array('classname' => 'tmpl_search_classified', 'description' => __('Search Classified by filter','classifieds') );
		$this->WP_Widget('TmplClassifiedFilters_Widget', __('T &rarr; Classified Filters','classifieds'), $widget_ops);
	}
	
	/**
	 * Front-end display of widget.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		global $wpdb,$country_table,$zones_table,$multicity_table,$current_cityinfo;
		$post_type = CUSTOM_POST_TYPE_CLASSIFIED;
		$currency = get_option('currency_symbol');
		$taxonomies = get_object_taxonomies( (object) array( 'post_type' => $post_type,'public'   => true, '_builtin' => true ));
		$min_price = (empty($instance['min_price']) && $instance['min_price']=='')?5000:$instance['min_price'];
		$max_price = empty($instance['max_price'])?555000:$instance['max_price'];
		$max_price = intval(preg_replace("/[^0-9]/", "",$max_price)) ;
		$min_price = intval(preg_replace("/[^0-9]/", "",$min_price)) ;
		$replace = array(' ','.');
		$replace_with = array('','');
		/* tables for countries, states and cities */
		$country_table = $wpdb->prefix."countries";
		$zones_table =$wpdb->prefix . "zones";	
		$multicity_table = $wpdb->prefix . "multicity";	
		$tsetting = get_option('directory_theme_settings');
		
		if(function_exists('location_current_multicity')){
			location_current_multicity(); /* Set the multicity info*/	
		}
		
		wp_enqueue_script("jquery-ui-slider");  
		/* get id of current city, state and country  */
		$default_country_id = $current_cityinfo['country_id'];
		$default_zone_id = $current_cityinfo['zones_id'];
		$default_city_id = $current_cityinfo['city_id'];
		$query_string = '';
		
		/* get page type */
		if(is_tax()){
		$page_type='taxonomy';
		$queried_object = get_queried_object();   
		$term_id = $queried_object->term_id; 
		$query_string .='&term_id='.$term_id; 
		}else{
			$page_type='archive';
		}
		if(function_exists('tmpl_wp_is_mobile') && tmpl_wp_is_mobile())
		{
			$query_string .='&device=mobile';
		}
		$list_id = 'loop_classified_taxonomy';
	
	if(is_plugin_active('Tevolution-LocationManager/location-manager.php')){
		/* to show the city only which contain the posts - no blank city */
		$city_ids=$wpdb->get_results("SELECT GROUP_CONCAT(distinct meta_value) as city_ids from {$wpdb->prefix}postmeta where `meta_key` ='post_city_id' group by {$wpdb->prefix}postmeta.post_id");
		if($city_ids[0]->city_ids){
			foreach($city_ids as $ids){
				$cityids.=$ids->city_ids.",";
			}
			$cityids=str_replace(",","','",substr($cityids,0,-1));
			$countryinfo = $wpdb->get_results("SELECT  distinct  c.country_id,c.country_name,GROUP_CONCAT(mc.cityname) as cityname, GROUP_CONCAT(mc.city_slug) as city_slug   FROM $country_table c,$multicity_table mc where mc.city_id in('$cityids') AND c.`country_id`=mc.`country_id`  AND c.is_enable=1 group by country_name order by country_name ASC");			
		}
		
		/* get the option for how City Selection Area/Widget Shows */
		$location_options = get_option('location_options');
		
		if($location_options  == 'location_for_cities'){
			/* if only state/city/country option selected  */
				$cityinfo = $wpdb->get_results("SELECT * FROM $multicity_table where $multicity_table.city_id in('$cityids') order by cityname ASC");
		}else{ 
			/* if default locations option selected */
			if($location_options =='location_for_country'){
				$default_country_id = get_option('directory_country_id');
			}
			if($default_country_id)
				$zoneinfo = $wpdb->get_results($wpdb->prepare("SELECT distinct z.zones_id,z.* FROM $zones_table z, $multicity_table mc where z.zones_id=mc.zones_id AND mc.country_id=%d  order by zone_name ASC",$default_country_id));
			if($default_zone_id  && $default_country_id)
				$cityinfo = $wpdb->get_results($wpdb->prepare("SELECT * FROM $multicity_table where zones_id=%d AND country_id=%d AND $multicity_table.city_id in('$cityids') order by cityname ASC",$default_zone_id,$default_country_id));
		}
	}
	global $wp_query;

		if((is_archive() || is_tax() || is_search()) && !is_author() && !is_home()){
		
		echo $args['before_widget']; /* widget start */
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		/* widget title */
		echo $args['before_title'].$title.$args['after_title'];

		?>
		<!-- form for find classified start -->
		<form name="tmpl_find_classified" method="post" action="<?php echo site_url();?>" id="tmpl_find_classified" class="tmpl_filter_results">
		<input type="hidden" name="posttype" value="<?php echo $post_type;?>"/>
		<input type="hidden" name="pagetype" value="<?php echo $page_type;?>"/>
		<input type="hidden" name="csortby" value="" id="csortby"/>
		<ul class="horizontal_location_nav">
					
		
			<div class="search_range">
			<h4><?php _e('Price','classifieds');?></h4>			
			<input type="hidden" name="price" id="cprice_range" value="<?php echo $min_price; ?> - <?php echo $max_price; ?>"/>

			<?php if($tsetting['rtlcss'] == 1 || is_rtl()): ?>
				<input type="text" name="cprice" id="classified_price_range" value="<?php echo display_amount_with_currency_plugin($max_price); ?>-<?php echo display_amount_with_currency_plugin($min_price); ?>" style="border: 0px none;"  readonly="readonly"/>			
			<?php else: ?>
				<input type="text" name="cprice" id="classified_price_range" value="<?php echo display_amount_with_currency_plugin($min_price); ?>-<?php echo display_amount_with_currency_plugin($max_price); ?>" style="border: 0px none;"  readonly="readonly"/>
			<?php endif; ?>	
			</div>
			<div id="classified-price-range"></div> <!-- division for range slider -->
			<?php 
			
			if(is_plugin_active('Tevolution-LocationManager/location-manager.php'))
			{
			?>
			<h4><?php _e('Location','classifieds');?></h4>
			<?php  if($location_options  == 'location_for_cities'){ 
				/* if only state/city/country option selected  - show all cities */
			?>
				<li>
				 
					   <select name="post_city_id" id="widget_classified_city" filterdisplayname="<?php _e('City','classifieds');?>">
						   <option value=""><?php _e('All Cities','classifieds');?></option>
						   <?php 
						   foreach($cityinfo as $city): 
						   $selected=($city->city_id ==$default_city_id)? '':'';
						   $cityname=$city->cityname;
						   if (function_exists('icl_register_string')) {									
									$city_slug = str_replace(' ','-',strtolower($country_name));
									$country_name = icl_t('location-manager', 'location_country_'.$city_slug ,$country_name);
								
						   }
						   ?>
						   <option value="<?php echo $city->city_id?>" <?php echo $selected;?>><?php echo $cityname ;?></option>
					       <?php endforeach;?>
					   </select>
				 
				</li>

			<?php 
			}
			elseif($location_options =='location_for_country'){ 
			/* if only state/city/country option selected  - fetch all states of selected country and show all cities */
			?>
			  <li>
				  <select name="zones_id" id="widget_classified_zone" filterdisplayname="<?php _e('State','classifieds');?>">
					   <option value=""><?php _e('All Regions','classifieds');?></option>
					   <?php foreach($zoneinfo as $zone): $selected=($zone->zones_id ==$default_zone_id)? '':'';
				       $zone_name=$zone->zone_name;
					   if (function_exists('icl_register_string')) {									
								icl_register_string('location-manager', 'location_zone_'.$zone->zones_id,$zone_name);
								$zone_name = icl_t('location-manager', 'location_zone_'.$zone->zones_id,$zone_name);
						  }	
					   ?>
					   <option value="<?php echo $zone->zones_id?>" <?php echo $selected;?>><?php echo $zone_name;?></option>
				       <?php endforeach;?>
				  </select>
			 </li>
			 <li>
				 
					   <select name="post_city_id" id="widget_classified_city" filterdisplayname="<?php _e('City','classifieds');?>">
							<option value=""><?php _e('All Cities','classifieds');?></option>
					        <?php 
					        foreach($cityinfo as $city): $selected=($city->city_id ==$default_city_id)? '':'';
					        $cityname=$city->cityname;
							if (function_exists('icl_register_string')) {									
										$city_slug = str_replace(' ','-',strtolower($country_name));
										$country_name = icl_t('location-manager', 'location_country_'.$city_slug ,$country_name);	
							}
				            ?>
							<option value="<?php echo $city->city_id?>" <?php echo $selected;?>><?php echo $cityname ;?></option>
					   <?php endforeach;?>
					   </select>
				 
			 </li>	
			
			<?php }
			else{ 
			/* if global option selected  - fetch country then state then city */
			?>
			 <li>
				  <select name="country_id" id="widget_classified_country" filterdisplayname="<?php _e('Country','classifieds');?>">
					   <option value=""><?php _e('Select Country','classifieds');?></option>
				       <?php foreach($countryinfo as $country): $selected=($country->country_id==$default_country_id)? '':'';
				       $country_name=$country->country_name;
					   if (function_exists('icl_register_string')) {									
								icl_register_string('location-manager', 'location_country_'.$country->country_id,$country_name);
								$country_name = icl_t('location-manager', 'location_country_'.$country->country_id,$country_name);
						  }
						?>
					   <option value="<?php echo $country->country_id?>" <?php echo $selected;?>><?php echo $country_name;?></option>
				  <?php endforeach; ?>
				  </select>
			 </li>
			 <li>
				  <select name="zones_id" id="widget_classified_zone" filterdisplayname="<?php _e('State','classifieds');?>">
					   <option value=""><?php _e('All Regions','classifieds');?></option>
				       <?php foreach($zoneinfo as $zone): $selected=($zone->zones_id ==$default_zone_id)? '':'';
				       $zone_name=$zone->zone_name;
					   if (function_exists('icl_register_string')) {									
								icl_register_string('location-manager', 'location_zone_'.$zone->zones_id,$zone_name);
								$zone_name = icl_t('location-manager', 'location_zone_'.$zone->zones_id,$zone_name);
					   }	
					   ?>
					   <option value="<?php echo $zone->zones_id?>" <?php echo $selected;?>><?php echo $zone_name;?></option>
				       <?php endforeach;?>
				  </select>
			 </li>
			 <li>
				  
					   <select name="post_city_id" id="widget_classified_city" filterdisplayname="<?php _e('City','classifieds');?>">
							<option value=""><?php _e('All Cities','classifieds');?></option>
					        <?php foreach($cityinfo as $city): $selected=($city->city_id ==$default_city_id)? '':'';
					        $cityname=$city->cityname;
							if (function_exists('icl_register_string')) {									
										$city_slug = str_replace(' ','-',strtolower($country_name));
										$country_name = icl_t('location-manager', 'location_country_'.$city_slug ,$country_name);	
							}
							?>
							<option ctitile="<?php echo $cityname ;?>" value="<?php echo $city->city_id?>" <?php echo $selected;?>><?php echo $cityname ;?></option>
					   <?php endforeach;?>
					   </select>
				 
			 </li>
			 <?php } 
			 }
			 ?> 
		</ul>
		<input type="hidden" name="pcity_name" id="pcity_name" value=""  filterdisplayname="<?php _e('City','classifieds');?>" />
		<input type="hidden" name="pzone_name" id="pzone_name" value=""  filterdisplayname="<?php _e('Region','classifieds');?>" />
		<input type="hidden" name="pcountry_name" id="pcountry_name" value=""  filterdisplayname="<?php _e('Country','classifieds');?>" />
		<input type="hidden" name="pcat_name" id="pcat_name" value=""  filterdisplayname="<?php _e('Categories','classifieds');?>" />
		<input type="hidden" name="class_price" id="class_price" value="0"/>
		<!--  City Selection Area end -->
		
		<?php if(!is_tax()) { ?>
		<!--  Classified Type start -->
		<h4><?php _e('Classified Type','classifieds');?></h4>
		
		<?php
		
		$args1=array(
			'post_type'                => (isset($post_type) && $post_type != '') ? $post_type : 'post', /* post type */
			'child_of'                 => 0,
			'parent'                   => '',
			'orderby'                  => 'name',
			'order'                    => 'ASC',
			'hide_empty'               => 1,
			'hierarchical'             => 1,
			'exclude'                  => '',
			'include'                  => '',
			'number'                   => '',
			'taxonomy'                 => (isset($taxonomies[0]) && $taxonomies[0]!='') ? $taxonomies[0] :'category',   /* texonomy for post type */
			'pad_counts'               => false
			);

		/* get all categories of particulate post type selected from back end widget */
		$categories = get_categories($args1); 

		if(count($categories) > 0){
			?>
			<ul class="flt-pstatus">
			<select name="classified_type" id="classified_type" filterdisplayname="<?php _e('Classified Type','classifieds');?>">
				<option value=""><?php _e('Select Classified Type','classifieds');?></option>
			<?php
			foreach($categories as $category) 
			{	

				if(isset($_REQUEST['category']) && $_REQUEST['category'] == $category->term_id)
					 $selecetd_cat = 'selected="selected"';

					echo '<option '.$selecetd_cat.' value="'.$category->term_id.'">'.$category->name.'</option>';
			}
			
			?>
			</select>
			</ul>
			<?php
		}else{
			echo '<p>'. __('No Category available.','classifieds').'</p>';
		} } ?>
		<!--  Classified Type end -->

		<!--  Classified Price Type Start -->
		<h4><?php _e('Price Type','classifieds');?></h4>
		<ul class="flt-pstatus">
		<?php  wp_reset_query();
		$post_content = $wpdb->get_row("SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'price_type' and $wpdb->posts.post_type = 'custom_fields'");
		if(count($post_content) != 0)
		{
			$classified_ptype_id = $post_content->ID;
			$values = get_post_meta($classified_ptype_id,'option_values',true);
			$title = get_post_meta($classified_ptype_id,'option_title',true);
			$pro_ptype_arr = explode(',',$values);
			$pro_ptype_title = explode(',',$title);
			$c = 0;
			/*print_r($pro_ptype_arr);print_r($pro_ptype_title);*/
			foreach($pro_ptype_arr as $classified_ptype)
			{
				if(isset($_REQUEST['classified_ptype']) && !empty($_REQUEST['classified_ptype']) && $_REQUEST['classified_ptype'] == $classified_ptype)
				{
					$checked = 'checked';
				}
				else
				{
					$checked = '';
				}
			
				?>
				<li><input id="classified_ptype_<?php echo strtolower(str_replace(' ','',$classified_ptype));  ?>" filterdispvalue="<?php echo $pro_ptype_title[$c];?>" type="checkbox" filterdisptitle="<?php _e('Price Type','classifieds');?>" filterdisplayid="price_type" filterdispID="price_type" name="price_type[]" value="<?php echo $classified_ptype; ?>"/><label for="classified_ptype_<?php echo strtolower(str_replace(' ','',$classified_ptype));  ?>"><?php echo $pro_ptype_title[$c];?></label></li>
                <?php
				$c++;
			}
		}
		
		?>
        </ul>
		<!--  Classified Price Type End -->		
		
		<!--  Classified Status Start -->
		<h4><?php _e('Classified Status','classifieds');?></h4>
		<ul class="flt-pstatus">
		<?php  wp_reset_query();
		$post_content = $wpdb->get_row("SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'classified_tag' and $wpdb->posts.post_type = 'custom_fields'");
		if(count($post_content) != 0)
		{
			$classified_status_id = $post_content->ID;
			$values = get_post_meta($classified_status_id,'option_values',true);
			$opt_title = get_post_meta($classified_status_id,'option_title',true);
			$pro_status_arr = explode(',',$values);
			$pro_status_title_arr = explode(',',$opt_title);
			$b = 0;
			
			foreach($pro_status_arr as $classified_status)
			{
				?>
				<li><input id="classified_tag_<?php echo strtolower(str_replace($replace,$replace_with,$classified_status));  ?>" filterdispvalue="<?php echo $pro_status_title_arr[$b];?>" type="checkbox" filterdisptitle="<?php _e('Classified Status','classifieds');?>" filterdisplayid="classified_tag" filterdispID="classified_tag" name="classified_tag[]" value="<?php echo $classified_status; ?>"/><label for="classified_tag_<?php echo strtolower(str_replace($replace,$replace_with,$classified_status)); ?>"><?php echo $pro_status_title_arr[$b];?></label></li>
                <?php
				$b++;
			}
		}
		
		?>
        </ul>
		<!--  Classified Status End -->
	
		</form>
		<!-- form for find classified end -->
		<script type="text/javascript">
		jQuery(document).ready(function(){
			var typingTimer,getCityNameTimer;                /* timer identifier*/
			var doneTypingInterval = 1000,getCityInterval = 500;  /* time in ms, 1 second */
			/* search classified by changing country */	
			jQuery("#widget_classified_country").change(function(){				
				var country_id = jQuery('#widget_classified_country').val();		
				jQuery.ajax({
					url:ajaxUrl,
					type:'POST',
					async: true,
					data:'action=fill_states_cmb&country_id=' + country_id+'&front=1',
					success:function(results) {				
						jQuery('#widget_classified_zone').html(results);
						clearTimeout(typingTimer);
						if(jQuery('select#widget_classified_zone option:selected').val()!=''){
							jQuery('select#widget_classified_zone').trigger('change');						
						}else{
							var zone_first_option = jQuery('#widget_classified_zone option').first();					
							jQuery('#widget_classified_zone + span.select').text(zone_first_option.text());
						}
						/*typingTimer = setTimeout(tmpl_classified_search_filter, doneTypingInterval);*/
						typingTimer = setTimeout(tmpl_classified_search_filter, doneTypingInterval,jQuery('#pcountry_name').attr('id'),jQuery('#pcountry_name').attr('filterdisplayname'));
					}
				});
					
			});
			/* search classified by changing state */
			jQuery("#widget_classified_zone").change(function(){				
				var state_id = jQuery('#widget_classified_zone').val();		
				jQuery.ajax({
					url:ajaxUrl,
					type:'POST',
					async: true,
					data:'action=fill_city_cmb&state_id=' + state_id+'&front=1',
					success:function(results) {				
						jQuery('#widget_classified_city').html(results);
						
						clearTimeout(typingTimer);
						
						if(jQuery('select#widget_classified_city option:selected').val()!=''){
							jQuery('select#widget_classified_city').trigger('change');						
						}else{
							var city_first_option = jQuery('#widget_classified_city option').first();					
							jQuery('#widget_classified_city + span.select').text('<?php _e('All Regions','classifieds'); ?>');
						}
						
						/*typingTimer = setTimeout(tmpl_classified_search_filter, doneTypingInterval);*/
						typingTimer = setTimeout(tmpl_classified_search_filter, doneTypingInterval,jQuery('#pzone_name').attr('id'),jQuery('#pzone_name').attr('filterdisplayname'));
						
					}
				});	
			});
			/* search classified by changing city */
			jQuery("#widget_classified_city").live('change',function(){
					clearTimeout(typingTimer);
					clearTimeout(getCityNameTimer);
					getCityNameTimer = setTimeout(getCityName, getCityInterval,jQuery(this).val());	
					typingTimer = setTimeout(tmpl_classified_search_filter, doneTypingInterval,jQuery('#pcity_name').attr('id'),jQuery('#pcity_name').attr('filterdisplayname'));	
			});
			
			/* search classified by changing classified type */
			jQuery("#classified_type").change(function(){
				clearTimeout(typingTimer);
				getCityNameTimer = setTimeout(getCatName, getCityInterval,jQuery(this).val());	
				typingTimer = setTimeout(tmpl_classified_search_filter, doneTypingInterval,jQuery('#pcat_name').attr('id'),jQuery('#pcat_name').attr('filterdisplayname'));	
			});
			
			
			/* search classified by typing textbox */
			jQuery('#tmpl_find_classified input[type="text"]').bind('keyup',function(){
				clearTimeout(typingTimer);
				typingTimer = setTimeout(tmpl_classified_search_filter, doneTypingInterval,jQuery(this).attr('id'),jQuery(this).attr('filterdisplayname'));
			});
			/* search classified by clicking checkbox */
			jQuery('#tmpl_find_classified input[type="checkbox"]').bind('click',function(e){
				clearTimeout(typingTimer);
				tmpl_classified_search_filter(jQuery(this).attr('filterdispID'),jQuery(this).attr('filterdisptitle'));
			});
			
			
			/* Sorting Classified */
							
			jQuery('#directory_sort_order_alphabetical ul li a').live('click',function(e){
			e.preventDefault();
			jQuery(this).parent().parent().find('.active').removeClass('active');
			
			jQuery(this).parent().addClass('active');
			jQuery('#alpha_sort').val(jQuery(this).text());
			var alpha_sort =  jQuery('#alpha_sort').val();
			var miles_range=jQuery('#sf_radius_range').val();
				var list_id='<?php echo $list_id?>';
				jQuery('.'+list_id+'_process').remove();
				jQuery('#'+list_id ).prepend( "<p class='<?php echo $list_id.'_process';?>' style='text-align:center';><span class='process-overlay'></span><i class='fa fa-circle-o-notch fa-spin'></i></p>" );
				jQuery.ajax({
					url:ajaxUrl,
					type:'POST',
					cache: true,
					data:'action=tmpl_filter_classified&'+jQuery("#tmpl_find_property").serialize()+'<?php echo $query_string; ?>&posttype=classified&alpha_sort='+alpha_sort,						
					success:function(results){					
						jQuery('.'+list_id+'_process').remove();
						jQuery('#listpagi').remove();
						jQuery('#'+list_id).html(results);
					}
				});
				/* Ajax request for locate the location on map */
				jQuery.ajax({
						url:ajaxUrl,
						type:'POST',			
						data:'action=tmpl_filter_classified&'+jQuery("#tmpl_find_property").serialize()+'<?php echo $query_string; ?>&property_price=1&alpha_sort='+alpha_sort,
						success:function(results){						
							tmpl_miles_googlemap(results);
						}
					});
		
			});
				
			jQuery('#classified_sortby').attr('onchange','').unbind('change');	
			jQuery('#classified_sortby').bind('change',function (e){
			
			e.preventDefault();

			var sort_by = jQuery(this).val();
			if( sort_by == ''){ return false; }		
		
				jQuery('#csortby').val(jQuery(this).val());

				
				/* aliphatic list for sorting */
				var alphabts = '';
					  alphabts += '<div id="directory_sort_order_alphabetical" class="sort_order_alphabetical">';
					   alphabts += '<input type="hidden" name="alpha_sort" id="alpha_sort" />';
						alphabts += '<ul>';
							alphabts += '<li class="active"><a href="javascript:void(0)"><?php _e('All','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('A','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('B','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('C','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('D','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('E','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('F','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('G','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('H','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('I','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('J','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('K','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('L','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('M','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('N','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('O','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('P','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('Q','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('R','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('S','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('T','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('U','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('V','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('W','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('X','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('Y','classifieds');?></a></li>';
							alphabts += '<li><a href="javascript:void(0)"><?php _e('Z','classifieds');?></a></li>';
						alphabts += '</ul>';
					alphabts += '</div>';
					
				/* if sort by alphabets then show alphabets */
				if(jQuery(this).val() == 'alphabetical')
				{
					var cc = jQuery.cookie('display_view');	
					if(cc !='locations_map'){
						if(jQuery('#content #directory_sort_order_alphabetical').length == 0)
								jQuery('#'+'<?php echo $list_id?>').before(alphabts);
					}
					
					
				}
				else
				{
					if(jQuery('#content #directory_sort_order_alphabetical').length > 0)
								jQuery('#directory_sort_order_alphabetical').remove();
				}
				var miles_range=jQuery('#sf_radius_range').val();
				var list_id='<?php echo $list_id?>';	
				jQuery('.'+list_id+'_process').remove();
				jQuery('#'+list_id ).prepend( "<p class='<?php echo $list_id.'_process';?>' style='text-align:center';><span class='process-overlay'></span><i class='fa fa-2x fa-circle-o-notch fa-spin'></i></p>" );
				
				jQuery.ajax({
					url:ajaxUrl,
					type:'POST',
					cache: true,
					data:'action=tmpl_filter_classified&'+jQuery("#tmpl_find_classified").serialize()+'<?php echo $query_string; ?>',
					success:function(results){	
						jQuery('.'+list_id+'_process').remove();
						jQuery('#listpagi').remove();
						jQuery('#'+list_id).html(results);
						if(jQuery("#classified_sortby").val() =='price_low_high'){
							jQuery(".short-price .fa").removeClass('fa-caret-down');
							jQuery(".short-price .fa").addClass('fa-caret-up');
						}else{
							jQuery(".short-price .fa").removeClass('fa-caret-up');
							jQuery(".short-price .fa").addClass('fa-caret-down');
						}
						
						if(jQuery("#classified_sortby").val() =='title_desc'){
							jQuery(".short-title .fa").removeClass('fa-caret-down');
							jQuery(".short-title .fa").addClass('fa-caret-up');
						}else{
							jQuery(".short-title .fa").removeClass('fa-caret-up');
							jQuery(".short-title .fa").addClass('fa-caret-down');
						}
						
						if(jQuery("#classified_sortby").val() =='date_desc'){
							jQuery(".short-date .fa").removeClass('fa-caret-down');
							jQuery(".short-date .fa").addClass('fa-caret-up');
						}else{
							jQuery(".short-date .fa").removeClass('fa-caret-up');
							jQuery(".short-date .fa").addClass('fa-caret-down');
						}
			
					}
				});
				/* Ajax request for locate the location on map */
				jQuery.ajax({
						url:ajaxUrl,
						type:'POST',
						data:'action=tmpl_filter_classified&'+jQuery("#tmpl_find_classified").serialize()+'<?php echo $query_string; ?>',
						dataType: 'json',
						success:function(results){						
							googlemaplisting_deleteMarkers();
							templ_add_googlemap_markers(results.markers);
						}
					});
			});
			
			
			
			/* search classified by price range */
			jQuery('#classified-price-range').bind('slidestop', function(event, ui) {

			jQuery("#class_price").val(1);	
			
				/* for price range filter */
			  var id = 'classified_price_range';
			  var value = jQuery('#'+id).val(); /* get filter value */
				jQuery("#filter-group-classified_price_range").show();
				var range = value.split('-');
				var min_price = '<?php echo $min_price; ?>';
				var max_price = '<?php echo $max_price; ?>';
				if((jQuery.trim(range[0]) == min_price) && (jQuery.trim(range[1]) == max_price))
				  {
					  jQuery("#class_price").val(0);
					  jQuery("#filter-group-classified_price_range").hide();
					  tmpl_check_form_field_values_();
				  }	
				
				var price_range = jQuery('#classified_price_range').val();
				typingTimer = setTimeout(tmpl_classified_search_filter, doneTypingInterval,'classified_price_range','');
			});

			/* generate slider for price range */
			jQuery(function(){ 
				jQuery("#classified-price-range").slider({ 
					range:true,
					<?php
						if($tsetting['rtlcss'] == 1):
						?>
							isRTL: true,
						<?php	
						endif;
					?>
					min: <?php echo $min_price; ?>,
					max:<?php echo $max_price; ?>,
					values:[<?php echo $min_price; ?>,<?php echo $max_price; ?>],
					slide:function(e,t){
						jQuery("#classified_price_range").val("<?php echo $currency ?>"+tmpl_thousandseperator((parseFloat(t.values[0])).toFixed(num_decimals)).replace('.',decimal_sep).replace(' ','')+" - <?php echo $currency ?>"+tmpl_thousandseperator((parseFloat(t.values[1])).toFixed(num_decimals)).replace('.',decimal_sep).replace(' ',''));
						
						jQuery("#cprice_range").val(t.values[0]+" - "+t.values[1]);
						
						}
					});			
			});
		});
		/* function for get city name */
		function getCityName(cid)
		{
			jQuery.ajax({
				url:ajaxUrl,
				type:'POST',
				async: true,
				data:'action=tmpl_get_classified_city&cid='+cid,
				success:function(results) {							
					    jQuery('#pcity_name').val(results);
					}
				});
		}
		
		/* function for get category name for properties form category id */
		function getCatName(catid)
		{
			jQuery.ajax({
				url:ajaxUrl,
				type:'POST',
				async: true,
				data:'action=tmpl_get_classified_category_name&catid='+catid,
				success:function(results) {							
					    jQuery('#pcat_name').val(results);
					}
				});
		}
				
		/*
		*
		* function: tmpl_classified_search_filter
		* Description: search by filter
		*
		*/
		function tmpl_classified_search_filter(id,title)
		{
			var list_id='<?php echo $list_id?>';
			jQuery('#loop_classified_taxonomy_process').remove();
			jQuery('#loop_classified_taxonomy' ).prepend( "<p class='loop_classified_taxonomy_process' style='text-align:center';><i class='fa fa-circle-o-notch fa-2x fa-spin'></i></p>" );
			
			jQuery.ajax({
				url:ajaxUrl,
				type:'POST',
				async: true,
				data:'action=tmpl_filter_classified&'+jQuery("#tmpl_find_classified").serialize()+'<?php echo $query_string; ?>',
				success:function(results) {
					jQuery('#listpagi').remove();	
					jQuery('#loop_classified_taxonomy_process').remove();			
					jQuery('#loop_classified_taxonomy').html(results);
					filter_title = title;
					var value = jQuery('#'+id).val(); /* get filter value */
					
					/* for city filter */
					if(id == 'pcity_name')
					{
						if(value != '')
						{
						 
						  
							if (jQuery('#CselectedFilters #filter-group-'+id).length == 0 )
							{
								jQuery('#CselectedFilters').prepend('<div id="filter-group-'+id+'" class="flit-opt-cols"><div class="filter-lable">'+filter_title+':</div><span class="value"><a  delfltrname="RTitle" onclick="delClassifiedFltr(\''+id+'\')">'+value+'<i class="fa fa-times-circle"></i></a></span></div>');
							}
							else
								{
									jQuery('#filter-group-'+id+' span a').html(value+'<i class="fa fa-times-circle"></i>');
								}
							
							if(jQuery('#searchfilterform #'+id).val() == '')
							{
								jQuery('#CselectedFilters #filter-group-'+id).remove(); 
							}
							if(id == 'search_within')	
							{
								if(jQuery('#CselectedFilters #'+id).val() == '')
								{
									jQuery('#CselectedFilters #filter-group-'+id).remove(); 
								}
							}
						}
                        else
						{
							jQuery('#CselectedFilters #filter-group-'+id).remove(); 
						}						


					}
					/* for price range filter */
					else if(id == 'classified_price_range')
					{
						  var range = value.split('-');
						     filter_title = '<?php _e('Price Range','classifieds')?>';   
							if (jQuery('#CselectedFilters #filter-group-'+id).length == 0 )
							{
								jQuery('#CselectedFilters').prepend('<div id="filter-group-'+id+'" class="flit-opt-cols"><div class="filter-lable">'+filter_title+':</div><span class="value"><a  delfltrname="RTitle" onclick="delClassifiedFltr(\''+id+'\')">'+value+'<i class="fa fa-times-circle"></i></a></span></div>');
							}
							else
								{
									jQuery('#filter-group-'+id+' span a').html(value+'<i class="fa fa-times-circle"></i>');
								}
							
							if(jQuery('#searchfilterform #'+id).val() == '')
							{
								jQuery('#CselectedFilters #filter-group-'+id).remove(); 
							}
							
					}
					else if(id == 'pcat_name')
					{ 
							if (jQuery('#CselectedFilters #filter-group-'+id).length == 0 )
							{
								jQuery('#CselectedFilters').prepend('<div id="filter-group-'+id+'" class="flit-opt-cols"><div class="filter-lable">'+filter_title+':</div><span class="value"><a  delfltrname="RTitle" onclick="delClassifiedFltr(\''+id+'\')">'+value+'<i class="fa fa-times-circle"></i></a></span></div>');
							}
							else
								{
									jQuery('#filter-group-'+id+' span a').html(value+'<i class="fa fa-times-circle"></i>');
								}
							
							if(jQuery('#searchfilterform #'+id).val() == '')
							{
								jQuery('#CselectedFilters #filter-group-'+id).remove(); 
							}
					}
					else
					{
						var atLeastOneIsChecked = jQuery('#tmpl_find_classified input[name="'+id+'[]"]:checked').length;
						if(atLeastOneIsChecked > 0) 
						{
							filter_title = title; /* get title of filter */
							
							jQuery('#tmpl_find_classified input[name="'+id+'[]"]:checked').each(function() {
								chkId = jQuery(this).attr('id');
								checkboxName = jQuery(this).attr('filterdispvalue'); 
								if (jQuery('#CselectedFilters #filter-group-'+id).length == 0 ) /* creates a block for creating of block is not created before */
								{
									jQuery('#CselectedFilters').prepend('<div id="filter-group-'+id+'" class="flit-opt-cols"><div class="filter-lable">'+filter_title+':</div><span class="value"><a  delfltrname="filter_title" id="'+id+'_'+chkId+'" onclick="delFltrCheckbox(\''+chkId+'\',\''+id+'\')">'+checkboxName+'<i class="fa fa-times-circle"></i></a></span></div>');
								}
								else    /* otherwise add a value for created block  */
								{
									
									if (jQuery('#filter-group-'+id+' span #'+id+'_'+chkId).length == 0 )
									{
										jQuery('#filter-group-'+id+' span').prepend('<a  delfltrname="filter_title" id="'+id+'_'+chkId+'" onclick="delFltrCheckbox(\''+chkId+'\',\''+id+'\')">'+checkboxName+'<i class="fa fa-times-circle"></i></a>');
									}
									else
									{
										jQuery('#filter-group-'+id+' span a').remove();
										
										jQuery('#tmpl_find_classified input[name="'+id+'[]"]').each(function(){
										
										var curr_val = jQuery(this).val();
										var curr_id = jQuery(this).attr('id');
										if(jQuery(this).attr('checked') == 'checked')
										{
											checkboxName = jQuery(this).attr('filterdispvalue');
											jQuery('#filter-group-'+id+' span').prepend('<a  delfltrname="filter_title" id="'+id+'_'+curr_id+'" onclick="delFltrCheckbox(\''+curr_id+'\',\''+id+'\')">'+checkboxName+'<i class="fa fa-times-circle"></i></a>');
										}
																										
										});
									}
								}
							});
						}
						else
						{
							jQuery('#CselectedFilters #filter-group-'+id).remove();
						}
					}
					jQuery('.cfilter_list_wrap').show();
					jQuery('#CselectedFilters').show();	
					tmpl_check_form_field_values_();	
				}
			});
			
			/* Ajax request for locate the location on map */
			jQuery.ajax({
					url:ajaxUrl,
					type:'POST',			
					data:'action=tmpl_filter_locations_map&'+jQuery("#tmpl_find_classified").serialize()+'<?php echo $query_string; ?>',
					dataType: 'json',
					success:function(results){						
						googlemaplisting_deleteMarkers();
						templ_add_googlemap_markers(results.markers);
					}
				});
			
			}
		
			/* clear all filters */
			jQuery('#cclear_filter').bind('click',function(){
				
				/* reset select box */
				jQuery('#tmpl_find_classified select').each(function(){
					var select_id = jQuery(this).attr('id');
					console.log(select_id);
					jQuery('#tmpl_find_classified #'+select_id+' + span.select').text(jQuery('#tmpl_find_classified #'+select_id+' option:first').text());
				});
			
				/* generate slider for price range */
				jQuery(function(){ 
					jQuery("#classified-price-range").slider({ 
						range:true,
						<?php
						if($tsetting['rtlcss'] == 1):
						?>
							isRTL: true,
						<?php	
						endif;
						?>
						min: <?php echo $min_price; ?>,
						max:<?php echo $max_price; ?>,
						values:[<?php echo $min_price; ?>,<?php echo $max_price; ?>],
						slide:function(e,t){ 
							 jQuery("#classified_price_range").val(t.values[0]+" - "+t.values[1]);
							}
						});			
				});
				
				jQuery('#tmpl_find_classified').each (function(){
				 this.reset();				  /* resets tha search filter form	*/				   
				});

				jQuery('#widget_classified_city + span.select').text('<?php _e('All Cities','classifieds') ?>');
				jQuery('#widget_classified_zone + span.select').text('<?php _e('All Regions','classifieds') ?>');
				jQuery('#widget_classified_country + span.select').text('<?php _e('Select Country','classifieds') ?>');	

				var list_id='<?php echo $list_id?>';	
				jQuery('.'+list_id+'_process').remove();
				jQuery('#'+list_id ).prepend( "<p class='<?php echo $list_id.'_process';?>' style='text-align:center';><span class='process-overlay'></span><i class='fa fa-circle-o-notch fa-spin'></i></p>" );
				jQuery.ajax({
				url:ajaxUrl,
				type:'POST',
				async: true,
				data:'action=tmpl_filter_classified&'+jQuery("#tmpl_find_classified").serialize()+'<?php echo $query_string; ?>',
				success:function(results) {	
					jQuery('#loop_classified_taxonomy_process').remove();			
					jQuery('#loop_classified_taxonomy').html(results);
						jQuery('#CselectedFilters .flit-opt-cols').remove(); /* remove all filters from filter listing  */
						jQuery('.cfilter_list_wrap').hide();
					}
				});
			/* Ajax request for locate the location on map */
						jQuery.ajax({
								url:ajaxUrl,
								type:'POST',			
								data:'action=tmpl_filter_locations_map&'+jQuery("#tmpl_find_classified").serialize()+'<?php echo $query_string; ?>',
								dataType: 'json',
								success:function(results){						
									googlemaplisting_deleteMarkers();
									templ_add_googlemap_markers(results.markers);
								}
							});
				
				});
				
				
				/* filter with pagination */
				jQuery('#listpagi .page-numbers').live('click',function(e){
				e.preventDefault();
				var page_link = jQuery(this).attr('href');
				if(page_link)
				{
					
					/* separates the link by '/' because page number is in the link */
					if(page_link.indexOf('paged') != -1){
						var split_link = page_link.split('=');
						/* get page number which is second last element in split link */
						var page_num = split_link[split_link.length-1];
					}else{
						var split_link = page_link.split('/');
						/* get page number which is second last element in split link */
						var page_num = split_link[split_link.length-2];
					}
					
					var list_id='<?php echo $list_id?>';
					
					jQuery('#loop_classified_taxonomy_process').remove();
					jQuery('#loop_classified_taxonomy' ).prepend( "<p class='loop_classified_taxonomy_process' style='text-align:center';><i class='fa fa-circle-o-notch fa-2x fa-spin'></i></p>" );
					
					jQuery.ajax({
					url:ajaxUrl,
					type:'POST',
					async: true,
					data:'action=tmpl_filter_classified&'+jQuery("#tmpl_find_classified").serialize()+'<?php echo $query_string; ?>&page_num='+page_num,
						success:function(results){					
							jQuery('.'+list_id+'_process').remove();
							jQuery('#listpagi').remove();
							
							jQuery('#'+list_id).html(results);
							jQuery("html, body").animate({ scrollTop: 0 }, 500);
						}
					});
					
					/* Ajax request for locate the location on map */
					jQuery.ajax({
							url:ajaxUrl,
							type:'POST',			
							data:'action=tmpl_filter_classified_map&'+jQuery("#tmpl_find_classified").serialize()+'<?php echo $query_string; ?>&page_num='+page_num,
							success:function(results){						
								tmpl_cmiles_googlemap(results);
							}
						});
						
				}
				else
				{
					return false;
				}
				
			});
			/* 
			Name :tmpl_miles_googlemap
			description : read the data, create markers for map location
			*/
			function tmpl_cmiles_googlemap(data) {
					
					/* get the bounds of the map*/
					bounds = new google.maps.LatLngBounds();  
					/* clear old markers*/
					tmpl_search_googlemap_deleteMarkers();   
					jsonData = jQuery.parseJSON(data);
					/* create the info window*/
					
					/* if no markers found, display map_marker_nofound div with no search criteria met message	*/
					 if (jsonData[0].totalcount <= 0) {
						
						var mapcenter = new google.maps.LatLng(CITY_MAP_CENTER_LAT,CITY_MAP_CENTER_LNG);
						tmpl_search_googlemap_listMapMarkers1(jsonData);
						map.setCenter(mapcenter);
						map.setZoom(CITY_MAP_ZOOMING_FACT);
					}else{			
						var mapcenter = new google.maps.LatLng(CITY_MAP_CENTER_LAT,CITY_MAP_CENTER_LNG);
						tmpl_search_googlemap_listMapMarkers1(jsonData);
						
						map.fitBounds(bounds);
						var center = bounds.getCenter();
						map.setCenter(center);
						
					}
				}
				
			
			/* 
			Name :search_googlemap_deleteMarkers
			description : Delete the existing google map markers
			*/
			function tmpl_search_googlemap_deleteMarkers() {		
				 if (markerArray && markerArray.length > 0) {		
					for (i in markerArray) {
						if (!isNaN(i)){								
							markerArray[i].setMap(null);
							infoBubble.close();
						}
					}
					markerArray.length = 0;
				  }	
				
				markerClusterer.clearMarkers();
				
			}
			
			/* 
			Name :tmpl_search_googlemap_listMapMarkers1
			description : markers
			*/
			function tmpl_search_googlemap_listMapMarkers1(input) {
			markers=input;
			var search_string = document.getElementById('search_string');
			var totalcount = input[0].totalcount;
			if(mClusterer != null)
			{
				mClusterer.clearMarkers();
			}	
			mClusterer = null;	
			if(totalcount > 0){
				for (var i = 0; i < input.length; i++) {							 
					var details = input[i];				
					var image = new google.maps.MarkerImage(details.icons,new google.maps.Size(PIN_POINT_ICON_WIDTH, PIN_POINT_ICON_HEIGHT));
					var coord = new google.maps.LatLng(details.location[0], details.location[1]);			
					markers[i]  = new google.maps.Marker({
									position: coord,
									title: details.name,
									visible: true,
									clickable: true,
									map: map,
									icon: details.icons
								});
					
					bounds.extend(coord);
					markerArray[i] = markers[i];				
					markers[i]['infowindow'] = new google.maps.InfoWindow({
						content: details.message,
						maxWidth: 200
					});	
					
					/*New infobundle*/
					 infoBubble = new InfoBubble({
						maxWidth:210,minWidth:210,minHeight:"auto",padding:0,content:details.message,borderRadius:0,borderWidth:0,borderColor:"none",overflow:"visible",backgroundColor:"#fff"
					  });			
					/* finish new infobundle */
					
					/* Start */
						google.maps.event.addListener(markers, "click", function (e) {														    
						infoBubble.open(map, details.message);					
						});
					
					
					mgr.addMarkers( markers[i], 0 );			
					tmpl_search_marker_attachMessage(markers[i], details.message);
					
				}			
				markerClusterer = new MarkerClusterer(map, markers);
			}  
			}
			
			
			function tmpl_search_marker_attachMessage(marker, msg) {
				  var myEventListener = google.maps.event.addListener(marker, 'click', function() {
						infoBubble.setContent( msg );
						infoBubble.open(map, marker);
				  });
				}	
			
		
		/* 
		Name :delFltr
		description : removal of filter from filter listing and show result according to it
		parameter : 'str' - removal according to this argument
		*/
		function delClassifiedFltr(str)
		{
			var list_id='<?php echo $list_id?>';	
			
			jQuery('.'+list_id+'_process').remove();
			jQuery('#'+list_id ).prepend( "<p class='<?php echo $list_id.'_process';?>' style='text-align:center';><span class='process-overlay'></span><i class='fa fa-circle-o-notch fa-spin'></i></p>" );
			
			if(str == 'pcity_name'){
				jQuery('#widget_classified_city + span.select').text('<?php _e('Select City','classifieds'); ?>');
			}

			if(str == 'pcat_name'){
				jQuery('#classified_type').prop('selectedIndex',0);
				jQuery('#classified_type + span.select').text('<?php _e('Select Classified Type','classifieds'); ?>');
			}		
			
			/* if removed filter is slider then initialize the filter */
			if(str == 'classified_price_range'){
				var min_val = '<?php echo $min_price; ?>';
				var max_val = '<?php echo $max_price; ?>';
				jQuery("#classified-price-range").slider({ 
					range:true,
					<?php
						if($tsetting['rtlcss'] == 1):
						?>
							isRTL: true,
						<?php	
						endif;
					?>
					min: <?php echo $min_price; ?>,
					max:<?php echo $max_price; ?>,
					values:[<?php echo $min_price; ?>,<?php echo $max_price; ?>],
					slide:function(e,t){
						 jQuery("#classified_price_range").val(t.values[0]+" - "+t.values[1]);			
						 tmpl_check_form_field_values_();
						}
					});

				jQuery("#classified_price_range").val(min_val+" - "+max_val);			
	
			}
			
			jQuery.ajax({
				url:ajaxUrl,
				type:'POST',
				async: true,
				data:'action=tmpl_filter_classified&'+jQuery("#tmpl_find_classified").serialize()+'<?php echo $query_string; ?>',
				success:function(results) {							
					jQuery('.'+list_id+'_process').remove();
					jQuery('#listpagi').remove();
					jQuery('#'+list_id).html(results);
					jQuery('#filter-group-'+str).remove();
					tmpl_check_form_field_values_();
				}
			});
			
		}
		
		
		function delFltrCheckbox(val,type)
		{
				/*if(type == 'classified_tag' || type == 'classified_ptype')*/
				{
				 jQuery('#tmpl_find_classified input[name="'+type+'[]"]').each(function() {
						if(jQuery(this).attr('id') == val)
						{
							jQuery(this).attr('checked', false); /* uncheck a checkbox  */
						}
				 });
				}
			
				
				var list_id='<?php echo $list_id?>';	 /* get the page id */
				jQuery('.'+list_id+'_process').remove(); /* remove the element */
				jQuery('#'+list_id ).prepend( "<p class='<?php echo $list_id.'_process';?>' style='text-align:center';><span class='process-overlay'></span><i class='fa fa-circle-o-notch fa-spin'></i></p>" );  /* show processing image during ajax request. */
				jQuery.ajax({
				url:ajaxUrl,
				type:'POST',
				async: true,
				data:'action=tmpl_filter_classified&'+jQuery("#tmpl_find_classified").serialize()+'<?php echo $query_string; ?>',
				success:function(results) {							
					jQuery('.'+list_id+'_process').remove();						
						jQuery('.'+list_id+'_process').remove();
						jQuery('#listpagi').remove(); 
						jQuery('#'+list_id).html(results);
						if(jQuery('#filter-group-'+type+' .value a').length > 1)
							{
								jQuery('#'+type+'_'+val).remove();
							}
						else
							{
								jQuery('#filter-group-'+type).remove();
							}
					tmpl_check_form_field_values_();		
					}
				});

		}
		
		function tmpl_check_form_field_values_()
		{
				/* check if textfields are empty */
				
				var id = 'classified_price_range';
				var value = jQuery('#'+id).val(); /* get filter value */
				
				var range = value.split('-');
				var min_price = '<?php echo $min_price; ?>';
				var max_price = '<?php echo $max_price; ?>';
				
				if((jQuery.trim(range[0]) == min_price) && (jQuery.trim(range[1]) == max_price))
				  {
					  var empty_textbox = 1;
				  }
				 else{
					var empty_textbox = 0;
				}	
				jQuery('#tmpl_find_classified :text').each(function(){ 
					if( jQuery.trim(jQuery(this).val()) == "" ) empty_textbox++ ;
					
				});
				
				/* check if checkboxes are empty */
				var empty_checkbox = 0;
				jQuery('#tmpl_find_classified :checkbox').each(function(){ 
					if( jQuery(this).prop('checked') == false ) empty_checkbox++ ;
					
				});
				
				/* check if selectboxes are empty */
				var empty_selectbox = 0;
				jQuery('#tmpl_find_classified select').each(function(){ 
					if( jQuery(this).val() == "" ) empty_selectbox++ ;
					
				});
				
				/*console.log(empty_textbox +'=='+ jQuery('#tmpl_find_classified :text').length);
				console.log(empty_checkbox  +'=='+ jQuery('#tmpl_find_classified :checkbox').length);
				console.log(empty_selectbox  +'=='+ jQuery('#tmpl_find_classified select').length);*/
				
				
				/* if all fields are empty then remove search filter list from above listing */				
				if((empty_textbox == jQuery('#tmpl_find_classified :text').length) && (empty_checkbox == jQuery('#tmpl_find_classified :checkbox').length) && (empty_selectbox == jQuery('#tmpl_find_classified select').length))
				{
					jQuery('#CselectedFilters').hide();
				}
		}	
		
		</script>
		<?php

		echo $args['after_widget'];
		}
	}
	
	/**
	 * Back-end widget form.
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => __('Find Classified','classifieds') ,'post_type' => 'classified') );		
		$title = strip_tags($instance['title']);
		$min_price = strip_tags($instance['min_price']);
		$max_price = strip_tags($instance['max_price']); ?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:','classifieds' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'price_range' ); ?>"><?php _e( 'Price Range:','classifieds' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'min_price' ); ?>" name="<?php echo $this->get_field_name( 'min_price' ); ?>" type="text" value="<?php echo esc_attr( $min_price ); ?>">
			<input class="widefat" id="<?php echo $this->get_field_id( 'max_price' ); ?>" name="<?php echo $this->get_field_name( 'max_price' ); ?>" type="text" value="<?php echo esc_attr( $max_price ); ?>">
		</p>
		<?php
	}
	
	/**
	 * Sanitize widget form values as they are saved.
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		return $new_instance;
	}
}


/* Widget to display the seller details on detail page */
class TmplClassifiedSellerDetails extends WP_Widget {
	/*
	 * Register widget with WordPress.
	 */	
	function __construct() {
		$widget_ops = array('classname' => 'tmpl_classified_seller', 'description' => __('Display the seller details on classified detail page sidebar.','classifieds') );
		$this->WP_Widget('TmplClassifiedSellerDetails', __('T &rarr; Classified&lsquo;s Seller Detail','classifieds'), $widget_ops);
	}
	
	function widget( $args, $instance ) {
		/* prints the widget*/
		extract($args, EXTR_SKIP);
		/* Show this widget only on preview page single page and on author page */
		
		if(isset($_REQUEST['p']) || (isset( $_REQUEST['ptype']) && $_REQUEST['ptype'] == 'preview') || is_author() || is_single()){
			echo $args['before_widget'];
			global $post,$curauth,$current_user,$htmlvar_name,$tmpl_flds_varname ;
			
			
			$is_edit='';
			if(isset($_REQUEST['action']) && $_REQUEST['action']=='edit'){
				$is_edit=1;
			}
			
			if(empty($curauth)){
				if($post->post_author !=''){
					$curauth = $post->post_author;
				}else{
					$curauth = $current_user->ID;
				}
				$curauth = get_userdata($curauth);
			} 
			$title = apply_filters('widget_title', $instance['title']);
			
			if(@$_REQUEST['ptype'] == 'preview')
			 {
				global $current_user;
				$userid = $current_user->ID;
				$user_details = get_userdata( $userid );
				$classified_id = $_REQUEST['cur_post_id'];
			 }elseif(is_author()){
				$author = get_userdata(get_query_var('author'));
				$userid = $author->ID;
				$user_details = get_userdata( $userid );
			 }else{
				if(isset($_REQUEST['p'])){
					$post = get_post(@$_REQUEST['p']);
				}
				
				$userid =  $post->post_author;
				$user_details = get_userdata( $userid );
				$classified_id  = $post->ID;
			 }

			$owner_name = get_post_meta( $post->ID,'owner_name',true);
			$facebook = get_post_meta( $post->ID,'facebook',true);
			$twitter = get_post_meta( $post->ID,'twitter',true);
			$google = get_post_meta( $post->ID,'google',true);
			$website = get_post_meta( $post->ID,'web_site',true);
			$phone = get_post_meta( $post->ID,'phone',true);
			$email = get_post_meta( $post->ID,'email',true);
			echo $args['before_title'].$title.$args['after_title']; 
			
			/* Show the seller details on preview page */
			?>
				<div class="tmpl-seller-details">
					<div class="seller-top_wrapper">
					  <div class="tmpl-seller-photo">
						<?php
						/* get user ID on preview page */
						if(!empty($_REQUEST)){
							$curauth = get_user_by( 'email', $_REQUEST['email'] );
							$user_details = get_user_by( 'email', $_REQUEST['email'] );
							$user_id = $curauth->ID;
						}
						/* get user ID on preview page end */
						 if ( get_user_meta($curauth->ID,'profile_photo',true) != '' ) { echo '<img src="'.get_user_meta($curauth->ID,'profile_photo',true).'" alt="'.$curauth->display_name.'" title="'.$curauth->display_name.'"  width="'.apply_filters('tev_widget_photo_size',90).'"/>'; } 
						else 
						{
							echo get_avatar($email, apply_filters('tev_seller_photo_size',90) ); 
						}
							
						?>
					  </div>
					  <div class="tmpl-seller-detail-rt">
						<!-- Listing details -->
                        <?php if($is_edit==1):
							$owner_name=($owner_name!='')?$owner_name:'Edit Author Name';
						?>
                        <p class="title"><strong id="frontend_owner_name" class="frontend_owner_name" contenteditable="true"><?php echo $owner_name; ?></strong></p>
                        <?php else:?>
						<p class="title"><a href="<?php echo get_author_posts_url($post->post_author); ?>"><strong><?php echo $owner_name; ?></strong></a></p>
                        <?php endif;?>
						<p><label><?php _e('Joined On','classifieds'); ?>:</label> <?php if($post->post_date && empty($_REQUEST)){ echo date_i18n(get_option('date_format'),strtotime($post->post_date)); }else{ echo date_i18n(get_option('date_format')); } ?></p>
                        <p class="author_seller_button">
						<a class="button" href="<?php echo get_author_posts_url($post->post_author)."?custom_post=classified"; ?>"><?php _e('Owner Listings','classifieds'); ?></a>
                        </p>
					  </div>
					</div>
					<!-- Display user details -->
					<div class="agent-social-networks">
					<?php
					/* facebook link display */
					if(($tmpl_flds_varname['facebook'] && $facebook !='') || ($is_edit==1 && $tmpl_flds_varname['facebook'])){ ?>
					<a id="facebook" class="frontend_facebook <?php if($is_edit==1):?>frontend_link<?php endif; ?>" href="<?php echo $facebook; ?>"><i class="fa fa-facebook"></i> <span class="mtext"><?php _e('facebook','classifieds'); ?></span><span class="urllink"><?php echo $facebook; ?></span></a>
					<?php }
					/* Twitter link display */
					if(($tmpl_flds_varname['twitter'] && $twitter !='') || ($is_edit==1 && $tmpl_flds_varname['twitter'])){ ?>
					<a id="twitter" class="frontend_twitter <?php if($is_edit==1):?>frontend_link<?php endif; ?>" href="<?php echo $twitter; ?>"><i class="fa fa-twitter"></i> <span class="mtext"><?php _e('twitter','classifieds'); ?></span><span class="urllink"><?php echo $twitter; ?></span> </a>
					<?php }
					/* Goggle Plus link display */
					if(($tmpl_flds_varname['google'] && $google !='') || ($is_edit==1 && $tmpl_flds_varname['google'])){ ?>
					<a id="google" class="frontend_google <?php if($is_edit==1):?>frontend_link<?php endif; ?>" href="<?php echo $google; ?>"><i class="fa fa-google-plus"></i> <span class="mtext"><?php _e('google','classifieds'); ?></span><span class="urllink"><?php echo $google; ?></span> </a>
					<?php } ?>
					</div>
					<?php 
					/* About User */
					
					/* Display User Description */
					if($form_fields_usermeta['description']['on_author_page'] && $user_details->description !=''){
					?>
						<p class="user_biography"><label><?php _e('Agent Description','classifieds'); ?>: </label><?php echo $user_details->description; ?></p>
					<?php } 
					
					/* Display User Website */
					if(($tmpl_flds_varname['web_site'] && $website !='') || ($is_edit==1 && $tmpl_flds_varname['web_site'])){ ?>
						<p class="website"><a id="web_site" class="frontend_web_site <?php if($is_edit==1):?>frontend_link<?php endif; ?>" href="<?php echo $website; ?>"><i class="fa fa-globe"></i> <?php _e('Visit seller&lsquo;s website','classifieds'); ?>  </a></p>
					<?php } 
					/* Display Phone Website */
					if(($tmpl_flds_varname['phone'] && $phone !='') || ($is_edit==1 && $tmpl_flds_varname['phone'])){ ?>
						<p class="phone"><i class="fa fa-phone"></i> <?php echo $phone; ?></p>
					<?php } 
					/* Contact form */ ?>

				</div>
			<?php
			echo $args['after_widget'];
		}
		
	}
	
	function update($new_instance, $old_instance) {
		$instance = $old_instance;		
		$instance['title'] = strip_tags($new_instance['title']);
		return $instance;
	}
	
	public function form( $instance ) {
		$instance = wp_parse_args((array)$instance, array('title' =>'') );
		$title = (strip_tags($instance['title'])) ? strip_tags($instance['title']) : __("About the seller",'classifieds');
		?>
		<p>
		  <label for="<?php echo $this->get_field_id('title'); ?>"><?php echo __('Title','classifieds'); ?>:
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
		  </label>
		</p>
		<?php
	}
}

/* classifieds - Popular Posts Widget - Slider */

class TmplClassifiedPopularList extends WP_Widget
{
		function __construct()
		{
			parent::__construct(
				'TmplClassifiedPopularList', /* Base ID*/
				__('T &rarr; Popular Advertisements','classifieds'), /* Name*/
				array('description'=> __('Display images from a specific category or a collection of static images. The widget works best in above home page content area.','classifieds')) /* Args*/
			);
		}
		function widget($args, $instance)
		{
			extract($args, EXTR_SKIP);
			echo $args['before_widget'];
			/*
			*  Add flexslider script and style sheet in head tag
			*/
			$custom_banner_temp = empty($instance['custom_banner_temp']) ? '' : $instance['custom_banner_temp'];
			$post_type = empty($instance['post_type']) ? 'post,1' : apply_filters('widget_category', $instance['post_type']);
			$title    = empty($instance['title']) ? '' : apply_filters('widget_title', $instance['title']);
			$popular_per    = empty($instance['popular_per']) ? '' : apply_filters('widget_popular_per', $instance['popular_per']);
			$sdesc = empty($instance['sdesc']) ? '' : apply_filters('widget_sdesc', $instance['sdesc']);
			$number = empty($instance['number']) ? '7' : apply_filters('widget_number', $instance['number']);
			$height = empty($instance['height']) ? '' : apply_filters('widget_height', $instance['height']);
			$autoplay = empty($instance['autoplay']) ? '' : apply_filters('widget_autoplay', $instance['autoplay']);
			$slideshowSpeed = empty($instance['slideshowSpeed']) ? '' : apply_filters('widget_autoplay', $instance['slideshowSpeed']);
			$sliding_direction = empty($instance['sliding_direction']) ? 'horizontal' : $instance['sliding_direction'];
			$reverse = empty($instance['reverse']) ? 'false' : $instance['reverse'];
			$animation_speed = empty($instance['animation_speed']) ? '2000' : $instance['animation_speed'];
			/* Carousel Slider Settings*/
			$is_Carousel = 1;
			if($is_Carousel){
				$item_width = empty($instance['item_width']) ? 300 : $instance['item_width'];
				/*$item_margin = empty($instance['item_margin']) ? '0' : $instance['item_margin'];*/
				$min_item = empty($instance['min_item']) ? '0' : $instance['min_item'];
				$max_items = empty($instance['max_items']) ? '7' : $instance['max_items'];
				$item_margin = empty($instance['item_margin']) ? 25 : $instance['item_margin'];
				$item_move = empty($instance['item_move']) ? '0' : $instance['item_move'];
			}else{
				$item_width = empty($instance['item_width']) ? 925 : $instance['item_width'];;
				$min_item = 0;
				$max_items= 0;
				$item_move= 0;
			}

			$width = apply_filters('classified_img_slider_width',$item_width,12);
			$height= apply_filters('classified_img_slider_height',350);

			
			$class = "flexslider".rand();
			if($autoplay == '')
			{
				$autoplay = 'false';
			}
			if($slideshowSpeed == '')
			{
				$slideshowSpeed = '300000';
			}
			if($animation_speed == '')
			{
				$animation_speed = '2000';
			}
			if($autoplay == 'false')
			{
				$animation_speed = '300000';
			}
			
			$supreme2_theme_settings = (function_exists('supreme_prefix')) ? get_option(supreme_prefix().'_theme_settings'):'';
			?>
			<script type="text/javascript">
			jQuery(window).load(function(){		
			 /* item margin is same as provided in css li- margin */	
				var $window = jQuery(window), flexslider;
				 function getGridSize() {
				    return (window.innerWidth < 480) ? 1 :
				           (window.innerWidth < 900) ? 4 : <?php echo $max_items;?>;
				  }
				  $window.load(function() {						
					jQuery('.<?php echo $class;?>').flexslider({
						animation: "slide",
						animationLoop: true,					
						slideshow: <?php echo $autoplay;?>,
						prevText: '<i class="fa fa-chevron-left"></i>',
						nextText: '<i class="fa fa-chevron-right"></i>',
						minItems:  getGridSize(),
						maxItems:   getGridSize(),
						itemWidth: <?php echo $item_width ; ?>,
						itemMargin: <?php echo $item_margin; ?>,
						<?php if($supreme2_theme_settings['rtlcss'] ==1){ ?>
						rtl: true,
						<?php } ?>
						touch:true,
					});
				});													
            }());
			</script>
			<!-- flex slider container start -->
			<?php
			if($custom_banner_temp != ''){
				$custom_class_name = ' image_slider';
			}
			else
			{
				$custom_class_name = ' post_slider';
			}
			$is_Carousel=' slider_carousel';
			$animation_class="slide ";
			if( $title == '')
			{
				$notitle = 'notitle ';
			}
			?>
			<div class="flexslider clearfix post_slider slider_carousel slide <?php echo $notitle.$class; ?>">
			<?php if($title){ ?>
				  <h3 class="widget-title"> <?php echo $title; ?> </h3>
			<?php } 
			if(function_exists('icl_register_string'))
			{
				icl_register_string('classifieds','slider_description',$sdesc);
				$sdesc = icl_t('classifieds','slider_description',$sdesc);
			}
			if($sdesc)
			{ ?><p> <?php echo $sdesc; ?> </p><?php } ?>
	
				<div class="slides_container clearfix">
					<?php do_action('templ_slider_search_widget',$instance);/* add action for display additional field */ ?>
					<ul class="slides">
					 <?php

						global $post,$wpdb;
						$counter=0;
						$postperslide = 1;						
						$slider_post=$post_type;
						
						for($k=0;$k<sizeof($slider_post);$k++){
							
							$posttype = explode(',',$slider_post[$k]);				
							$post_type = $posttype[0];
							$catid = $posttype[1];
							$cat_name = @$posttype[2];
							$taxonomies = get_object_taxonomies( (object) array( 'post_type' => $post_type,'public'   => true, '_builtin' => true ));							
							if($post_type=='product')
							{
								$taxonomies[0]=$taxonomies[1];	
							}
							$term = get_term( $catid, $taxonomies[0] );							
							$cat_id[]=$term->term_id;
						
						}
						if(is_plugin_active('woocommerce/woocommerce.php') && $post_type == 'product')
						{
							$taxonomies[0] = $taxonomies[1];
						}
						
						/* show the popular way different way */
						if($popular_per =='views'){
							$order_arg = array('meta_key' => 'viewed_count',	
										'orderby' => 'meta_value_num',
										'meta_value_num'=>'viewed_count',
										'order' => 'DESC');
						}elseif($popular_per =='dailyviews'){
							$order_arg = array('meta_key' => 'viewed_count_daily',	
										'orderby' => 'meta_value_num',
										'meta_value_num'=>'viewed_count_daily',
										'order' => 'DESC');						
						}elseif($popular_per =='comments'){
							$order_arg = array('orderby' => 'comment_count','order' => 'DESC');
						}else{
							/* Fetch the featured on home page listings first */
							$order_arg = array('meta_key' => 'featured_h',	
										'orderby' => 'meta_value',
										'order' => 'ASC');
						}
						$args=array(												  
								  'post_type' => $post_type,
								  'posts_per_page' => $number,												  
								  'post_status' => 'publish' ,
								  'tax_query' => array(                
											array(
												'taxonomy' =>$taxonomies[0],
												'field' => 'id',
												'terms' => $cat_id,
												'operator'  => 'IN'
											)            
										 )
								  );
						$args1 = array_merge($args,$order_arg);
					
						$slide = null;
						remove_all_actions('posts_where');
						remove_all_actions('posts_orderby');
						remove_all_actions('pre_get_posts');
						if(is_plugin_active('Tevolution-LocationManager/location-manager.php'))
						{
							add_filter('posts_where', 'location_multicity_where');
						}
						add_filter('posts_join', 'templatic_posts_where_filter');
						$slide   = new WP_Query($args1);
						
						if(is_plugin_active('Tevolution-LocationManager/location-manager.php'))
						{
							remove_filter('posts_where', 'location_multicity_where');
						}
						remove_filter('posts_join', 'templatic_posts_where_filter');
						remove_filter('pre_get_posts', 'home_page_feature_listing',14);
 						$array_find=array(' ','.');
						$array_replace=array('','');
						if( $slide->have_posts() )
						{
							while($slide->have_posts()) : $slide->the_post();
								global $post;
								if(function_exists('bdw_get_images_plugin'))
								{ 
									$post_img = bdw_get_images_plugin($post->ID,'clasified-thumb');						
									$thumb_img = @$post_img[0]['file'];
									$attachment_id = @$post_img[0]['id'];
									$attach_data = get_post($attachment_id);
									$img_title = $attach_data->post_title;
									$img_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
								}
								if(get_post_meta($post->ID,'featured_h',true) != 'n'){
									$fclass="featured_c";
								}else{
									$fclass="";
								}
								/* Get the option where all settings save */
								$tmpdata = get_option('templatic_settings');	
								$replace = array(' ','.');
								$replace_with = array('','');
								$classified_tag =  str_replace($replace, $replace_with,get_post_meta($post->ID,'classified_tag',true));
		
								/* get classified tag text */
								$classified_tag_tax = $tmpdata['classified_tag_text_'.str_replace($array_find, $array_replace,$classified_tag)]; 
								if(!isset($classified_tag_tax) || $classified_tag_tax==''){
									$classified_tag_tax = $classified_tag;
									$ctags = $wpdb->get_row("SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'classified_tag' and $wpdb->posts.post_type = 'custom_fields'");
									if(count($ctags) != 0)
									{
										$classified_status_id = $ctags->ID;
										$values = explode(',',get_post_meta($classified_status_id,'option_values',true));
										$opt_title = explode(',',get_post_meta($classified_status_id,'option_title',true));
										/* merge two array for title and value: title as key and value as array value*/
										$tag_array = array_combine($opt_title, $values);
										if(in_array($classified_tag_tax,$tag_array)){
											/* gets an key for matched value */
											$classified_tag_tax = array_search($classified_tag_tax,$tag_array);
										}	
									}
								}
								/* get classified tag colour */
								$classified_tag_color = $tmpdata['classified_tag_color_'.str_replace(' ', '', $classified_tag)];
								if(!isset($classified_tag_color)){
									$classified_tag_color=  "#b00809";
								}
								?>
								
								<li class="<?php echo $fclass; ?>">
									<?php if($classified_tag_tax)
											echo '<span class="classified-status" style="background:'.$classified_tag_color.'">'.$classified_tag_tax.'</span>';
									?>
									<a href="<?php echo get_permalink($pos->ID); ?>">
									<?php if($thumb_img){ ?>
										<img src="<?php echo $thumb_img; ?>" alt="<?php $img_alt; ?>" title="<?php echo $img_title; ?>"/>
									<?php }else{ ?>
										<img src="http://placehold.it/140x110"/>
									<?php } ?>
									</a>
									
									<h3><a href="<?php echo get_permalink($pos->ID); ?>"><?php the_title(); ?></a></h3>
									<?php
										global $post,$htmlvar_name;
	
										$price_type = get_post_meta($post->ID,'price_type',true); 
										$classified_price = get_post_meta($post->ID,'price',true); 
										if($htmlvar_name['price']){
												echo '<span class="classified-price">'.display_amount_with_currency_plugin($classified_price).'</span>';
										}
										$for_lbl = explode(',',$htmlvar_name['price_type']['option_title']);
	
										echo ' <span class="classified-price"><span>'; echo display_amount_with_currency_plugin($classified_price).'</span></span>';
										if($for_lbl[0] !='')	
											echo '<span class="price-type">( '.$for_lbl[0]." )</span>";
										?>
								</li>
								
								<?php do_action('classified_after_post_loop');
									
							endwhile;
						}
						wp_reset_query(); ?>
					</ul>
				</div>
			</div>
		<!-- flexslider container end -->
		<?php
			echo $slider_args['after_widget'];
		}
		function update($new_instance, $old_instance)
		{
			/*save the widget*/
			return $new_instance;
		}
		function form($instance)
		{
			/*widgetform in backend*/
			$instance = wp_parse_args( (array) $instance, array('search'            =>'','search_post_type'  =>'','location'          =>'','distance'          =>'','radius'            =>'','post_type'         => '','number'            => '','animation'         =>'fade','slideshowSpeed'    =>'4700','animation_speed'   =>'800','sliding_direction' =>'','reverse'           =>'true','item_width'        =>'','is_Carousel_temp'  =>'','min_item'          =>'','max_items'         =>'','item_move'         =>'','custom_banner_temp'=>'','postperslide'      =>'','content_len'       =>'' ,'autoplay'       =>'true' ) );
			/* Widget Get Posts settings*/
			$title              = strip_tags(@$instance['title']);
			$sdesc              = strip_tags(@$instance['sdesc']);
			$post_type = $instance['post_type'];	
			/* Slider Basic Settings*/
			$autoplay = empty($instance['autoplay'])? '' : strip_tags($instance['autoplay']);
			$animation         = strip_tags($instance['animation']);
			$slideshowSpeed    = strip_tags($instance['slideshowSpeed']);
			$sliding_direction = strip_tags($instance['sliding_direction']);
			$reverse           = strip_tags($instance['reverse']);
			$animation_speed   = strip_tags($instance['animation_speed']);
			/* Carousel Slider Settings*/
			$is_Carousel       = empty($instance['is_Carousel'])? '' : strip_tags($instance['is_Carousel']);
			$item_width       = strip_tags($instance['item_width']);
			/*$item_margin = strip_tags($instance['item_margin']);*/
			$min_item         = strip_tags($instance['min_item']);
			$max_items        = strip_tags($instance['max_items']);
			$item_move        = strip_tags($instance['item_move']);
			$is_Carousel_temp = strip_tags($instance['is_Carousel_temp']);
			$item_width       = strip_tags($instance['item_width']);			
			$min_item         = strip_tags($instance['min_item']);
			$max_items        = strip_tags($instance['max_items']);
			$item_move        = strip_tags($instance['item_move']);
			$popular_per        = strip_tags($instance['popular_per']);
			$number        = strip_tags($instance['number']);
			$postperslide     = empty($instance['postperslide'])? '' : strip_tags($instance['postperslide']); ?>
		<p>
		  <label for="<?php echo $this->get_field_id('title'); ?>">
			<?php echo __('Slider Title','classifieds'); ?>
			:
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
		  </label>
		</p>
		<p>
		  <label for="<?php echo $this->get_field_id('sdesc'); ?>">
			<?php echo __('Slider Description','classifieds'); ?>
			:
			<textarea class="widefat" id="<?php echo $this->get_field_id('sdesc'); ?>" name="<?php echo $this->get_field_name('sdesc'); ?>" type="text" ><?php echo esc_attr($sdesc); ?></textarea>
		  </label>
		</p>
		<p>
		  <label for="<?php echo $this->get_field_id('autoplay'); ?>">
			<?php echo __('Slide show','classifieds'); ?>
			:
			<select class="widefat" name="<?php echo $this->get_field_name('autoplay'); ?>" id="<?php echo $this->get_field_id('autoplay'); ?>">
			  <option <?php
		 if(esc_attr($autoplay) == 'true')
		{?> selected="selected"<?php }?> value="true">
			  <?php echo __("Yes",'classifieds');?>
			  </option>
			  <option <?php
		 if(esc_attr($autoplay) == 'false')
		{?> selected="selected"<?php }?> value="false">
			  <?php echo __("No",'classifieds');?>
			  </option>
			</select>
		  </label>
		</p>
		<p>
		  <label for="<?php echo $this->get_field_id('sliding_direction'); ?>">
			<?php echo __('Sliding Direction','classifieds'); ?>
			:
			<select class="widefat" name="<?php echo $this->get_field_name('sliding_direction'); ?>" id="<?php echo $this->get_field_id('sliding_direction'); ?>">
			  <option <?php
		 if(esc_attr($sliding_direction) == 'horizontal')
		{?> selected="selected"<?php }?> value="horizontal">
			  <?php echo __("Horizontal",'classifieds');?>
			  </option>
			  <option <?php
		 if(esc_attr($sliding_direction) == 'vertical')
		{?> selected="selected"<?php }?> value="vertical">
			  <?php echo __("Vertical",'classifieds');?>
			  </option>
			</select>
		  </label>
		</p>
		<p>
		  <label for="<?php echo $this->get_field_id('reverse'); ?>">
			<?php echo __('Reverse Animation Direction','classifieds'); ?>
			:
			<select class="widefat" name="<?php echo $this->get_field_name('reverse'); ?>" id="<?php echo $this->get_field_id('reverse'); ?>">
			  <option <?php
		 if(esc_attr($reverse) == 'false')
		{?> selected="selected"<?php }?> value="false">
			  <?php echo __("False",'classifieds');?>
			  </option>
			  <option <?php
		 if(esc_attr($reverse) == 'true')
		{?> selected="selected"<?php }?> value="true">
			  <?php echo __("True",'classifieds');?>
			  </option>
			</select>
		  </label>
		</p>
		<p>
		  <label for="<?php echo $this->get_field_id('slideshowSpeed'); ?>">
			<?php echo __('Slide Show Speed','classifieds'); ?>
			:
			<input class="widefat" id="<?php echo $this->get_field_id('slideshowSpeed'); ?>" name="<?php echo $this->get_field_name('slideshowSpeed'); ?>" type="text" value="<?php echo esc_attr($slideshowSpeed); ?>" />
		  </label>
		</p>
		<p>
		  <label for="<?php echo $this->get_field_id('animation_speed'); ?>">
			<?php echo __('Animation Speed','classifieds'); ?>
			:
			<input class="widefat" id="<?php echo $this->get_field_id('animation_speed'); ?>" name="<?php echo $this->get_field_name('animation_speed'); ?>" type="text" value="<?php echo esc_attr($animation_speed); ?>" />
		  </label>
		</p>
		<!--is_Carousel -->
		<div id="<?php echo $this->get_field_id('home_slide_carousel'); ?>">
		  <p>
			<label for="<?php echo $this->get_field_id('item_width'); ?>">
			  <?php echo __('Item Width','classifieds').' <br/><small>'.__('(Box-model width of individual items, including horizontal borders and padding.)','classifieds').'</small>'; ?>
			  <input class="widefat" id="<?php echo $this->get_field_id('item_width'); ?>" name="<?php echo $this->get_field_name('item_width'); ?>" type="text" value="<?php echo esc_attr($item_width); ?>" />
			</label>
		  </p> 		  
		  <p>
			<label for="<?php echo $this->get_field_id('min_item'); ?>">
			  <?php echo __('Min Item','classifieds').' <br/><small>'.__('(Minimum number of items that should be visible. Items will resize fluidly when below this.)','classifieds').'</small>'; ?>
			  <input class="widefat" id="<?php echo $this->get_field_id('min_item'); ?>" name="<?php echo $this->get_field_name('min_item'); ?>" type="text" value="<?php echo esc_attr($min_item); ?>" />
			</label>
		  </p>
		  <p>
			<label for="<?php echo $this->get_field_id('max_items'); ?>">
			  <?php echo __('Max Item','classifieds').' <br/><small>'.__('(Maximum number of items that should be visible. Items will resize fluidly when above this limit.)','classifieds').'</small>'; ?>
			  <input class="widefat" id="<?php echo $this->get_field_id('max_items'); ?>" name="<?php echo $this->get_field_name('max_items'); ?>" type="text" value="<?php echo esc_attr($max_items); ?>" />
			</label>
		  </p>
		  <p>
			<label for="<?php echo $this->get_field_id('item_move'); ?>">
			  <?php echo __('Items Move','classifieds').' <br/><small>'.__('(Number of items that should move on animation. If 0, slider will move all visible items.)','classifieds').'</small>'; ?>
			  <input class="widefat" id="<?php echo $this->get_field_id('item_move'); ?>" name="<?php echo $this->get_field_name('item_move'); ?>" type="text" value="<?php echo esc_attr($item_move); ?>" />
			</label>
		  </p>
		  <?php
						if(current_theme_supports('postperslide')): ?>
		  <p>
			<label for="<?php echo $this->get_field_id('postperslide'); ?>">
			  <?php echo __('Posts Per Slide','classifieds').' <br/><small>'.__('Number of items you want to show in one slide. this option is work with LI tag, it will show all images in one LI tag.','classifieds').' </small>'; ?>
			  <input class="widefat" id="<?php echo $this->get_field_id('postperslide'); ?>" name="<?php echo $this->get_field_name('postperslide'); ?>" type="text" value="<?php echo esc_attr($postperslide); ?>" />
			</label>
		  </p>
		  <?php endif; ?>
		</div>

		<!-- Finish is_Carousel -->
		<div id="<?php echo $this->get_field_id('home_slide_default_temp'); ?>">
		<p>
		<label for="<?php echo $this->get_field_id('post_type');?>" >
		<?php echo __('Select Category','classifieds');?>
		<select id="<?php echo $this->get_field_id('post_type'); ?>" name="<?php echo $this->get_field_name('post_type'); ?>[]" class="widefat"  multiple="multiple" size="8">
        <?php $taxonomies = get_taxonomies( array( 'public' => true ), 'objects' );
						foreach ( $taxonomies as $taxonomy ) {	
							$query_label = '';
							if ( !empty( $taxonomy->query_var ) )
								$query_label = $taxonomy->query_var;
							else
								$query_label = $taxonomy->name;
							
							if($taxonomy->labels->name!='Tags' && $taxonomy->labels->name!='Format' && !strstr($taxonomy->labels->name,'tag') && !strstr($taxonomy->labels->name,'Tags') && !strstr($taxonomy->labels->name,'format') && !strstr($taxonomy->labels->name,'Shipping Classes')&& !strstr($taxonomy->labels->name,'Order statuses')&& !strstr($taxonomy->labels->name,'genre')&& !strstr($taxonomy->labels->name,'platform') && !strstr($taxonomy->labels->name,'colour') && !strstr($taxonomy->labels->name,'size')):	
								?>
							<optgroup label="<?php echo esc_attr( $taxonomy->object_type[0])."-".esc_attr($taxonomy->labels->name); ?>">
							<?php
												$terms = get_terms( $taxonomy->name, 'orderby=name&hide_empty=0' );
												foreach ( $terms as $term ) {		
												$term_value=esc_attr($taxonomy->object_type[0]). ',' .$term->term_id.','.$query_label;
							?>
        <!--<option style="margin-left: 8px; padding-right:10px;" value="<?php echo $term_value ?>" <?php if($post_type==$term_value) echo "selected";?>><?php echo '-' . esc_attr( $term->name ); ?></option>-->
								<option style="margin-left: 8px; padding-right:10px;" value="<?php echo $term_value ?>" <?php if(isset($term_value) && !empty($post_type) && in_array(trim($term_value),$post_type)) echo "selected";?>><?php echo '-' . esc_attr( $term->name ); ?></option>
							<?php } ?>
							</optgroup>
							<?php
								endif;
						}?>
		</select>
		</label>
		<small>
		<?php echo __('Select the categories from the post types.','classifieds');?>
		</small> 
		</p>
		<p>
		<label for="<?php  echo $this->get_field_id('popular_per'); ?>"><?php echo __('Shows post as per view counting/comments','classifieds');?>:
			<select class="widefat" id="<?php  echo $this->get_field_id('popular_per'); ?>" onchange="show_hide_info(this.value,'<?php echo $this->get_field_id('daily_view'); ?>')" name="<?php echo $this->get_field_name('popular_per'); ?>">
			  <option value="featured" <?php
		 if($instance['popular_per'] == 'featured')
		{ ?>selected='selected'<?php } ?>>
			  <?php echo __('Featured List','classifieds'); ?>
			  </option>
			  <option value="views" <?php
		 if($instance['popular_per'] == 'views')
		{ ?>selected='selected'<?php } ?>>
			  <?php echo __('Total views','classifieds'); ?>
			  </option>
			  <option value="dailyviews" <?php
		 if($instance['popular_per'] == 'dailyviews')
		{ ?>selected='selected'<?php } ?>>
			  <?php echo __('Daily views','classifieds'); ?>
			  </option>
			  <option value="comments" <?php
		 if($instance['popular_per'] == 'comments')
		{ ?>selected='selected'<?php } ?>>
			  <?php echo __('Total comments','classifieds'); ?>
			  </option>
			</select>
		  </label>
		</p>
		<p>
		<label for="<?php echo $this->get_field_id('number'); ?>">
		  <?php echo __('Number of posts:','classifieds');?>
		  <input class="widefat" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo esc_attr($number); ?>" />
		</label>
		</p>
		<p>
		<label for="<?php echo $this->get_field_id('content_len'); ?>">
		  <?php echo __('Excerpt Length:','classifieds');?>
		  <input class="widefat" id="<?php echo $this->get_field_id('content_len'); ?>" name="<?php echo $this->get_field_name('content_len'); ?>" type="text" value="<?php echo esc_attr($content_len); ?>" />
		</label>
	  </p>
	</div>
<?php	}
}
?>