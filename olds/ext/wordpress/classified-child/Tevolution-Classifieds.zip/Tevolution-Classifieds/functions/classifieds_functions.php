<?php
/* * **************** Category page hook ******************* */

/* 	display the classifieds category sub categories */

add_action('classified_subcategory', 'tmpl_classifieds_subcategory');

function tmpl_classifieds_subcategory() {
          global $wpdb, $wp_query;
          $term_id = $wp_query->get_queried_object_id();
          $taxonomy_name = $wp_query->queried_object->taxonomy;
          do_action('tevolution_category_query');
          $featured_catlist_list = wp_list_categories('title_li=&child_of=' . $term_id . '&echo=0&taxonomy=' . $taxonomy_name . '&show_count=0&hide_empty=1&pad_counts=0&show_option_none=&orderby=name&order=ASC');
          if (is_plugin_active('Tevolution-LocationManager/location-manager.php')) {
                    remove_filter('terms_clauses', 'locationwise_change_category_query', 10, 3);
          }
          if (!strstr(@$featured_catlist_list, 'No categories') && !empty($featured_catlist_list)) {
                    echo '<div id="sub_listing_categories">';
                    echo '<ul>';
                    echo $featured_catlist_list;
                    echo '</ul>';
                    echo '</div>';
          }
}

/* Add list view / grid view and sorting options on listing page of classified  */
add_action('classified_before_loop_taxonomy', 'tmpl_classified_sorting');

function tmpl_classified_sorting() {
          global $wpdb, $wp_query;
          if ($wp_query->found_posts == 0 && (!isset($_REQUEST['classified_sortby'])))
                    return '';

          $templatic_settings = get_option('templatic_settings');
          $googlemap_setting = get_option('city_googlemap_setting');
          ?>
          <div class="classified-short clearfix">
               <span><?php _e('Sort by', 'classifieds'); ?></span>
               <div class="short-option">
                    <?php
                    if (!is_tax() && is_archive() && !is_search()) {
                              $pageURL = get_post_type_archive_link('classified');
                    } elseif (is_search()) {
                              $search_query_str = str_replace('&classified_sortby=alphabetical&sortby=' . @$_REQUEST['sortby'], '', $_SERVER['QUERY_STRING']);
                              $pageURL = site_url() . "?" . $search_query_str;
                    } else {
                              $current_term = $wp_query->get_queried_object();
                              $pageURL = ($current_term->slug) ? get_term_link($current_term->slug, $current_term->taxonomy) : '';
                    }
                    /* title on click ordering */

                    if (isset($_REQUEST['classified_sortby']) && $_REQUEST['classified_sortby'] == 'title_asc') {
                              if (strstr($pageURL, "?"))
                                        $title_order = $pageURL . '&amp;classified_sortby=title_desc';
                              else
                                        $title_order = $pageURL . '?classified_sortby=title_desc';
                              $icon = '<i class="fa fa-caret-up"></i>';
                              $tclass = "active";
                    }else {
                              //if((isset($_REQUEST['classified_sortby']) && $_REQUEST['classified_sortby'] =='title_desc') || @$_REQUEST['classified_sortby'] =='')
                              {
                                        if (strstr($pageURL, "?"))
                                                  $title_order = $pageURL . '&amp;classified_sortby=title_asc';
                                        else
                                                  $title_order = $pageURL . '?classified_sortby=title_asc';
                              }
                              $icon = '<i class="fa fa-caret-down"></i>';
                              $tclass = "";
                    }
                    if (isset($_REQUEST['classified_sortby']) && ($_REQUEST['classified_sortby'] == 'title_desc' || $_REQUEST['classified_sortby'] == 'title_asc')) {
                              $tclass = "active";
                    } else {
                              $tclass = "";
                    }
                    ?>
                    <span class="short-title"><a href="<?php echo $title_order; ?>" class="<?php echo $tclass; ?>" onclick="tmpl_sort_as_set('<?php echo $title_order; ?>')"><?php _e('Title', 'classifieds');
          echo " " . $icon;
                    ?></a></span>
                    <?php
                    /* Date on click ordering */
                    if (isset($_REQUEST['classified_sortby']) && $_REQUEST['classified_sortby'] == 'date_desc') {
                              if (strstr($pageURL, "?"))
                                        $date_order = $pageURL . '&amp;classified_sortby=date_asc';
                              else
                                        $date_order = $pageURL . '?classified_sortby=date_asc';

                              $date_icon = '<i class="fa fa-caret-up"></i>';
                              $dclass = "active";
                    }else {
                              if (strstr($pageURL, "?"))
                                        $date_order = $pageURL . '&amp;classified_sortby=date_desc';
                              else
                                        $date_order = $pageURL . '?classified_sortby=date_desc';
                              $date_icon = '<i class="fa fa-caret-down"></i>';
                              $dclass = "";
                    }
                    if (isset($_REQUEST['classified_sortby']) && ($_REQUEST['classified_sortby'] == 'date_desc' || $_REQUEST['classified_sortby'] == 'date_asc')) {
                              $dclass = "active";
                    } else {
                              $dclass = "";
                    }
                    ?>
                    <span class="short-date"><a href="<?php echo $date_order; ?>" class="<?php echo $dclass; ?>"><?php _e('Date', 'classifieds');
                    echo " " . $date_icon;
                    ?></a></span>
                    <?php
                    /* Date on click ordering */
                    if (isset($_REQUEST['classified_sortby']) && $_REQUEST['classified_sortby'] == 'price_low_high') {
                              if (strstr($pageURL, "?"))
                                        $price_order = $pageURL . '&amp;classified_sortby=price_high_low';
                              else
                                        $price_order = $pageURL . '?classified_sortby=price_high_low';


                              $price_icon = '<i class="fa fa-caret-up"></i>';
                              $pclass = "active";
                    }else {
                              if (strstr($pageURL, "?"))
                                        $price_order = $pageURL . '&amp;classified_sortby=price_low_high';
                              else
                                        $price_order = $pageURL . '?classified_sortby=price_low_high';

                              $price_icon = '<i class="fa fa-caret-down"></i>';
                              $pclass = "";
                    }
                    if (isset($_REQUEST['classified_sortby']) && ($_REQUEST['classified_sortby'] == 'price_high_low' || $_REQUEST['classified_sortby'] == 'price_low_high')) {
                              $pclass = "active";
                    } else {
                              $pclass = "";
                    }
                    ?>
                    <span class="short-price"><a href="<?php echo $price_order; ?>" class="<?php echo $pclass; ?>"><?php _e('Price', 'classifieds');
                    echo " " . $price_icon;
                    ?></a></span>
               </div>
          </div>
          <?php
}

add_action('classified_post_info', 'tmpl_classified_information');

function tmpl_classified_information() {
          global $post, $htmlvar_name, $multicity_table, $wpdb;
          $post_class = $post;
          $post_type = get_post_type();

          if (!empty($htmlvar_name))
                    $htmlvar_name = $htmlvar_name;
          else
                    global $htmlvar_name;


          if (isset($_REQUEST['custom_post']) && $_REQUEST['custom_post'] != '') {
                    $post_type = $_REQUEST['custom_post'];
          }
          $post_id = $post->ID;

          /* get all the custom fields which select as " Show field on listing page" from back end */
          if (empty($htmlvar_name)) {
                    $htmlvar_name = tmpl_get_category_list_customfields($post_type);
          }

          $address = get_post_meta($post->ID, 'address', true);
          $owner_name = get_post_meta($post->ID, 'owner_name', true);
          $website = get_post_meta($post->ID, 'web_site', true);
          $multicity_table = $wpdb->prefix . "multicity";
          $post = $post_class;
          echo "<div class='classified-tax-detail clearfix'>";
          /* get agent phone number */
          $user_phone = get_user_meta($post->post_author, 'user_phone', true);
          /* get the categories */
          do_action('templ_classifieds_taxonomies');



          if ($htmlvar_name['owner_name'] && $owner_name != '') {
                    if ($htmlvar_name['web_site'] && $website != '') {
                              echo '<p class="owner_name"><label>' . __('By', 'classifieds') . ' </label> <a href="' . $website . '"> ' . $owner_name . '</a></p>';
                    } elseif ($website == '') {
                              echo '<p class="owner_name"><label>' . __('By', 'classifieds') . ' </label> <a href="' . get_author_posts_url($post->post_author) . '"> ' . $owner_name . '</a></p>';
                    } else {
                              echo '<p class="owner_name"><label>' . __('By', 'classifieds') . ' </label> ' . $owner_name . '</p>';
                    }
          }
          /* Display ratings on sitting */
          do_action('tmpl_classified_ratings');

          /* display  City name / address */

          $city_id = get_post_meta($post->ID, 'post_city_id', true);
          if ($htmlvar_name['address'] && $city_id != '' && is_plugin_active('Tevolution-LocationManager/location-manager.php')) {
                    $sql = "SELECT GROUP_CONCAT(cityname) as cityname FROM $multicity_table where city_id in(" . $city_id . ")";
                    $cityname = $wpdb->get_var($sql);
                    echo '<div class="address"><label>' . __('In', 'classifieds') . ' </label> ' . preg_replace('/(?<!\d),|,(?!\d{3})/', ', ', $cityname) . '</div>';
          }
          $j = 0;
          if (!empty($htmlvar_name)) {
                    echo "<ul class='other_custom_fields'>";
                    $i = 0;
                    foreach ($htmlvar_name as $key => $value) {
							$field = get_post_meta($post->ID, $key, true);	
                              if (isset($value) && $value != ''  && !empty($field)) {

                                        $key = ($key == 'basic_inf') ? __('classified Information', 'classifieds') : $key;
                                        if ($key != 'post_title' && $key != 'price_type' && $key != 'category' && $key != 'post_content' && $key != 'post_excerpt' && $key != 'post_images' && $key != 'listing_timing' && $key != 'address' && $key != 'listing_logo' && $key != 'video' && $key != 'post_tags' && $key != 'map_view' && $key != 'proprty_feature' && $key != 'email' && $key != 'website' && $key != 'twitter' && $key != 'facebook' && $key != 'google_plus' && $key != 'post_city_id' && $key != 'contact_info' && $key != 'classified_tag' && $key != 'area' && $key != 'classified_type' && $key != 'classified_status' && $key != 'owner_name' && $key != 'price' && $key != 'web_site') {
                                                  if ($i == 0) {
														/* Show locations informations - country/state/city */
														if ($htmlvar_name['post_city_id'] && $htmlvar_name['post_city_id']['type'] == 'multicity') {
															  global $wpdb, $country_table, $zones_table, $multicity_table;

															  $city = get_post_meta($post->ID, 'post_city_id', true);
															  $zones_id = get_post_meta($post->ID, 'zones_id', true);
															  $country_id = get_post_meta($post->ID, 'country_id', true);
															  $cityinfo = $wpdb->get_results($wpdb->prepare("select cityname from $multicity_table where city_id =%d", $city));
															  if ($country_id != '')
																		$countryinfo = $wpdb->get_results($wpdb->prepare("select country_name from $country_table where country_id =%d", $country_id));
															  if ($zones_id != '')
																		$zoneinfo = $wpdb->get_results($wpdb->prepare("select zone_name from $zones_table where zones_id =%d", $zones_id));

															  if ($countryinfo[0]->country_name) {
																		?><p class='<?php echo $value['style_class']; ?>'><label><?php _e('Country', 'classifieds'); ?>:</label> <strong><span><?php echo $countryinfo[0]->country_name; ?></span></strong></p>
															  <?php
															  }
															  if ($zoneinfo[0]->zone_name) {
																		?>
																		<p class='<?php echo $value['style_class']; ?>'><label><?php _e('State', 'classifieds'); ?>:</label> <strong><span><?php echo $zoneinfo[0]->zone_name; ?></span></strong></p>
															  <?php
															  }
															  if ($cityinfo[0]->cityname) {
																		?>
																		<p class='<?php echo $value['style_class']; ?>'><label><?php _e('City', 'classifieds'); ?>:</label> <strong><span><?php echo $cityinfo[0]->cityname; ?></span></strong></p>
																		<?php
															  }
														}
                                                  }
                                                  if ($value['type'] == 'multicheckbox' && $field != ""):
												  
												  /* get the title array */
													$title_arr = explode(',',$value['option_title']);
													/* get values array */
													$value_arr = explode(',',$value['option_values']);
													/* combine  title as a key and values as value in array */
													$final_arr = array_combine($title_arr,$value_arr);
													/* get the common array value by comparing database valued array and combined array */
													$value2 = $field;
													$field = array_intersect($final_arr,$value2);
													/* show key from array as it's key is taken as a title and show it in tab */
													if(!empty($field))
													{
														$value1 = '';
														foreach($field as $key=>$val)
														{
															$value1 .= $key.', ';
														}
													}
													/* remove ,(comma) from last value */
													$field = rtrim($value1,', ');
												  
                                                            ?>
                                                            <li class='<?php echo $value['style_class']; ?>'><label><?php echo $value['label']; ?></label>: <?php echo $field; ?></li>
                                                            <?php
												  elseif ($value['type'] == 'radio' && $field != ''):
												  /* get the title array */
													$title_arr =  explode(',',$value['option_title']);
													/* get values array */
													$value_arr = explode(',',$value['option_values']);
													/* combine  title as a key and values as value in array */
													$final_arr = array_combine($title_arr,$value_arr);
													/* get value from database which is in array form */
													$value2 = $field;
													/* get compared value's key from array as key is the title in combined array */
													$field = array_search($value2,$final_arr);
                                                            ?>                              
                                                            <li class='<?php echo $value['style_class']; ?>'><label><?php echo $value['label']; ?></label>: <?php echo $field; ?></li>
                                                            <?php
                                                  else:
                                                            ?>                              
                                                            <li class='<?php echo $value['style_class']; ?>'><label><?php echo $value['label']; ?></label>: <?php echo $field; ?></li>
                                                            <?php
                                                  endif;
                                                  $i++;
                                        }
                              }

                              $j++;
                    }
                    echo "</ul>";
          }
          echo "</div>";
}

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );	
/* shows post images when directory plugin is deactivate for home page listing widget. */
if(!is_plugin_active('Tevolution-Directory/directory.php')){
	add_action('directory_category_page_image','tmpl_classified_category_page_image');
}
/*
  Display the classified featured image on category page
 */
add_action('classified_category_page_image', 'tmpl_classified_category_page_image');

function tmpl_classified_category_page_image() {
          global $post, $wpdb, $wp_query, $htmlvar_name;

          $post_id = get_the_ID();

          $featured = get_post_meta($post_id, 'featured_c', true);
          $featured = ($featured == 'c') ? 'featured_c' : '';
          if (has_post_thumbnail()):
                    /* Get the featured image */
                    $post_img = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'adv_listings-thumb');
                    $thumb_img = @$post_img[0];
          else:
                    if (function_exists('bdw_get_images_plugin')) {
                              $post_img = bdw_get_images_plugin($post_id, 'adv_listings-thumb');
                              $thumb_img = apply_filters('tmpl_thumb_image',$post_img[0]['file']);
                              $attachment_id = @$post_img[0]['id'];
                              $attach_data = get_post($attachment_id);
                              $img_title = $attach_data->post_title;
                              $img_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
                    }
          endif;
          /* Get the classified Price */
          $classified_price = get_post_meta($post->ID, 'price', true);


          /* Get the option where all settings save */
          $tmpdata = get_option('templatic_settings');

          $replace = array(' ', '.');
          $replace_with = array('', '');
          $classified_tag = str_replace($replace, $replace_with, get_post_meta($post->ID, 'classified_tag', true));

          /* get classified tag text */
          $classified_tag_tax = $tmpdata['classified_tag_text_' . str_replace(' ', '', $classified_tag)];
          if (!isset($classified_tag_tax) || empty($classified_tag_tax)) {
                    $classified_tag_tax = $classified_tag;
                    $ctags = $wpdb->get_row("SELECT post_title,ID FROM $wpdb->posts WHERE $wpdb->posts.post_name = 'classified_tag' and $wpdb->posts.post_type = 'custom_fields'");
                    if (count($ctags) != 0) {
                              $classified_status_id = $ctags->ID;
                              $values = explode(',', get_post_meta($classified_status_id, 'option_values', true));
                              $opt_title = explode(',', get_post_meta($classified_status_id, 'option_title', true));
                              /* merge two array for title and value: title as key and value as array value */
                              $tag_array = array_combine($opt_title, $values);
                              if (in_array($classified_tag_tax, $tag_array)) {
                                        /* gets an key for matched value */
                                        $classified_tag_tax = array_search($classified_tag_tax, $tag_array);
                              }
                    }
          }
          /* get classified tag colour */

          $classified_tag_color = $tmpdata['classified_tag_color_' . str_replace(' ', '', $classified_tag)];
          if (!isset($classified_tag_color)) {
                    $classified_tag_color = '#0165BD';
          }
		  
          ?>
          <!-- classified image start -->
          <div class="classified_img">
               <?php
              
               $featured = get_post_meta(get_the_ID(), 'featured_c', true);
               $featured = ($featured == 'c') ? 'featured_c' : '';
               ?>
               <a href="<?php the_permalink(); ?>" >
                    <?php
                     if ($classified_tag_tax)
                         echo '<span class="classified-status" style="background:' . $classified_tag_color . '">' . $classified_tag_tax . '</span>';
                    /* show featured image if listing is featured */
                    if ($featured) {
                              echo '<span class="featured_tag">';
                              _e('Featured', 'classifieds');
                              echo '</span>';
                    }
                    if ($thumb_img):
                              ?>
                              <img src="<?php echo $thumb_img; ?>"  alt="<?php echo $img_alt; ?>" title="<?php echo $img_title; ?>" />
          <?php else: ?>    
                              <img src="http://placehold.it/250x196" alt=""  />
          <?php endif;
          ?>
               </a>
			   <?php do_action('after_entry_image'); ?>
          </div>
          <!-- classified image end -->
          <?php
}

/* Show the add to favourites,comments and pinpoint  */
add_action('classified_after_post_entry', 'tmpl_show_classified_favourite_html');

/* add filter for show favorite in author page */
add_action('directory_after_taxonomies','tmpl_show_classified_favourite_html');

function tmpl_show_classified_favourite_html() {
          global $post, $htmlvar_name, $templatic_settings;
          $is_archive = get_query_var('is_ajax_archive');
          $is_related = get_query_var('is_related');
		  $tmpdata = get_option('templatic_settings');
          if (in_array($post->post_type, array('classified'))) {
                    echo '<div class="rev_pin">';
                    echo '<ul>';
                    $post_id = get_the_ID();
                    $googlemap_setting = get_option('city_googlemap_setting');
                    $comment_count = count(get_comments(array('post_id' => $post_id, 'status' => 'approve')));
                    $review = ($comment_count <= 1 ) ? __('review', 'classifieds') : __('reviews', 'classifieds');
                    $review = apply_filters('tev_review_text', $review);
                    ?>
                    <?php if (current_theme_supports('tevolution_my_favourites')): ?> 
                              <li class="favourite"><?php tevolution_favourite_html(); ?></li>
                              <?php
                    endif;

                    /* to display the comment count on widget and listings of classifeids, if don;t want some where simply remove filter "classified_after_post_entry" from child theme */
                    if (get_option('default_comment_status') == 'open' || $post->comment_status == 'open') {
                              ?>
                              <li class="review"> <?php echo '<a href="' . get_permalink($post_id) . '#comments">' . $comment_count . ' ' . $review . '</a>'; ?></li>
                              <?php
                    }

                    echo '</ul>';
                    /* view more details link  for grid view */
                    $tmpdata = get_option('directory_theme_settings');
                    if (isset($tmpdata['templatic_excerpt_link']) && $tmpdata['templatic_excerpt_link'] && (isset($tmpdata['default_page_view']) && $tmpdata['default_page_view']!="gridview")) {
                              echo '<a href=' . get_permalink($post->ID) . ' class="moretag">' . $tmpdata['templatic_excerpt_link'] . '</a>';
                    }
                    echo '</div>';
          }
}

/* Show the date in list view of classified */
add_action('templ_classified_post_date', 'tmpl_classified_cattitle_right_date');

function tmpl_classified_cattitle_right_date() {
          global $post;
          if ($post->post_type == CUSTOM_POST_TYPE_CLASSIFIED) {
                    /* Date format - show last updated */
                    echo '<span class="last-updated">';
                    /* _e('Posted','classifieds'); */
                    echo mysql2date(get_option('date_format'), $post->post_date);
                    echo "</span>";
          }
}

/* Show the price in list view of classified */
add_action('templ_classified_post_title', 'tmpl_classified_cattitle_right',10,1);

function tmpl_classified_cattitle_right($htmlvar_name = '') {
          global $post;
		  if(!empty($htmlvar_name))
			 $htmlvar_name =  $htmlvar_name;
		  else
			global  $htmlvar_name;	
		  	
          $price_type = get_post_meta($post->ID, 'price_type', true);
          $classified_price = get_post_meta($post->ID, 'price', true);
          $for_lbl = explode(',', @$htmlvar_name['price_type']['option_title']);

          $for_lbl_value = explode(',', $htmlvar_name['price_type']['option_values']);
          $for_lbl = explode(',', $htmlvar_name['price_type']['option_title']);
          for ($i = 0; $i < count($for_lbl_value); $i++) {
                    if ($for_lbl_value[$i] == $price_type) {
                              $price_type = $for_lbl[$i];
                              break;
                    }
          }
          if ($post->post_type == CUSTOM_POST_TYPE_CLASSIFIED) {
                   
                    if (@$htmlvar_name['price']) {
						echo '<span class="classified-price">';
                            echo '<span class="cls-price-wrapper">' . display_amount_with_currency_plugin($classified_price) . '</span>';
						echo '</span>';
                    }
                    if ($price_type != '' && $htmlvar_name['price_type']['option_values']) {
						echo '<span class="classified-price">';
                            echo '<span class="price-type">( ' . $price_type . " )</span>";
						echo '</span>';	  
                    }
          }
}

/* Add the ratings on category page */
add_action('tmpl_classified_ratings', 'tevolution_listing_after_title');

/* Make the tabs work on detail page */
add_action('wp_head', 'tmpl_classified_tabs_script');

function tmpl_classified_tabs_script() {
          if ((is_home() || is_front_page()) && !tmpl_wp_is_mobile()) {
                    add_action('templ_post_title', 'tmpl_classified_cattitle_right');
          }

          if (function_exists('tevolution_get_post_type'))
                    $custom_post_type = tevolution_get_post_type();

          if ((is_archive() || is_tax()) && get_post_type() == CUSTOM_POST_TYPE_CLASSIFIED && !is_author()) {
                    wp_enqueue_script('classified-cookies-script', TEVOLUTION_CLASSIFIEDS_URL . 'js/jquery_cookies.js', array('jquery'), '', false);
          }

          if ((is_single() || is_singular()) && get_post_type() == CUSTOM_POST_TYPE_CLASSIFIED && get_post_type() != CUSTOM_POST_TYPE_LISTING) {
                    wp_enqueue_script('jquery-ui-tabs');
                    ?>
                    <script type="text/javascript">
                              jQuery(function () {
                                   jQuery('#image_gallery a').lightBox();
                              });

                              jQuery('#tabs').bind('tabsshow', function (event, ui) {
                                   if (ui.panel.id == "locations_map") {
                                        google.maps.event.trigger(Demo.map, 'resize');
                                        Demo.map.setCenter(Demo.map.center); /* be sure to reset the map center as well*/
                                        Demo.init();
                                   }
                              });
                              jQuery(function () {
                                   jQuery('#tabs').tabs({
                                        activate: function (event, ui) {
                                             /*console.log(event);*/
                                             var panel = jQuery(".ui-state-active a").attr("href");
                                             if (panel == '#locations_map') {
                                                  google.maps.event.trigger(Demo.map, 'resize');
                                                  Demo.map.setCenter(Demo.map.center); /* be sure to reset the map center as well*/
                                                  Demo.init();
                                             }
                                        }
                                   });
                              });
                    </script>
                    <?php
          }
}

/* Hook to display the map on category page - below header section */

add_action('before_main', 'tmpl_classified_theme_before_main');

function tmpl_classified_theme_before_main() {

          global $post;
          if (!is_single() && !is_author() && !is_home()) {
				$tmpdata = get_option('templatic_settings');
				{
					  $map_class = ($tmpdata['google_map_full_width'] == 'yes') ? 'map_full_width' : 'map_fixed_width';

					  $custom_post_type = CUSTOM_POST_TYPE_CLASSIFIED;

					  if (get_post_type() == CUSTOM_POST_TYPE_CLASSIFIED) {
								remove_action('after_classified_header', 'tmpl_after_classified_header');
								if (is_active_sidebar('after_classifiedscategory_header')) :
										  ?>
										  <div id="category-widget" class="category-widget">
										  <?php dynamic_sidebar('after_classifiedscategory_header'); ?>
										  </div>
										  <?php
								endif;
					  }
				}
          }
}

/*
 * Add action display post categories and tag before the post comments
 */
add_action('templ_classifieds_taxonomies', 'tmpl_classified_post_categories_tags');

function tmpl_classified_post_categories_tags() {

          global $post, $htmlvar_name;
          $taxonomies = get_object_taxonomies((object) array('post_type' => $post->post_type, 'public' => true, '_builtin' => true));
          $terms = get_the_terms($post->ID, $taxonomies[0]);
          $sep = ",";
          $i = 0;
          $taxonomy_category = '';
          if (!empty($terms)) {
                    foreach ($terms as $term) {

                              if ($i == ( count($terms) - 1)) {
                                        $sep = '';
                              } elseif ($i == ( count($terms) - 2)) {
                                        $sep = ',';
                              }
                              $term_link = get_term_link($term, $taxonomies[0]);
                              if (is_wp_error($term_link))
                                        continue;
                              $taxonomy_category .= '<a href="' . $term_link . '">' . $term->name . '</a>' . $sep . ' ';
                              $i++;
                    }
          }

          if (!empty($terms) && (!empty($htmlvar_name['basic_inf']['category']) || !empty($htmlvar_name['category'])) && is_string($taxonomy_category)) {
                    $taxonomy_category = explode(',', $taxonomy_category);
                    echo '<p class="bottom_line i_category">';
                    echo $taxonomy_category[0];
                    echo '</p>';
          }
}

/* sorting options for category page and archive page */

add_action('tmpl_before_sortby_title_alphabetical', 'tmpl_sorting_for_classifieds');

function tmpl_sorting_for_classifieds() {
          global $wpdb, $wp_query, $sort_post_type;
          $templatic_settings = get_option('templatic_settings');

          /* Permalink */
          $sel_sort_by = $_REQUEST[$sort_post_type . '_sortby'];
          $sel_class = 'class="init"';

          if (!is_search()) {
                    $post_type = (get_post_type() != '') ? get_post_type() : get_query_var('post_type');
                    $sort_post_type = apply_filters('tmpl_tev_sorting_for_' . $post_type, $post_type);
          } else {
                    /* on search page what happens if user search with multiple post types */
                    if (isset($_REQUEST['post_type'])) {
                              if (is_array($_REQUEST['post_type']) && count($_REQUEST['post_type']) == 1) {
                                        $sort_post_type = $_REQUEST['post_type'][0];
                              } else {
                                        $sort_post_type = $_REQUEST['post_type'];
                              }
                    }
                    if (!$cur_post_type) {
                              $sort_post_type = 'directory';
                    }
          }

          $sel_sort_by = $_REQUEST[$sort_post_type . '_sortby'];
          $sel_class = 'selected=selected';
          if (get_post_type() == CUSTOM_POST_TYPE_CLASSIFIED) {

                    if (!empty($templatic_settings['sorting_option']) && in_array('classifieds_price_low_high', $templatic_settings['sorting_option'])):
                              ?>
                              <option value="price_low_high" <?php
                              if ($sel_sort_by == 'price_low_high') {
                                        echo $sel_class;
                              }
                              ?>><?php _e('Price low to high', 'classifieds'); ?></option>
                            <?php
                            endif;

                            if (!empty($templatic_settings['sorting_option']) && in_array('classifieds_price_high_low', $templatic_settings['sorting_option'])):
                                      ?>
                              <option value="price_high_low" <?php
                                      if ($sel_sort_by == 'price_high_low') {
                                                echo $sel_class;
                                      }
                                      ?>><?php _e('Price high to low', 'classifieds'); ?></option>
                                      <?php
                            endif;
                  }
        }

        /*         * ************************************* Classifieds Detail page Hooks ************************************************ */

        /* direction map on detail page */
        add_action('classified_single_page_map', 'tmpl_classified_single_googlemap');

        function tmpl_classified_single_googlemap() {
                  global $post, $templatic_settings,$tmpl_flds_varname;
                  $templatic_settings = get_option('templatic_settings');

                  if (is_single() && $templatic_settings['direction_map'] == 'yes') {

                            $post_id = get_the_ID();
                            if (get_post_meta($post_id, '_event_id', true)) {
                                      $post_id = get_post_meta($post_id, '_event_id', true);
                            }
                            $geo_latitude = get_post_meta($post_id, 'geo_latitude', true);
                            $geo_longitude = get_post_meta($post_id, 'geo_longitude', true);
                            $address = get_post_meta($post_id, 'address', true);
                            $map_type = get_post_meta($post_id, 'map_view', true);
                            $zooming_factor = get_post_meta(get_the_ID(), 'zooming_factor', true);
                            if ($address && $tmpl_flds_varname['address']) {
                                      ?>
                              <div id="classified_location_map" style="width:100%;">
                                   <div class="classified_location_map" id="classified_location_map_id" style="width:100%;"> 
                              <?php include_once (TEMPL_MONETIZE_FOLDER_PATH . 'templatic-custom_fields/google_map_detail.php'); ?> 
                                   </div>  <!-- Google map #end -->
                              </div>
                              <?php
                    }
          }
}

/* display the detail page slider left */

add_action('tmpl_classified_info_left', 'tmpl_classified_info_left_fun');

function tmpl_classified_info_left_fun() {

          global $post;
          ?>
          <!-- Image Gallery Div --> 
          <?php
          if (function_exists('bdw_get_images_plugin') && (isset($_REQUEST['pid']) && $_REQUEST['pid'] != '')) {
                    $post_img = bdw_get_images_plugin($_REQUEST['pid'], 'large');
                    $postimg_thumbnail = bdw_get_images_plugin($_REQUEST['pid'], 'thumbnail');
                    $more_listing_img = bdw_get_images_plugin($_REQUEST['pid'], 'tevolution_thumbnail');
                    $thumb_img = apply_filters('tmpl_thumb_image',$post_img[0]['file']);
                    $attachment_id = $post_img[0]['id'];
                    $attach_data = get_post($attachment_id);
                    $img_title = $attach_data->post_title;
                    $img_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
          }
          $is_edit = '';
          if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'edit') {
                    $is_edit = 1;
          }
          /* Image gallery on preview page */
          if (isset($_REQUEST['ptype']) && $_REQUEST['ptype'] == 'preview') {
                    if (!is_array($_REQUEST['imgarr']))
                              $_REQUEST['imgarr'] = explode(",", $_REQUEST['imgarr']);

                    if ($_REQUEST['imgarr']):
                              ?>
                              <div id="classified_detail_img" class="entry-header-image">

                                             <?php
                                             do_action('directory_before_post_image');

                                             if ($is_edit == ""):
                                                       ?>
                                             <div id="slider" class="listing-image flexslider frontend_edit_image">    

                                                  <ul class="slides-preview">
                                                       <?php
                                                       if (!empty($_REQUEST['imgarr'])):
                                                                 $i = 0;
                                                                 foreach ($_REQUEST['imgarr'] as $image_id => $val):
                                                                           $i++;
                                                                           $src = get_template_directory_uri() . '/images/tmp/' . trim($val);
                                                                           $thumb_image_path = get_template_directory() . '/images/tmp/' . trim($val);

                                                                           if (file_exists($thumb_image_path) && $i == 1):
                                                                                     ?>
                                                                                     <li>
                                                                                          <img src="<?php echo $src; ?>" alt=""/>
                                                                                     </li>
                                                                           <?php else: ?>
                                                                                     <?php
                                                                                     if ($post_img):
                                                                                               foreach ($post_img as $value):
                                                                                                         $tmpl = explode("/", $value['file']);
                                                                                                         $name = end($tmpl);
                                                                                                         if ($val == $name):
                                                                                                                   ?>
                                                                                                                   <li><img src="<?php echo $value['file']; ?>" alt=""  title="<?php echo $img_title['filename'] ?>" /></li>
                                                                                                    <?php
                                                                                          endif;
                                                                                endforeach;
                                                                      endif;
                                                            endif;
                                                            ?>
                                                                           <?php
                                                                 endforeach;
                                                       endif;
                                                       ?>
                                                  </ul>

                                             </div>
                                             <!-- More Image gallery -->
                                             <div id="silde_gallery" class="flexslider-preview<?php
                                                       if (!empty($more_listing_img) && count($more_listing_img) > 4) {
                                                                 echo ' slider_padding_class';
                                                       }
                                                       ?>">
                                                  <ul class="more_photos slides">
                                                       <?php
                                                       $thumb_img_counter = 0;
                                                       $thumb_img_counter = $thumb_img_counter + count($_REQUEST['imgarr']);
                                                       $image_path = get_image_phy_destination_path_plugin();
                                                       $tmppath = "/" . $upload_folder_path . "tmp/";
                                                       foreach ($_REQUEST['imgarr'] as $image_id => $val):
                                                                 $thumb_image = get_template_directory_uri() . '/images/tmp/' . trim($val);
                                                                 $thumb_image_path = get_template_directory() . '/images/tmp/' . trim($val);
                                                                 if (file_exists($thumb_image_path) && trim($val) != '') {
                                                                           ?>
                                                                           <li>
                                                                                <img src="<?php echo $thumb_image; ?>" alt=""  />
                                                                           </li>
                                                  <?php
                                                  }
                                        endforeach;
                                        ?>
                                                  </ul>
                                             </div>
                                             <!-- Finish More Image gallery -->
                              <?php
                              endif;

                              do_action('directory_after_post_image');
                              ?>
                              </div><!-- .entry-header-image -->
                              <?php
                    endif;
          } else {
                    if (function_exists('bdw_get_images_plugin')) {
                              $post_img = bdw_get_images_plugin(get_the_ID(), 'adv_detail-main-img');
                              $postimg_thumbnail = bdw_get_images_plugin(get_the_ID(), 'thumbnail');
                              $more_listing_img = bdw_get_images_plugin(get_the_ID(), 'tevolution_thumbnail');
                              $thumb_img = @$post_img[0]['file'];
                              $attachment_id = @$post_img[0]['id'];
                              $image_attributes = wp_get_attachment_image_src($attachment_id, 'large');
                              $attach_data = get_post($attachment_id);
                              $img_title = $attach_data->post_title;
                              $img_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
                    }
                    if ($thumb_img && $is_edit == ''):
                              ?>		
                              <div id="classified_detail_img" class="entry-header-image">

                              <?php do_action('directory_before_post_image'); ?>
                              <?php if ($is_edit == ""): ?>
                                             <div id="slider" class="listing-image flexslider frontend_edit_image">    

                                                  <ul class="slides">
                                                       <?php
                                                       if (!empty($post_img)):
                                                                 foreach ($post_img as $key => $value):
                                                                           $attachment_id = $value['id'];
                                                                           $attach_data = get_post($attachment_id);
                                                                           $image_attributes = wp_get_attachment_image_src($attachment_id, 'large'); /* returns an array							 */
                                                                           $img_title = $attach_data->post_title;
                                                                           $img_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
                                                                           ?>
                                                                           <li>
                                                                                <a href="<?php echo $image_attributes['0']; ?>" title="<?php echo $img_title; ?>" class="listing_img" >		
                                                                                     <img src="<?php echo $value['file']; ?>" alt="<?php echo $img_title; ?>"/>
                                                                                </a>
                                                                           </li>

                                                                 <?php endforeach; ?>
                                                       <?php endif; ?>
                                                  </ul>

                                             </div>
                                             <!-- More Image gallery -->
                                             <div id="silde_gallery" class="flexslider<?php
                                        if (!empty($more_listing_img) && count($more_listing_img) > 4) {
                                                  echo ' slider_padding_class';
                                        }
                                                       ?>">
                                                  <ul class="more_photos slides">
                                        <?php if (!empty($more_listing_img) && count($more_listing_img) > 1): ?>
                                                       <?php
                                                       foreach ($more_listing_img as $key => $value):
                                                                 $attachment_id = $value['id'];
                                                                 $attach_data = get_post($attachment_id);
                                                                 $image_attributes = wp_get_attachment_image_src($attachment_id, 'tevolution_thumbnail'); /* returns an array							 */
                                                                 $img_title = $attach_data->post_title;
                                                                 $img_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
                                                                 ?>
                                                                           <li>
                                                                                <a title="<?php echo $img_title; ?>" >		
                                                                                     <img src="<?php echo $value['file']; ?>" alt="<?php echo $img_title; ?>"  />
                                                                                </a>
                                                                           </li>

                                                  <?php endforeach; ?>
                                        <?php endif; ?>
                                                  </ul>
                                             </div>
                                             <!-- Finish More Image gallery -->
                              <?php
                              endif;
                              do_action('directory_after_post_image');
                              ?>
                              </div><!-- .entry-header-image -->
                              <?php
                    else:
                              if ($is_edit == ''):
                                        ?>
                                        <div id="classified_detail_img" class="entry-header-image">
                                             <li>
                                                  <a href="<?php echo $image_attributes['0']; ?>" title="<?php echo $img_title; ?>" class="listing_img" >		
                                                       <img src="<?php echo TEVOLUTION_CLASSIFIEDS_URL . 'images/noimage-256x180.jpg'; ?>" alt="<?php echo $img_title; ?>"/>
                                                  </a>
                                             </li>
                                        </div>
                                                       <?php
                                             endif;

                                   endif;

                                   if ($is_edit == "1"):
                                             ?>
                              <!-- Front end edit upload image-->
                              <div id="classified_detail_img" class="entry-header-image">
                                   <!--editing post images -->
                                   <div id="slider" class="listing-image flexslider frontend_edit_image flex-viewport">
                                        <ul class="frontend_edit_images_ul">
                                             <?php
                                             $post_img = bdw_get_images_plugin($post->ID, 'large');
                                             if (!empty($post_img)):
                                                       foreach ($post_img as $key => $value):
                                                                 echo "<li class='image' data-attachment_id='" . basename($value['file']) . "' data-attachment_src='" . $value['file'] . "'><img src='" . $value['file'] . "' alt='" . $img_title . "' /></li>";
                                                                 break;
                                                       endforeach;
                                             endif;
                                             ?>
                                        </ul>
                                        <div id="uploadimage" class="upload button secondary_btn clearfix">
                                             <span><?php _e("Upload Images", 'classifieds'); ?></span>					
                                        </div>
                                   </div>

                                   <div id="frontend_images_gallery_container" class="clearfix flex-viewport">
                                        <ul class="frontend_images_gallery more_photos slides">
                              <?php
                              if (!empty($post_img)):
                                        foreach ($post_img as $key => $value):
                                                  echo "<li class='image' data-attachment_id='" . basename($value['file']) . "' data-attachment_src='" . $value['file'] . "'><img src='" . $value['file'] . "' alt='" . $img_title . "' /><span>
							<a class='delete' title='Delete image' href='#' id='" . $value['id'] . "' ><i class='fa fa-times-circle redcross'></i>";
                                                  echo "</a></span></li>";
                                        endforeach;
                              endif;
                              ?>
                                        </ul>
                                        <input type="hidden" id="fontend_image_gallery" name="fontend_image_gallery" value="<?php echo esc_attr(substr(@$image_gallery, 0, -1)); ?>" />		
                                   </div>
                                   <span id="forntend_status" class="message_error2 clearfix"></span>
                                   <!--finish editing post images -->
                                   <!--finish editing post images -->
                              </div>
                    <?php
                    endif;
          }
          ?>
          <!-- Finish Image Gallery Div -->
          <?php
}

/* Show the post meta below the title */
add_action('classified_after_title', 'tmpl_classifieds_ad_id');

function tmpl_classifieds_ad_id() {
          if (!isset($_REQUEST['ptype']) && $_REQUEST['ptype'] != 'preview') {
                    global $tmpl_flds_varname, $post;
					echo "<ul>";
					if($tmpl_flds_varname['ad_id'])
						echo "<li><p class='bottom_line'><span>" . $tmpl_flds_varname['ad_id']['label'] . ":&nbsp;</span><span>" . get_post_meta($post->ID, 'ad_id', true) . "</span></p></li>";
                    /* views */
                    global $post;
                    $count_post_id = $post->ID;

                    /* get all tevolution settings */
                    $tmpdata = get_option('templatic_settings');

                    /* get all tevolution general settings->detail page settings show views */
                    if (isset($tmpdata['templatic_view_counter']) && $tmpdata['templatic_view_counter'] == 'Yes'){

                              if (function_exists('view_counter_single_post')) {
                                        view_counter_single_post($count_post_id);
                              }

                              $post_visit_count = (get_post_meta($count_post_id, 'viewed_count', true)) ? get_post_meta($count_post_id, 'viewed_count', true) : '0';
                              /* $post_visit_daily_count=(get_post_meta($count_post_id,'viewed_count_daily',true))? get_post_meta($count_post_id,'viewed_count_daily',true): '0'; */


                              echo "<li class='view_counter'>";
                              if ($post_visit_count == 1) {
                                        $custom_content = '<p><span class="total-views"><em>' . __('Viewing', 'classifieds') . '</em></span>';
                              } else {
                                        $custom_content = '<p><span class="total-views"><em>' . sprintf('%s', $post_visit_count) . ' ' . __('views', 'classifieds') . '</em></span>';
                              }
                              /* $custom_content.= '<span class="todays-views"> <em>'.$post_visit_daily_count.__(" today</em></span>",'classifieds')."</p>"; */
                              echo $custom_content;
                              echo '</li>';
                    }
                    if ($tmpdata['templatin_rating'] == 'yes'):
                              $total = get_post_total_rating(get_the_ID());
                              $total = ($total == '') ? 0 : $total;
                              $review_text = ($total == 1) ? '<a href="#comments">' . $total . ' ' . __('Review', 'classifieds') . '</a>' : '<a href="#comments">' . $total . ' ' . __('Reviews', 'classifieds') . '</a>';
                              ?><li>
                                   <div class="listing_rating">
                                        <div class="directory_rating_row"><span class="single_rating"> <?php echo draw_rating_star_plugin(get_post_average_rating(get_the_ID())); ?> <span><?php echo $review_text ?></span></span></div>
                                   </div>
                              </li>
                              <?php
                    endif;
                    do_action('directory_display_rating', get_the_ID());
                    echo "</ul>";
          }
}

add_action('classified_custom_fields_collection', 'tmpl_classifieds_metadata', 20);

function tmpl_classifieds_metadata() {
          global $htmlvar_name, $post;
          wp_reset_postdata();
          wp_reset_query();
          echo "<ul class='detail-meta'>";
          /* publish date */
          if (isset($_REQUEST['ptype']) && $_REQUEST['ptype'] == 'preview') {
                    /* categories */
                    if (@$htmlvar_name['basic_inf']['category'] && @$htmlvar_name['basic_inf']['category']) {
                              echo "<li>" . tmpl_classified_post_preview_categories_tags($_REQUEST['category'], $_REQUEST['post_tags']) . "</li>";
                    }
          } else {

                    /* categories */
                    if (@$htmlvar_name['basic_inf']['category'] && @$htmlvar_name['basic_inf']['category']) {
                              echo "<li>" . tmpl_get_the_posttype_taxonomies(CUSTOM_MENU_CLASSIFIED_CAT_LABEL, CUSTOM_CATEGORY_TYPE_CLASSIFIED, __('Categories: ', 'classifieds')) . "</li>";
                    }
          }
          echo "</ul>";
}

/* Add the classifieds informations */

add_action('tmpl_classified_info_right', 'tmpl_classified_info_right_fun');

function tmpl_classified_info_right_fun() {
          global $post, $htmlvar_name, $tmpl_flds_varname;
          if (isset($_REQUEST['ptype']) && $_REQUEST['ptype'] == 'preview') {
                    $address = $_REQUEST['address'];
                    $zip_code = $_REQUEST['zip_code'];
                    $phone = $_REQUEST['phone'];
          } else {
                    $address = get_post_meta($post->ID, 'address', true);
                    $zip_code = get_post_meta($post->ID, 'zip_code', true);
                    $phone = get_post_meta($post->ID, 'phone', true);
                    $classified_tag = get_post_meta($post->ID, 'classified_tag', true);
          }
          $is_edit = '';
          if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'edit') {
                    $is_edit = 1;
          }
          ?>
          <div id="classified_info_right" class="classified_info-right">
               <article  class="entry-header-custom-wrap classified-info">
                    <?php
                    /* Display Address */
                    if (($tmpl_flds_varname['address'] && $address != '') || ($is_edit == 1 && $tmpl_flds_varname['address'])) {
                              echo "<p class='entry_address'><label>" . $tmpl_flds_varname['address']['label'] . ": </label> <span id='frontend_address' class='frontend_address' " . (($is_edit == 1) ? "contenteditable='true'" : "") . ">" . $address . "</span></p>";
                    }

                    /* Display locations info  */
                    if ($tmpl_flds_varname['post_city_id'] && $tmpl_flds_varname['post_city_id']['type'] == 'multicity') {
                              global $wpdb, $country_table, $zones_table, $multicity_table;

                              if (isset($_REQUEST['ptype']) && $_REQUEST['ptype'] == 'preview') {
                                        $city = $_REQUEST['post_city_id'];
                                        $zones_id = $_REQUEST['zones_id'];
                                        $country_id = $_REQUEST['country_id'];
                              } else {
                                        $city = get_post_meta($post->ID, 'post_city_id', true);
                                        $zones_id = get_post_meta($post->ID, 'zones_id', true);
                                        $country_id = get_post_meta($post->ID, 'country_id', true);
                              }
                              /* if multiple cities selected */
                              if (strstr($city, ',')) {
                                        $cities = explode(',', $city);
                                        $sep = ", ";
                                        for ($c = 0; $c < count($cities); $c++) {
                                                  if ($c == ( count($cities) - 1)) {
                                                            $sep = '';
                                                  }
                                                  $cityinfo = $wpdb->get_results($wpdb->prepare("select cityname from $multicity_table where city_id =%d", $cities[$c]));
                                                  $cityname .= $cityinfo[0]->cityname . $sep;
                                        }
                                        $cityname = rtrim($cityname, ',');
                              } else {
                                        /* if single city selected */
                                        $cityinfo = $wpdb->get_results($wpdb->prepare("select cityname from $multicity_table where city_id =%d", $city));
                                        $cityname = $cityinfo[0]->cityname;
                              }
                              /* Display country name */
                              if ($country_id != '')
                                        $countryinfo = $wpdb->get_results($wpdb->prepare("select country_name from $country_table where country_id =%d", $country_id));

                              /* Display zone name */
                              if ($zones_id != '')
                                        $zoneinfo = $wpdb->get_results($wpdb->prepare("select zone_name from $zones_table where zones_id =%d", $zones_id));

                              if ($countryinfo[0]->country_name) {
                                        ?><p class='classified_county <?php echo $value['style_class']; ?>'><label><?php _e('Country', 'classifieds'); ?>:</label> <span><?php echo $countryinfo[0]->country_name; ?></span></p>
                              <?php
                              }
                              if ($zoneinfo[0]->zone_name) {
                                        ?>
                                        <p class='classified_zone <?php echo $value['style_class']; ?>'><label><?php _e('State', 'classifieds'); ?>:</label> <span><?php echo $zoneinfo[0]->zone_name; ?></span></p>
                              <?php
                              }
                              if ($cityinfo[0]->cityname) {
                                        ?>
                                        <p class='classified_city <?php echo $value['style_class']; ?>'><label><?php _e('City', 'classifieds'); ?>:</label> <span><?php echo $cityname; ?></span></p>
                                        <?php
                              }
                    }

                    /* Display Zip code */

                    if (($tmpl_flds_varname['zip_code'] && $zip_code != '' ) || ($is_edit == 1 && $tmpl_flds_varname['zip_code'])) {
                              echo "<p class='zip_code'><label>" . $tmpl_flds_varname['zip_code']['label'] . ": </label> <span class='frontend_zip_code' " . (($is_edit == 1) ? 'contenteditable="true"' : '') . ">" . $zip_code . "</span></p>";
                    }

                    //echo '<pre>';print_r($htmlvar_name);echo '</pre>';

                    if (($is_edit == 1 && $tmpl_flds_varname['classified_tag'])) {
                              $for_lbl_value = explode(',', $tmpl_flds_varname['classified_tag']['option_values']);
                              $for_lbl = explode(',', $tmpl_flds_varname['classified_tag']['option_title']);
                              for ($i = 0; $i < count($for_lbl_value); $i++) {
                                        if ($for_lbl_value[$i] == $classified_tag) {
                                                  $classified_tag = $for_lbl[$i];
                                                  break;
                                        }
                              }
                              echo "<p class='zip_code'><label>" . $tmpl_flds_varname['classified_tag']['label'] . ": </label> <span id='frontend_select_classified_tag' class='frontend_classified_tag' contenteditable='true'>" . $classified_tag . "</span></p>";
                    } else {
                              $for_lbl_value = explode(',', $tmpl_flds_varname['classified_tag']['option_values']);
                              $for_lbl = explode(',', $tmpl_flds_varname['classified_tag']['option_title']);
                              for ($i = 0; $i < count($for_lbl_value); $i++) {
                                        if ($for_lbl_value[$i] == $classified_tag) {
                                                  $classified_tag = $for_lbl[$i];
                                                  break;
                                        }
                              }
                              if ($tmpl_flds_varname['classified_tag'] && $classified_tag) {
                                        echo "<p class='classified_tag'><label>" . $tmpl_flds_varname['classified_tag']['label'] . ": </label> <span class='frontend_classified_tag' " . (($is_edit == 1) ? 'contenteditable="true"' : '') . ">" . $classified_tag . "</span></p>";
                              }
                    }


                    if (isset($_REQUEST['ptype']) && $_REQUEST['ptype'] == 'preview') {
                              echo "<p class='publish_date'><label>" . __('Listed On', 'classifieds') . ":</label> ";
                              echo "<span>";
                              echo date_i18n(get_option('date_format'));
                              echo "&nbsp;&nbsp;";
                              echo "</span>";
                              echo "</p>";
                    } else {
                              echo "<p class='publish_date'><label>" . __('Listed On', 'classifieds') . ":</label> ";
                              echo "<span>";
                              echo date_i18n(get_option('date_format'), strtotime($post->post_date));
                              echo "</span>";
                              echo "</p>";
                    }

                    if (function_exists('tmpl_wp_is_mobile') && tmpl_wp_is_mobile()) {
                              /* show classified type on preview page and detail page */
                              if (isset($_REQUEST['ptype']) && $_REQUEST['ptype'] == 'preview') {
                                        $price_type = $_REQUEST['price_type'];
                              } else {
                                        $price_type = get_post_meta($post->ID, 'price_type', true);
                              }
                              /* show classified price on preview page and detail page */
                              if (isset($_REQUEST['ptype']) && $_REQUEST['ptype'] == 'preview') {
                                        $classified_price = $_REQUEST['price'];
                              } else {
                                        $classified_price = get_post_meta($post->ID, 'price', true);
                              }


                              $for_lbl_value = explode(',', $tmpl_flds_varname['price_type']['option_values']);
                              $for_lbl = explode(',', $tmpl_flds_varname['price_type']['option_title']);
                              for ($i = 0; $i < count($for_lbl_value); $i++) {
                                        if ($for_lbl_value[$i] == $price_type) {
                                                  $price_type = $for_lbl[$i];
                                                  break;
                                        }
                              }

                              $for_lbl = explode(',', $tmpl_flds_varname['price_type']['option_title']);

                              echo ' <p class="classified_price"><span>';
                              echo display_amount_with_currency_plugin($classified_price) . '( ' . $price_type . ' )</span></p>';
                    }

                    do_action('directory_display_custom_fields');
                    /* For preview page */
                    if (isset($_REQUEST['ptype']) && $_REQUEST['ptype'] == 'preview') {
                              do_action('directory_display_custom_fields_preview_default_right');
                    }
                    ?>
               </article>
          <?php
          /* Display Phone number */

          if (($tmpl_flds_varname['phone'] && $phone != '') || ($is_edit == 1 && $tmpl_flds_varname['phone'])) {
                    echo "<span id='frontend_contact-no' class='contact-no' " . (($is_edit == 1) ? "contenteditable='true'" : "") . "><i class='fa fa-mobile'></i>" . $phone . "</span></p>";
          } elseif ($tmpl_flds_varname['phone'] && $phone != '' && !tmpl_wp_is_mobile()) {
                    ?>
                         <span class="contact-no"><i class="fa fa-mobile"></i><?php echo $phone; ?></span>
                    <?php
          }

          if (!tmpl_wp_is_mobile() && !isset($_REQUEST['ptype']) && $_REQUEST['ptype'] != 'preview') {
                    ?>
                         <a id="contact_seller_id" data-reveal-id="contact_seller_div" class="button"  href="javascript:void(0);"><?php _e('Contact Seller', 'classifieds'); ?></a>
                    <?php
                    contact_seller();
          }
          ?>
          </div>
          <?php
}

/* Show the classified price on detail page */

add_action('classified_header_right', 'tmpl_classified_header_right');

function tmpl_classified_header_right() {
          global $post, $htmlvar_name, $tmpl_flds_varname;

          $is_edit = '';
          if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'edit') {
                    $is_edit = 1;
          }
          /* show classified type on preview page and detail page */
          if (isset($_REQUEST['ptype']) && $_REQUEST['ptype'] == 'preview') {
                    $price_type = $_REQUEST['price_type'];
          } else {
                    $price_type = get_post_meta($post->ID, 'price_type', true);
          }
          /* show classified price on preview page and detail page */
          if (isset($_REQUEST['ptype']) && $_REQUEST['ptype'] == 'preview') {
                    $classified_price = $_REQUEST['price'];
          } else {
                    $classified_price = get_post_meta($post->ID, 'price', true);
          }

          $for_lbl_value = explode(',', $tmpl_flds_varname['price_type']['option_values']);
          $for_lbl = explode(',', $tmpl_flds_varname['price_type']['option_title']);
          for ($i = 0; $i < count($for_lbl_value); $i++) {
                    if (strtolower($for_lbl_value[$i]) == strtolower($price_type)) {
                              $price_type = $for_lbl[$i];
                              break;
                    }
          }
          if ($is_edit == 1) {
                    echo ' <span class="classified-price">' . get_option('currency_symbol') . '<span id="frontend_price" class="frontend_price" contenteditable="true">';
                    echo $classified_price . '</span></span>';
          } elseif ($classified_price != '' && $tmpl_flds_varname['price']) {
                    echo ' <span class="classified-price"><span>';
                    echo display_amount_with_currency_plugin($classified_price) . '</span></span>';
          }
          if (( $tmpl_flds_varname['price_type'] ) && $is_edit == 1) {
                    echo '<span class="price-type">( <span id="frontend_radio_price_type" class="frontend_price_type" contenteditable="true">' . $price_type . "</span> )</span>";
          }
          if (($price_type != '' && $tmpl_flds_varname['price_type'] ) && $is_edit == '') {
                    echo '<span class="price-type">( ' . $price_type . " )</span>";
          }
}

/* return the all pop up links display on detail page */

add_action('classified_popup_links', 'tmpl_classified_popup_links');

function tmpl_classified_popup_links($post) {
          global $post;
          ?>
          <div class="claim-post-wraper">
               <ul>
          <?php
          /* show sent to friend and send inquiry form pop up */
          if (function_exists('tevolution_dir_popupfrms'))
                    tevolution_dir_popupfrms($post);
          if (!isset($link)) {
                    $link = '';
          }
          ?>
                    <li class="print"><a id="print_id" title="Print this post" href="#print" rel="leanModal_print" class="small_btn print" onclick="tmpl_printpage()"><?php _e('Print', 'classifieds'); ?></a></li>
          <?php
          if (current_theme_supports('tevolution_my_favourites') && $post->post_status == 'publish') {
                    global $current_user;
                    $user_id = $current_user->ID;
          }
          if (function_exists('add_to_my_calendar')) {
                    add_to_my_calendar();
          }
          ?>                        
               </ul>
          </div>
          <!--Code start for single captcha -->
          <?php
          $tmpdata = get_option('templatic_settings');
          $display = (isset($tmpdata['user_verification_page'])) ? $tmpdata['user_verification_page'] : array();
          $captcha_set = array();
          $captcha_dis = '';
          if (count($display) > 0 && !empty($display)) {
                    foreach ($display as $_display) {
                              if ($_display == 'claim' || $_display == 'emaitofrd') {
                                        $captcha_set[] = $_display;
                                        $captcha_dis = $_display;
                              }
                    }
          }
          $recaptcha = get_option("recaptcha_options");
          global $current_user;
          ?>

          <div id="myrecap" style="display:none;"><?php
          if ($recaptcha['show_in_comments'] != 1 || $current_user->ID != '') {
                    templ_captcha_integrate($captcha_dis);
          }
          ?></div> 
          <input type="hidden" id="owner_frm" name="owner_frm" value=""  />
          <div id="claim_ship"></div>
          <script type="text/javascript" async >
                    var RECAPTCHA_COMMENT = '';
          <?php if ($recaptcha['show_in_comments'] != 1 || $current_user->ID != '') { ?>
                              jQuery('#owner_frm').val(jQuery('#myrecap').html());
          <?php } else { ?> RECAPTCHA_COMMENT = <?php echo $recaptcha['show_in_comments']; ?>;
          <?php } ?>
          </script>

          <!--Code end for single captcha -->
          <?php
}

/* get related advertisements */
add_action('tmpl_related_classified', 'tmpl_get_related_classified');

function tmpl_get_related_classified() {

          global $post, $htmlvar_name, $wpdb, $wp_query;

          /* get all the custom fields which select as " Show field on listing page" from back end */

          if (function_exists('tmpl_get_category_list_customfields')) {
                    $htmlvar_name = tmpl_get_category_list_customfields(CUSTOM_POST_TYPE_CLASSIFIED);
          } else {
                    global $htmlvar_name;
          }
          $wp_query->set('is_related', 1);
          $related_posts = tmpl_get_related_posts_query();

          if (!empty($related_posts)) {

                    echo "<ul class='loop_related_list'>";
                    while ($related_posts->have_posts()) {
                              global $post;
                              $related_posts->the_post();

                              /* remove ratings from below title */
                              remove_action('templ_post_title', 'tevolution_listing_after_title', 12);
                              /* remove add to favourite from below title */
                              remove_action('templ_post_title', 'tevolution_favourite_html', 11);
                              $address = get_post_meta($post->ID, 'address', true);
                              $price = get_post_meta($post->ID, 'price', true);
                              ?>
                              <li class="post clearfix <?php templ_post_class(); ?>">  
                                   <div class="post-left">
                              <?php
                              $post_img = bdw_get_images_plugin($post->ID, 'tevolution_thumbnail');
                              if (!empty($post_img)) {
                                        ?>
                                                  <img src="<?php echo $post_img[0]['file']; ?>"/>
                              <?php } else { ?>
                                                  <img src="<?php echo TEVOLUTION_CLASSIFIEDS_URL; ?>images/noimage-256x180.jpg" width="80px"/>
                                        <?php
                              }
                              ?>
                                   </div>
                                   <div class="post-right">
                                        <h4><a href="<?php echo get_permalink($pos->ID); ?>"><?php the_title(); ?></a></h4>
                              <?php
                              if ($htmlvar_name['address'] && $address != '') {
                                        echo "<p>" . $address . "</p>";
                              }

                              if ($htmlvar_name['price'] && $price != '') {
                                        echo "<span class='rel-price'>" . display_amount_with_currency_plugin($price) . "</span>";
                              }
                              ?>
                                   </div>

                              </li>
                              <?php
                              do_action('classified_after_post_loop');
                    }
                    echo "</ul>";
                    wp_reset_query();
          }
}

/* * ************************************* Preview page functions **************************************************** */

/* To display the categories on preview page */

if (!function_exists('tmpl_classified_post_preview_categories_tags')) {

          function tmpl_classified_post_preview_categories_tags($cats, $tags) {
                    global $heading_title;
                    $_SESSION['custom_fields'] = $_POST;
                    $session = $_SESSION['custom_fields'];
                    $cur_post_type = ($session['cur_post_type'] != "") ? $session['cur_post_type'] : CUSTOM_POST_TYPE_CLASSIFIED;
                    $heading_type = tmpl_fetch_heading_post_type($cur_post_type);
                    $htmlvar_name = tmpl_single_page_custom_field($cur_post_type, '[#taxonomy_name#]', 'basic_inf'); /* custom fields for custom post type.. */
                    $taxonomies = get_object_taxonomies((object) array('post_type' => $cur_post_type, 'public' => true, '_builtin' => true));
                    /* $hm = $htmlvar_name[]; */

                    $htm_keys = array_keys($htmlvar_name);
                    $taxonomy_category = '';
                    for ($c = 0; $c < count($cats); $c++) {

                              if ($c < ( count($cats) - 1)) {
                                        $sep = ', ';
                              } else {
                                        $sep = ' ';
                              }

                              $cat_id = explode(',', $cats[$c]);
                              $term = get_term_by('id', $cat_id[0], $taxonomies[0]);

                              $term_link = get_term_link($term, $taxonomies[0]);

                              $taxonomy_category .= '<a href="' . $term_link . '">' . $term->name . '</a>' . $sep;
                    }

                    return sprintf(__('Categories: %s', 'classifieds'), $taxonomy_category);
          }

}

add_action('classified_before_container_breadcrumb', 'tmpl_classified_breadcrumb');

/*
  Single Post types Breadcrumbs
 */

function tmpl_classified_breadcrumb() {
          if (current_theme_supports('breadcrumb-trail') && supreme_get_settings('supreme_show_breadcrumb')) {
                    breadcrumb_trail(array('separator' => '&raquo;'));
          }
}

add_action('classified_custom_fields_collection', 'classified_preview_page_fields_collection', 10, 2);
add_action('classified_custom_fields_collection', 'tmpl_fields_detail_informations', 10, 2);
/*
 * return array for classified listing custom fields
 */

function get_classified_single_customfields($post_type, $heading = '', $heading_key = '') {
          global $wpdb, $post, $posttitle;
          $cur_lang_code = (is_plugin_active('sitepress-multilingual-cms/sitepress.php')) ? ICL_LANGUAGE_CODE : '';
          remove_all_actions('posts_where');
          $post_query = null;
          remove_action('pre_get_posts', 'event_manager_pre_get_posts');
          remove_action('pre_get_posts', 'directory_pre_get_posts', 12);
          add_filter('posts_join', 'custom_field_posts_where_filter');


          $args = apply_filters('tmpl_nondir_htmlvar_name_query', array('post_type' => 'custom_fields',
                    'posts_per_page' => -1,
                    'post_status' => array('publish'),
                    'meta_query' => array('relation' => 'AND',
                              array(
                                        'key' => 'post_type_' . $post_type . '',
                                        'value' => $post_type,
                                        'compare' => '=',
                                        'type' => 'text'
                              ),
                              array(
                                        'key' => 'is_active',
                                        'value' => '1',
                                        'compare' => '='
                              ),
                              array(
                                        'key' => 'show_on_detail',
                                        'value' => '1',
                                        'compare' => '='
                              ),
                              array('key' => $post_type . '_heading_type', 'value' => array('basic_inf', $heading), 'compare' => 'IN')
                    ),
                    'meta_key' => 'sort_order',
                    'orderby' => 'meta_value',
                    'order' => 'ASC'
                    ), $post_type, $heading, $heading_key);

          if (get_option('tevolution_cache_disable') == 1 && false === ($post_query = get_transient('_tevolution_query_single' . trim($post_type) . trim($heading_key) . $cur_lang_code))) {
                    $post_query = new WP_Query($args);
                    set_transient('_tevolution_query_single' . trim($post_type) . trim($heading_key) . $cur_lang_code, $post_query, 12 * HOUR_IN_SECONDS);
          } elseif (get_option('tevolution_cache_disable') == '') {
                    $post_query = new WP_Query($args);
          }

          remove_filter('posts_join', 'custom_field_posts_where_filter');

          $htmlvar_name = '';
          if ($post_query->have_posts()) {
                    while ($post_query->have_posts()) : $post_query->the_post();
                              $ctype = get_post_meta($post->ID, 'ctype', true);
                              if ($ctype == 'heading_type')
                                        continue;
                              $post_name = get_post_meta($post->ID, 'htmlvar_name', true);
                              $style_class = get_post_meta($post->ID, 'style_class', true);
                              $option_title = get_post_meta($post->ID, 'option_title', true);
                              $option_values = get_post_meta($post->ID, 'option_values', true);
                              $default_value = get_post_meta($post->ID, 'default_value', true);
                              $htmlvar_name[$post_name] = array('type' => $ctype,
                                        'label' => $post->post_title,
                                        'style_class' => $style_class,
                                        'option_title' => $option_title,
                                        'option_values' => $option_values,
                                        'default' => $default_value,
                              );
                    endwhile;
                    wp_reset_query();
          }
          return $htmlvar_name;
}

/*
  display the additional custom field on preview page
 */

function classified_preview_page_fields_collection() {

          global $heading_title;
          $session = $_REQUEST;
          /* $cur_post_type='listing'; */
          $cur_post_type = ($session['submit_post_type'] != "") ? $session['submit_post_type'] : get_post_type();
          $heading_type = tmpl_fetch_heading_post_type($cur_post_type);

          if (count($heading_type) > 0) {
                    foreach ($heading_type as $key => $heading) {
                              $htmlvar_name[$key] = get_classified_single_customfields($cur_post_type, $heading, $key); /* custom fields for custom post type.. */
                    }
          }
          $j = 0;

          if (!empty($htmlvar_name)) {
                    echo '<div class="listing_custom_field">';
                    foreach ($htmlvar_name as $key => $value) {
                              $i = 0;
                              if (!empty($value)) {
                                        foreach ($value as $k => $val) {
                                                  $tmpl_key = ($key == 'basic_inf') ? __('Listing Information', 'classifieds') : $heading_type[$key];
                                                  if ($k != 'post_title' && $k != 'post_content' && $k != 'post_excerpt' && $k != 'post_images' && $k != 'category' && $k != 'listing_timing' && $k != 'listing_logo' && $k != 'video' && $k != 'post_tags' && $k != 'map_view' && $k != 'proprty_feature' && $k != 'phone' && $k != 'email' && $k != 'website' && $k != 'twitter' && $k != 'facebook' && $k != 'google_plus' && $k != 'address' && $k != 'post_city_id') {


                                                            $field = $session[$k];
                                                            if ($val['type'] == 'multicheckbox' && $field != ""):
                                                                      if ($i == 0) {
                                                                                echo '<h4 class="custom_field_headding">' . $tmpl_key . '</h4>';
                                                                                $i++;
                                                                      }
                                                                      $option_values = explode(",", $val['option_values']);
                                                                      $option_titles = explode(",", $val['option_title']);
                                                                      for ($i = 0; $i < count($option_values); $i++) {
                                                                                if (in_array($option_values[$i], $field)) {
                                                                                          if ($option_titles[$i] != "") {
                                                                                                    $checkbox_value .= $option_titles[$i] . ',';
                                                                                          } else {
                                                                                                    $checkbox_value .= $option_values[$i] . ',';
                                                                                          }
                                                                                }
                                                                      }
                                                                      ?>
                                                                      <p class='<?php echo $k; ?>'><label><?php echo $val['label']; ?></label> : <?php echo substr($checkbox_value, 0, -1); ?></p>
                                                            <?php elseif ($val['type'] == 'upload' && $field != ''):
                                                                      ?>
                                                                      <p class='<?php echo $k; ?>'><label><?php echo $val['label']; ?></label>: <img height="80px" width="80px" src="<?php echo $field ?>" alt="<?php echo $field; ?>" /></p>

                                                                      <?php
                                                            elseif ($val['type'] == 'radio' && $field != ''):
                                                                      $option_values = explode(",", $val['option_values']);
                                                                      $option_titles = explode(",", $val['option_title']);
                                                                      for ($i = 0; $i < count($option_values); $i++) {
                                                                                if ($field == $option_values[$i]) {
                                                                                          if ($option_titles[$i] != "") {
                                                                                                    $rado_value = $option_titles[$i];
                                                                                          } else {
                                                                                                    $rado_value = $option_values[$i];
                                                                                          }
                                                                                          ?>
                                                                                          <p class='<?php echo $k; ?>'><label><?php echo $val['label']; ?></label>: <?php echo $rado_value; ?></p>
                                                                                          <?php
                                                                                }
                                                                      }
                                                            endif;

                                                            if (!is_array($session[$k])) {
                                                                      $field = stripslashes($session[$k]);
                                                            }
                                                            if ($val['type'] != 'multicheckbox' && $val['type'] != 'radio' && $val['type'] != 'upload' && $field != ''):
                                                                      if ($i == 0) {
                                                                                echo '<h4 class="custom_field_headding">' . $tmpl_key . '</h4>';
                                                                                $i++;
                                                                      }
                                                                      ?>                              
                                                                      <p class='<?php echo $k; ?>'><label><?php echo $val['label']; ?></label> : <?php echo $field; ?></p>
                                                                      <?php
                                                            endif;
                                                  }/* End If condition */

                                                  $j++;
                                        }
                              } /* End second foreach */
                    }/* END First foreach */
                    echo '</div>';
          }
}

/* Hook to Add the singular page class on preview page */
add_filter('body_class', 'tmpl_classified_preview_page_body_class', 11);

/* Add the singular page class on preview page */

function tmpl_classified_preview_page_body_class($classes) {
          global $post;

          if (isset($_REQUEST['ptype']) && $_REQUEST['ptypr'] == 'preview') {
                    $_SESSION['custom_fields'] = $_POST;
                    $classes[] = 'singular-' . $_REQUEST['cur_post_type'];
                    return $classes;
          } else {
                    if (is_single() && $post->post_type == 'classified') {
                              $classes[] = 'singular-classified';
                              return $classes;
                    } else {
                              $classes[] = '';
                              return $classes;
                    }
          }
}

/* Add price in specific format on success page */

add_action('tmpl_on_success_after_price_type', 'tmpl_classifieds_successpage_display_price');

function tmpl_classifieds_successpage_display_price() {
          global $post;
          $postdata = get_post(@$_GET['pid']);
          $price = get_post_meta(@$_GET['pid'], 'price', true);

          echo "<li><p class='submit_info_label'>" . __('Price (In ', 'classifieds') . get_option('currency_symbol') . " " . get_option('currency_code') . ") : </p> <p class='submit_info_detail'> " . $price . "</p></li>";
}

/*
  Include Contact Seller File
 */

function contact_seller() {
          ?>
          <script>
                    jQuery(document).ready(function () {
                         jQuery('#contact_seller_id').on('click', function () {
                              jQuery('html,body').scrollTop(0);
                              jQuery('#contact_seller_div').scrollTop(0);
                         });
                    });
          </script>
          <?php
          add_action('wp_footer', 'include_contact_seller_js');
          include_once(TEVOLUTION_CLASSIFIEDS_DIR . "functions/popup_contact_seller_frm.php");
}

/* show captcha on contact seller form */
add_action('show_captcha', 'include_classified_captcha_script');

function include_classified_captcha_script() {
          $tmpdata = get_option('templatic_settings');
          echo 'if(jQuery("#contact_seller_frm_popup").length > 0 ) { 
			grecaptcha.render("contact_seller_frm_popup", {' .
          '"sitekey" : "' . $tmpdata['site_key'] . '",' .
          '"theme" : "' . $tmpdata['comments_theme'] . '",' .
          '"hl" : "' . $tmpdata['captcha_language'] . '"' .
          '});
		 }';
}

/*
  Open Pop up for contact seller
 */

function include_contact_seller_js() {
          ?>
          <script>
                    jQuery(function () {
                         if (jQuery("#contact_seller_div")) {

                              /* Contatc Seller */

                              jQuery("#contact_seller_div .modal_close").click(function () {
                                   jQuery('#contact_seller_div').attr('style', '');
                                   jQuery('.reveal-modal-bg').css('display', 'none');
                                   jQuery('#contact_seller_div').removeClass('open');
                              });
                              tmpl_close_popup();
                         }
                    });
          </script>
          <?php
}

/*
  Sent Contact Mail to Seller
 */
add_action('wp_ajax_classifieds_contact_seller', 'classifieds_contact_seller');
add_action('wp_ajax_nopriv_classifieds_contact_seller', 'classifieds_contact_seller');

function classifieds_contact_seller() {
          global $wpdb, $post;
          /* CODE TO CHECK CAPTCHA */
          $tmpdata = get_option('templatic_settings');
          $display = $tmpdata['user_verification_page'];
          if (!empty($display) && in_array('sendinquiry', $display)) {
                    /* fetch captcha private key */
                    $privatekey = $tmpdata['secret'];
                    /* get the response from captcha that the entered captcha is valid or not */
                    $response = wp_remote_get("https://www.google.com/recaptcha/api/siteverify?secret=" . $privatekey . "&response=" . $_REQUEST["g-recaptcha-response"] . "&remoteip=" . getenv("REMOTE_ADDR"));
                    /* decode the captcha response */
                    $responde_encode = json_decode($response['body']);
                    /* check the response is valid or not */
                    if (!$responde_encode->success) {
                              echo '1';
                              exit;
                    }
          }
          if (isset($_REQUEST['contact_your_iemail']) && $_REQUEST['contact_your_iemail'] != "") {
                    $tmpdata = get_option('templatic_settings');

                    $contact_full_name = $_REQUEST['contact_full_name'];
                    $contact_your_iemail = $_REQUEST['contact_your_iemail'];
                    $contact_inq_sub = $_REQUEST['contact_inq_sub'];
                    $contact_inq_msg = $_REQUEST['contact_inq_msg'];
                    $post_id = $_REQUEST['listing_id'];
					if($post_id != "")
					{
						$productinfosql = "select ID,post_title from $wpdb->posts where ID ='".$post_id."'";
						$productinfo = $wpdb->get_results($productinfosql);
						foreach($productinfo as $productinfoObj)
						{
							$post_title = stripslashes($productinfoObj->post_title); 
						}
					}
                    $to_email = $_REQUEST['contact_author_email'];
                    $userdata = get_userdata($post->post_author);
                    $to_name = $userdata->display_name;
                    $store_name = '<a href="' . site_url() . '">' . get_option('blogname') . '</a>';
					$post_url_link = '<a href="'.get_permalink($post_id).'">'.$post_title.'</a>';
                    $tmpdata = get_option('templatic_settings');
                   
                    $email_content = @stripslashes($tmpdata['contact_us_email_content']);
                    if (@$email_content == '') {
                              $email_content = __("<p>Dear [#to_name#],</p><p>You have an inquiry message. Here are the details</p><p>Link : <b>[#post_link#]</b> </p><p> Name: [#user_name#] </p> <p> Email: [#user_email#] </p> <p> Message: [#user_message#] </p>", 'classifieds');
                    }
                    $toEmailName = get_option('blogname');
                    $search_array = array('[#to_name#]', '[#user_name#]', '[#user_email#]', '[#user_message#]','[#post_link#]');
                    $replace_array = array($_REQUEST['to_name'], $contact_full_name, $contact_your_iemail, nl2br($contact_inq_msg),$post_url_link);
                    $message = str_replace($search_array, $replace_array, $email_content);
                    $headers = 'MIME-Version: 1.0' . "\r\n";
                    $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";

                    $headers .= 'From: ' . $contact_full_name . ' <' . $contact_your_iemail . '>' . "\r\n";

                    if ($email_content != "" && $contact_inq_sub != "") {
                              if (wp_mail($to_email, $contact_inq_sub, $message, $headers)) {
                                        
                              } else {
                                        mail($to_email, $contact_inq_sub, $message, $headers);
                              }
                    }
                    _e('Email sent successfully', 'classifieds');
                    exit;
          }
}

/*
  tmpl_sidebar_after_singular
 */

function tmpl_sidebar_after_singular() {
          global $post, $wp_query, $wp_the_query;
          if (is_active_sidebar('after-singular') && get_post_type() == CUSTOM_POST_TYPE_CLASSIFIED):
                    ?>
                    <?php do_action('after_sidebar_after_singular'); ?>
                    <aside id="sidebar-after-singular" class="sidebar sidebar-inter-content">
                    <?php
                    do_action('open_sidebar_after_singular');

                    dynamic_sidebar('after-singular');

                    do_action('close_sidebar_after_singular');
                    ?>
                    </aside>
                    <!-- #sidebar-after-singular -->
                    <?php
                    do_action('after_sidebar_after_singular');
          endif;
}

/* show the singular advertisement after advertisement  */
if (function_exists('tmpl_sidebar_after_singular')) {
          add_action('after_entry', 'tmpl_sidebar_after_singular');
}

/* return classified search page template from ajax */
add_filter('get_tevolution_search_template_part', 'templ_classified_search_template_part', 10, 3);

function templ_classified_search_template_part($search_template, $slug, $name) {
          if ($name == 'classified') {

                    return TEVOLUTION_CLASSIFIEDS_DIR . "templates/{$slug}-{$name}.php";
          }

          return $search_template;
}

/* put filter listing below title */
if (function_exists('add_selected_filters')) {
          /* this function is in List Filter Plug-in */
          add_action('classified_subcategory', 'add_selected_filters', 99);
}

/* filter for default field for classified */
add_filter('directory_default_display_custom_fields','tmpl_classified_default_display_custom_fields');
function tmpl_classified_default_display_custom_fields($defult_filed){
          global $post;
         $post_type = get_post_type();
          if($post_type == 'classified')
                    $defult_filed = array('address','zip_code','classified_tag','phone');
          return $defult_filed;
}


/*
 * This function will return the results after drag the miles range slider
 */
add_action('wp_ajax_nopriv_classified_search','directory_classified_search');
add_action('wp_ajax_classified_search','directory_classified_search');
function directory_classified_search(){
	global $wp_query,$wpdb,$current_cityinfo;
	if(function_exists('tmpl_get_category_list_customfields')){
	
		$posttype = $_REQUEST['posttype'];

		$htmlvar_name = tmpl_get_category_list_customfields('classified');
	
	}else{
	
		global $htmlvar_name;
	
	}
	$per_page=get_option('posts_per_page');
	$paged = (isset($_REQUEST['page_num']) && $_REQUEST['page_num'] != '') ? $_REQUEST['page_num'] : 1;
	if(isset($_REQUEST['term_id']) && $_REQUEST['term_id']!=""){
		$taxonomies = get_object_taxonomies( (object) array( 'post_type' => $_REQUEST['posttype'],'public'   => true, '_builtin' => true ));
		$args=array(
				 'post_type'      => $_REQUEST['posttype'],
				 'posts_per_page' => $per_page,
				 'paged' 		  => $paged,
				 'post_status'    => 'publish',
				 'tax_query'      => array(
										  array(
											 'taxonomy' => $taxonomies[0],
											 'field'    => 'id',
											 'terms'    => explode(',',$_REQUEST['term_id']),
											 'operator' => 'IN'
										  )
									   ),
				);

	}else{
		$args=array(
				 'post_type'      => $_REQUEST['posttype'],
				 'posts_per_page' => $per_page,
				 'paged' 		  => $paged,
				 'post_status'    => 'publish',
				 );
	}
	
	directory_manager_classified_custom_field();
	if(is_plugin_active('sitepress-multilingual-cms/sitepress.php')){
		add_filter('posts_where', 'wpml_listing_milewise_search_language');
	}
	
	add_action('pre_get_posts','classified_search_get_posts');
	add_filter( 'posts_where', 'directory_classified_search_posts_where', 10, 2 );
	if(is_plugin_active('Tevolution-LocationManager/location-manager.php'))
	{
		add_filter('posts_where', 'location_multicity_where');
	}
	$post_details= new WP_Query($args);

	if(is_plugin_active('Tevolution-LocationManager/location-manager.php'))
	{
		remove_filter('posts_where', 'location_multicity_where');
	}
	if(is_plugin_active('sitepress-multilingual-cms/sitepress.php')){
		remove_filter('posts_where', 'wpml_listing_milewise_search_language');
	}
	if ($post_details->have_posts()) :
		while ( $post_details->have_posts() ) : $post_details->the_post();
		
		if(isset($_REQUEST['page_type'])=='archive' || isset($_REQUEST['page_type'])=='taxonomy'){
			/* 
			   loads template part for search result - loads template if it is available in theme otherwise it loads the template from perticuler plugins.
			   And template name should be "content-{your-posttype}.php"
			*/
			
			
			if(function_exists('tmpl_wp_is_mobile') && tmpl_wp_is_mobile()){
				
				if (locate_template('entry-mobile-' .'classified' . '.php') != ''){
					
					get_template_part('entry-mobile','classified');
				
				}else{
					
					do_action('get_template_part_tevolution-search','entry-mobile','classified',$htmlvar_name);
				
				}
			
			}else{
				
				if (locate_template('entry-' . 'classified' . '.php') != ''){
					
					get_template_part('entry', 'classified');
				
				}else{
					
					do_action('get_template_part_tevolution-search','entry','classified',$htmlvar_name);
				
				}
			
			}
		}
		endwhile;
		if($post_details->max_num_pages !=1):
		?>
		 <div id="list_paggination">
			  <div class="pagination pagination-position">
					<?php 
				
					$big = 999999999; /* need an unlikely integer */
					
						echo paginate_links( array(
							'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
							'format' => '/page/%#%',
							'current' => max( 1, $paged ),
							'total' => $post_details->max_num_pages,
							'before_page_number' => '<strong>',
							'after_page_number' => '</strong>',
							'prev_text'    => '<strong>'.__('Previous','classifieds').'</strong>',
							'next_text'    => '<strong>'.__('Next','classifieds').'</strong>',
							'type'         => 'plain',
						) );
					?>
			  </div>
		 </div>
		 <?php endif;
		wp_reset_query();
	else:
		?>
        <p class='nodata_msg'><?php _e( 'Apologies, but no results were found for the requested archive.', 'classifieds' ); ?></p>
        <?php
	endif;
	exit;
}
function classified_search_get_posts($wp_query){
	$wp_query->set('is_archive',1);	
}

/*
 *This function will return the HTMl  after the filter results on category page ( like miles range )
 */
function classified_archive_search_listing($wp_query){

	add_filter( "pre_get_posts", "classified_search_get_posts" );
	global $post,$wp_query;
	$wp_query->set('is_ajax_archive',1);
	do_action('classified_before_post_loop');
	
	$featured=get_post_meta(get_the_ID(),'featured_c',true);
	$classes=($featured=='c')?'featured_c':'';
	 	?>
            <div class="post  <?php templ_post_class();?>">  
            <?php 
                /*do_action before the post image */
                do_action('classified_before_category_page_image');           
                
                /* Here to fetch the image */
                do_action('classified_category_page_image');
                
                /*do action after the post image */
                do_action('classified_after_category_page_image'); 
                
                do_action('classified_before_post_entry');?>
                <div class="entry"> 
                       <!--start post type title -->
                       <?php do_action('classified_before_post_title');         /* do action for before the post title.*/ ?>
                       
                       <div class="classified-title">
                       
                        <?php /* do action for display the single post title */
                        do_action('templ_post_title');                
                      
                       /* do action for display the single post title */
                       do_action('tevolution_title_text');                ?>
                       
                       </div>
                       <?php 
                       /* do action for after the post title.*/
                       do_action('classified_after_post_title');         
                     
                        /*do action for display the post info */ 
                       do_action('classified_post_info');                 
                      
                        /* do action for before the post content. */								  
                       do_action('classified_before_post_content');      
                       
                       do_action('templ_taxonomy_content');	
                       
                       /* do action for after the post content. */
                       do_action('classified_after_post_content');       ?>
                       <!-- End Post Content -->
                       
                       <!-- Show custom fields where show on listing = yes -->
                       <?php 
                       /*add action for display the listing page custom field */
                       do_action('classified_listing_custom_field');
                       
                       do_action('templ_the_taxonomies');   
                       
                       do_action('classified_after_taxonomies');
                       
                       /* Here to show the add to favorites,comments and pinpoint  */
                        do_action('classified_after_post_entry');?>
                </div>
                 
            </div>
            <?php do_action('classified_after_post_loop');
}
function directory_manager_classified_custom_field(){
	global $wpdb,$post,$htmlvar_name,$pos_title;

	$post_type = (isset($_REQUEST['action']))? CUSTOM_POST_TYPE_CLASSIFIED : get_post_type();
	global $wpdb,$post,$posttitle,$htmlvar_name;
	$cur_lang_code=(is_plugin_active('sitepress-multilingual-cms/sitepress.php'))? ICL_LANGUAGE_CODE :'';
	$args = apply_filters('tmpl_dir_category_vars_arg',array( 'post_type' => 'custom_fields',
				'posts_per_page' => -1,
				'post_status' => array('publish'),
				'meta_query' => array('relation' => 'AND',
												array(
														  'key'     => 'post_type_'.$post_type.'',
														  'value'   => array($post_type,'all'),
														  'compare' => 'IN',
														  'type'    => 'text'
												),
												array(
														  'key'     => 'is_active',
														  'value'   =>  '1',
														  'compare' => '='
												),
												array(
														  'key'     => 'show_on_listing',
														  'value'   =>  '1',
														  'compare' => '='
												)
									  ),
				'meta_key' => 'sort_order',
				'orderby' => 'meta_value',
				'order' => 'ASC'
		),$post_type);
          
	remove_all_actions('posts_where');
	$post_query = null;
	remove_action('pre_get_posts','event_manager_pre_get_posts');
	remove_action('pre_get_posts','directory_pre_get_posts',12);
	add_filter('posts_join', 'custom_field_posts_where_filter');
	/* Set the results in transient to get fast results */
	if (get_option('tevolution_cache_disable')==1  && false === ( $post_query = get_transient( '_tevolution_query_taxo'.trim($post_type).trim($heading_key).$cur_lang_code  ) )  ) {
		$post_query = new WP_Query($args);
		set_transient( '_tevolution_query_taxo'.trim($post_type).trim($heading_key).$cur_lang_code, $post_query, 12 * HOUR_IN_SECONDS );
	}elseif(get_option('tevolution_cache_disable')==''){
		$post_query = new WP_Query($args);
	}

	remove_filter('posts_join', 'custom_field_posts_where_filter');

	$htmlvar_name='';
	if($post_query->have_posts())
	{
		while ($post_query->have_posts()) : $post_query->the_post();
			$ctype = get_post_meta($post->ID,'ctype',true);
			$post_name=get_post_meta($post->ID,'htmlvar_name',true);
			$style_class=get_post_meta($post->ID,'style_class',true);
			$label=get_post_meta($post->ID,'admin_title',true);
			$option_title=get_post_meta($post->ID,'option_title',true);
			$option_values=get_post_meta($post->ID,'option_values',true);

			$htmlvar_name[$post_name] = array( 'type'=>$ctype,
                                                                                                    'htmlvar_name'=> $post_name,
                                                                                                    'style_class'=> $style_class,
                                                                                                    'option_title'=> $option_title,
                                                                                                    'option_values'=> $option_values,
                                                                                                    'label'=> $post->post_title
                                                                                            );
			$posttitle[] = $post->post_title;
		endwhile;
		wp_reset_query();
	}
	
	return $htmlvar_name;
}

/*
 *This function will return the search page map listings
 */
add_action('wp_ajax_nopriv_classified_search_map','directory_classified_search_map');
add_action('wp_ajax_classified_search_map','directory_classified_search_map');
function directory_classified_search_map(){
	global $wp_query,$wpdb,$current_cityinfo;

	$per_page=get_option('posts_per_page');
	if(isset($_REQUEST['term_id']) && $_REQUEST['term_id']!=""){
		$taxonomies = get_object_taxonomies( (object) array( 'post_type' => 'classified','public'   => true, '_builtin' => true ));
		$args=array(
				 'post_type'      => 'classified',
				 'posts_per_page' => $per_page,
				 'post_status'    => 'publish',
				 'tax_query'      => array(
										  array(
											 'taxonomy' => $taxonomies[0],
											 'field'    => 'id',
											 'terms'    => explode(',',$_REQUEST['term_id']),
											 'operator' => 'IN'
										  )
									   ),
				);

	}else{
		$args=array(
				 'post_type'      => 'classified',
				 'posts_per_page' => $per_page,
				 'post_status'    => 'publish',
				 );
	}
	directory_manager_classified_custom_field();
	if(is_plugin_active('sitepress-multilingual-cms/sitepress.php')){
		add_filter('posts_where', 'wpml_listing_milewise_search_language');
	}
	
	add_action('pre_get_posts','classified_search_get_posts');
	add_filter( 'posts_where', 'directory_classified_search_posts_where', 10, 2 );
	if(is_plugin_active('Tevolution-LocationManager/location-manager.php'))
	{
		add_filter('posts_where', 'location_multicity_where');
	}
	$post_details= new WP_Query($args);
	if(is_plugin_active('Tevolution-LocationManager/location-manager.php'))
	{
		remove_filter('posts_where', 'location_multicity_where');
	}
	if(is_plugin_active('sitepress-multilingual-cms/sitepress.php')){
		remove_filter('posts_where', 'wpml_listing_milewise_search_language');
	}
	$term_icon='';
	if(isset($_REQUEST['taxonomy']) && $_REQUEST['taxonomy']!='' && isset($_REQUEST['slug']) && $_REQUEST['slug']!=''){
		$term=get_term_by( 'slug',$_REQUEST['slug'] , $_REQUEST['taxonomy'] ) ;
		$term_icon=$term->term_icon;
	}
		
	if ($post_details->have_posts()) :
	$pids=array();
		while ( $post_details->have_posts() ) : $post_details->the_post();
			$ID =get_the_ID();
			$title = get_the_title($ID);
			$plink = get_permalink($ID);
			$lat = get_post_meta($ID,'geo_latitude',true);
			$lng = get_post_meta($ID,'geo_longitude',true);					
			$address = stripcslashes(str_replace($srcharr,$replarr,(get_post_meta($ID,'address',true))));
			$contact = str_replace($srcharr,$replarr,(get_post_meta($ID,'phone',true)));
			$website = get_post_meta($ID,'website',true);
			/*Fetch the image for display in map */
			if ( has_post_thumbnail()){
				$post_img = wp_get_attachment_image_src( get_post_thumbnail_id(), 'thumbnail');
				$post_images=$post_img[0];
			}else{
				$post_img = bdw_get_images_plugin($ID,'thumbnail');
				$post_images = $post_img[0]['file'];
			}

			$imageclass='';
			if($post_images)
				$post_image='<div class=map-item-img><img src='.$post_images.' width=150 height=150/></div>';
			else{
				$post_image='';
				$imageclass='no_map_image';
			}
			
			if($term_icon=='')
				$term_icon=apply_filters('tmpl_default_map_icon',TEVOLUTION_CLASSIFIEDS_URL.'images/pin.png');
			
			$image_class=($post_image)?'map-image' :'';
			$comment_count= count(get_comments(array('post_id' => $ID)));
			$review=($comment_count ==1 )? __('review','classifieds'):__('reviews','classifieds');

			if(($lat && $lng )&& !in_array($ID,$pids))
			{ 	
				$retstr ='{';
				$retstr .= '"name":"'.$title.'",';
				$retstr .= '"location": ['.$lat.','.$lng.'],';
				$retstr .= '"message":"<div class=\"google-map-info '.$image_class.'\"><div class=map-inner-wrapper><div class=\"map-item-info '.$imageclass.'\">'.$post_image;
				$retstr .= '<h6><a href='.$plink.' class=ptitle><span>'.$title.'</span></a></h6>';
				if($address){$retstr .= '<p class=address>'.$address.'</p>';}
				if($contact){$retstr .= '<p class=contact>'.$contact.'</p>';}
				if($website){$retstr .= '<p class=website><a href= '.$website.'>'.$website.'</a></p>';}
				if($templatic_settings['templatin_rating']=='yes'){
					$rating=draw_rating_star_plugin(get_post_average_rating(get_the_ID()));
					$retstr .= '<div class=map_rating>'.str_replace('"','',$rating).' <span><a href='.$plink.'#comments>'.$comment_count.' '.$review.'</a></span></div>';
				}else{
					$retstr .= apply_filters('show_map_multi_rating',get_the_ID(),$plink,$comment_count,$review);
				}
				$retstr .= '</div></div></div>';
				$retstr .= '",';
				$retstr .= '"icons":"'.$term_icon.'",';
				$retstr .= '"pid":"'.$ID.'"';
				$retstr .= '}';
				$content_data[] = $retstr;
				$j++;
			}

			$pids[]=$ID;
		endwhile;
		wp_reset_query();	
		
	endif;
	if($content_data)
		$cat_content_info[]= implode(',',$content_data);

	if($cat_content_info){
		$catinfo_arr= '{"markers":['.implode(',',$content_data)."]}";
	}else{
		$catinfo_arr= '{"markers":[]}';
	}
	echo $catinfo_arr;	
	exit;
}
?>