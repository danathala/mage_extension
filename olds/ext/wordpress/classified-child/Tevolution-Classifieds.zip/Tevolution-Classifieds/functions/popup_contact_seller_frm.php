<div id="contact_seller_div" class="reveal-modal tmpl_login_frm_data clearfix" data-reveal>
<?php global $post,$wp_query; ?>
    <form name="contact_seller_frm" id="contact_seller_frm" action="#" method="post"> 
        <input type="hidden" id="listing_id" name="listing_id" value="<?php _e($post->ID,'classifieds'); ?>"/>
        <input type="hidden" id="request_uri" name="request_uri" value="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?>"/>
        <input type="hidden" id="link_url" name="link_url" value="<?php	the_permalink();?>"/>
        <?php $userdata = get_userdata($post->post_author); ?>  
        <input type="hidden" name="to_name" id="to_name" value="<?php _e($userdata->display_name,'classifieds');?>" />
        <?php $to_email = (get_post_meta($post->ID,'email',true)!="")? get_post_meta($post->ID,'email',true): get_the_author_meta( 'user_email', $post->post_author )  ; ?>
        <input type="hidden" id="contact_author_email" name="contact_author_email" value="<?php echo $to_email; ?>"/>
        <div class="email_to_friend">
        	<h3 class="h3"><?php _e("Contact Seller",'classifieds'); ?></h3>
        	<a class="modal_close" href="#"></a>
    	</div>
          <?php $tmpdata = get_option('templatic_settings');?>          
            <div class="form_row clearfix" > <label><?php _e("Name",'classifieds');?><span class="indicates">*</span></label> <input name="contact_full_name" id="contact_full_name" type="text"  /><span id="contact_full_nameInfo"></span></div>
        
            <div class="form_row clearfix" > <label><?php _e("Email",'classifieds');?><span class="indicates">*</span></label>  <input name="contact_your_iemail" id="contact_your_iemail" type="text"  /><span id="contact_your_iemailInfo"></span></div>
            
            <div class="form_row clearfix" ><label><?php _e("Subject",'classifieds');?><span class="indicates">*</span></label> <input name="contact_inq_sub" id="contact_inq_sub" type="text"  /><span id="contact_inq_subInfo"></span></div>	
            
            <div class="form_row  clearfix" ><label> <?php _e('Message','classifieds'); ?>: <span class="indicates">*</span></label> 
				<textarea rows="5" name="contact_inq_msg" id="contact_inq_msg"></textarea><span id="contact_inq_msgInfo"></span></div>
				<div id="contact_seller_frm_popup"></div>
            <div class="send_info_button clearfix" >
            	<input name="Send" type="submit" value="<?php _e('Send','classifieds'); ?>" class="button send_button" />
               <span id="process_state" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i></span>
              	<strong id="contact_us_msg" class="process_state"></strong>
				
		  </div>
    </form>
</div>
<?php 
	global $post;
	$current_post_id = $post->ID;
?>
<script>
var $q = jQuery.noConflict();
$q(document).ready(function(){
/*global vars*/
	var enquiry1frm = $q("#contact_seller_frm");
	var full_name = $q("#contact_full_name");
	var full_nameInfo = $q("#contact_full_nameInfo");
	var your_iemail = $q("#contact_your_iemail");
	var your_iemailInfo = $q("#contact_your_iemailInfo");
	var sub = $q("#contact_inq_sub");
	var subinfo = $q("#contact_inq_subInfo");
	var frnd_comments = $q("#contact_inq_msg");
	var frnd_commentsInfo = $q("#contact_inq_msgInfo");
	/*On blur*/
	full_name.blur(validate_full_name1);
	your_iemail.blur(validate_your_iemail);
	sub.blur(validate_subject);
	frnd_comments.blur(validate_frnd_comments);
	frnd_comments.keyup(validate_frnd_comments);
	/*On Submitting*/
	
	enquiry1frm.submit(function(){
		
		if(validate_full_name1() & validate_your_iemail() & validate_subject() & validate_frnd_comments())
		{ 
			document.getElementById('process_state').style.display="block";
			var inquiry_data = enquiry1frm.serialize();				
			jQuery.ajax({
				url:ajaxUrl,
				type:'POST',
				data:'action=classifieds_contact_seller&' + inquiry_data + '&postid=' + <?php echo $current_post_id; ?>,
				success:function(results) {
					if(results==1){
						jQuery('#contact_us_msg').html(captcha_invalid_msg);
					}else{				
					document.getElementById('process_state').style.display="none";					
						jQuery('#contact_us_msg').html(results);
						setTimeout(function(){
									jQuery("#lean_overlay").fadeOut(200);
									jQuery('.reveal-modal-bg').css({"display":"none"});
									jQuery('#contact_seller_div').css({"display":"none"});
									jQuery('#contact_us_msg').html('');
									full_name.val('');
									your_iemail.val('');
									sub.val('');
									frnd_comments.val('');},2000); 
					}
				}
			});
			return false;
		}
		else
		{ 
			
			return false;
		}
	});
	
	/*validation functions*/
	function validate_full_name1()
	{	
		if(full_name.val() == '')
		{
			full_name.addClass("error");
			full_nameInfo.text("<?php _e('Please enter your full name','classifieds');?>");
			full_nameInfo.addClass("message_error2");
			return false;
		}else{
			full_name.removeClass("error");
			full_nameInfo.text("");
			full_nameInfo.removeClass("message_error2");
			return true;
		}
	}
	function validate_your_iemail()
	{ 
		var isvalidemailflag = 0;
		if(your_iemail.val() == '')
		{
			isvalidemailflag = 1;
		}else {
			if(your_iemail.val() != '')
			{
				var a = your_iemail.val();
				var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
				/*if it's valid your_iemail*/
				if(filter.test(a)){
					isvalidemailflag = 0;
				}else{
					isvalidemailflag = 1;	
				}
			}
		}
		if(isvalidemailflag == 1)
		{
			your_iemail.addClass("error");
			your_iemailInfo.text("<?php _e('Please enter your valid email address','classifieds');?>");
			your_iemailInfo.addClass("message_error2");
			return false;
		}else
		{
			your_iemail.removeClass("error");
			your_iemailInfo.text("");
			your_iemailInfo.removeClass("message_error");
			return true;
		}
		
	}
	function validate_subject()
	{ 
		if($q("#contact_inq_sub").val() == '')
		{
			sub.addClass("error");
			subinfo.text("<?php _e('Please enter subject line','classifieds');?>");
			subinfo.addClass("message_error2");
			return false;
		}
		else{
			sub.removeClass("error");
			subinfo.text("");
			subinfo.removeClass("message_error2");
			return true;
		}
	}
	
	function validate_frnd_comments()
	{
		if($q("#contact_inq_msg").val() == '')
		{
			frnd_comments.addClass("error");
			frnd_commentsInfo.text("<?php _e('Please enter message','classifieds');?>");
			frnd_commentsInfo.addClass("message_error2");
			return false;
		}else{
			frnd_comments.removeClass("error");
			frnd_commentsInfo.text("");
			frnd_commentsInfo.removeClass("message_error2");
			return true;
		}
	}
});
</script>
