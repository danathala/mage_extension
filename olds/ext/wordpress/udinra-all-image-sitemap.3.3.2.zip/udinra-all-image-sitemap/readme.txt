=== Udinra All Image Sitemap ===
Contributors: Udinra
Donate link: https://udinra.com/
Tags: xml sitemaps, google sitemaps, image sitemap, seo, search engines, sitemap,google image sitemap,wordpress seo
Requires at least: 2.1
Tested up to: 4.4
Stable tag: 3.3.2
License: GPLv2 or later

Automatically creates Image sitemap and pings Google,Bing and Ask.com

== Description ==

Automatically creates Google XML sitemap for images and pings Google,Bing and Ask.com.

<strong>Udinra Image Sitemap Pro Features</strong>

<ul><li>eCommerce plugin support (WooCommerce,WP eCommerce,Easy Digital Downloads etc)</li>
<li>Only Image Sitemap plugin to support NextGen Gallery.(only shortcodes supported)</li>
<li>Generates ALT text</li>
<li>Index Sitemap functionality</li>
<li>Supports Large Website with limited resources</li>
<li>Increased Google Search Visibility</li></ul>
<br />
You can buy Pro Version at <a href="https://udinra.com/downloads/udinra-image-sitemap-pro">Udinra Image Sitemap Pro</a>
<br />
https://www.youtube.com/watch?v=kDigPavSaPI
<br />
You may also be interested in <a href="https://udinra.com/downloads/udinra-image-sitemap-pro">Udinra Video Sitemap Pro</a>.The plugin creates video sitemap from videos embedded on your website.Currently the plugin supports 
<ul>
<li>YouTube</li>
<li>Vimeo</li>
<li>Dailymotion</li>
<li>Twitch</li>
<li>Facebook</li>
</ul>

== Installation ==

The plugin can be installed like any other plugin.You can search from WordPress Dashboard (Udinra Image Sitemap) and click install to install it.You can also download it and upload it to your server wp-content/plugins directory and extract the zip file.

== Frequently Asked Questions ==

https://udinra.com/blog/udinra-image-sitemap

== Screenshots ==

N/A.

== Changelog ==

= 3.3.2 =

Clubbed Ping Google,Bing and Ask options to single option Ping Search Engines.Also WordPress 4.4 compatible.

= 3.3.1 =

Compatible with WordPress 4.3.1 and minor compatibility fixes with other plugins.

= 3.2 =

Compatible with WordPress 4.2.1

= 3.1 =

Minor bug fixes

= 3.0 =

Handled Draft post and other small bugs,code enhancements

= 2.9 =

Handled Unattached image bug

= 2.8 =

Link to generated sitemap on plugin configuration page
Small code cleanup

= 2.7 =

Compatibility with other sitemap plugins

= 2.6 =

Special character handlingin URL

= 2.5 =

Search engine ping issue resolved

= 2.4 =

Fixed xsl issue.
Code changes for pinging search engines

= 2.3 =

Minor code fix

= 2.2 =

Minor verbiage fix

= 2.1 =

Option to control automatic generation of sitemap.
Sitemap generated automatically if post contains images
minor coding enhancements
XSL support

= 2.0 =

Pings gzipped version to search engines if gzipped version is created

= 1.9 =

Option to generate gzipped version of image sitemap

= 1.8 =

Fixed special characters in title and caption issue.

== Upgrade Notice ==

Compatible with WordPress 4.3.1 and minor compatibility fixes with other plugins.