<?php

class Sbridge_Advcashondelivery_Block_Cod extends Mage_Core_Block_Template {
	
	public function testMethod() {
		
		//code goes here;
		
	}
}
