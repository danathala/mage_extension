<?php

    /**
    * Setubridge Technolabs
    * http://www.setubridge.com/
    * @author SetuBridge
    * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
    **/
?>
 <?php

class Sbridge_Advcashondelivery_Helper_Data extends Mage_Core_Helper_Abstract
{
 
}
?>