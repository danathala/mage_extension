<?php
/**
 * Adminhtml base helper
 *
 * @category   Mageworks
 * @package    Mageworks_Core
 * @author     mageworks kumar <mageworksnsscoe@gmail.com>
 */
class Mageworks_Core_Helper_Data extends Mage_Core_Helper_Abstract
{

}