<?php
/**
 * Adminhtml base helper
 *
 * @category   Mageworks
 * @package    Mageworks_Import
 * @author     mageworks kumar <mageworksnsscoe@gmail.com>
 */
class Mageworks_Import_Helper_Data extends Mage_Core_Helper_Abstract
{
}