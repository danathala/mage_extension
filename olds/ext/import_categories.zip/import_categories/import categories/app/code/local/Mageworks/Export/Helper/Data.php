<?php
/**
 * Adminhtml base helper
 *
 * @category   Mageworks
 * @package    Mageworks_Export
 * @author     mageworks kumar <mageworksnsscoe@gmail.com>
 */
class Mageworks_Export_Helper_Data extends Mage_Core_Helper_Abstract
{
}