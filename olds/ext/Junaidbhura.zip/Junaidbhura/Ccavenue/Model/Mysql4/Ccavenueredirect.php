<?php
class Junaidbhura_Ccavenue_Model_Mysql4_Ccavenueredirect extends Mage_Core_Model_Mysql4_Abstract {
    protected function _construct() {
        $this->_init( 'ccavenue/ccavenueredirect', 'ccavenue_redirect_id' );
    }
}