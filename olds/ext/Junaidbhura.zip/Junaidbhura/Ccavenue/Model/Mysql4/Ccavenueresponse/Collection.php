<?php
class Junaidbhura_Ccavenue_Model_Mysql4_Ccavenueresponse_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract {
	public function _construct(){
		$this->_init( 'ccavenue/ccavenueresponse' );
	}
}