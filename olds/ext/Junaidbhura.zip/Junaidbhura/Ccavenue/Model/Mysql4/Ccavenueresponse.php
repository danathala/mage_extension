<?php
class Junaidbhura_Ccavenue_Model_Mysql4_Ccavenueresponse extends Mage_Core_Model_Mysql4_Abstract {
    protected function _construct() {
        $this->_init( 'ccavenue/ccavenueresponse', 'ccavenue_response_id' );
    }
}