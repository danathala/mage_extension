<?php
/**
 * Ccavenueresponse model
 *
 * @category    Model
 * @package     Junaidbhura_Ccavenue
 * @author      Junaid Bhura <info@junaidbhura.com>
 */

class Junaidbhura_Ccavenue_Model_Ccavenueresponse extends Mage_Core_Model_Abstract {
    protected function _construct(){
       $this->_init( 'ccavenue/ccavenueresponse' );
    }
}