<?php
/*
Plugin Name: Custom Status Helper
Plugin URI: http://agapetry.net/
Description: Registers an "Approved" status as an intermediate moderation between Pending and Published.  Defines Reviewer role as able to approve (but not publish) pending posts.  Also defines a custom Private status, "Secret".  Defines and enforces corresponding status-specific capabilities.  Requires WP changes proposed for 
Version: 1.0
Author: Kevin Behrens
Author URI: http://agapetry.net/
Min WP Version: 3.0
License: GPL version 2 - http://www.opensource.org/licenses/gpl-license.php
*/

/*
Copyright (c) 2010, Kevin Behrens.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
version 2 as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

define( 'REGISTER_CUSTOM_PRIVATE_STATUS', true );
define( 'REGISTER_CUSTOM_MODERATION_STATUS', true );

$as_ref = new Approved_Status(); 

class Approved_Status {
	
	function Approved_Status() {
		add_action( 'init', array( &$this, 'init'), 1 );
		add_action( 'init', array( &$this, 'add_wp_roles') );
		add_action( 'init', array( &$this, 'define_post_caps'), 50 );
		add_action( 'init', array( &$this, 'supplement_wp_role_caps'), 100 );
		
		add_filter( 'map_meta_cap',  array( &$this, 'map_meta_cap'), 99, 4 );
		add_filter( 'map_meta_cap',  array( &$this, 'translate_publish_cap'), 99, 4 );
		
		add_filter( 'post_moderation_status',  array( &$this, 'post_moderation_status'), 10, 2 );	
	}

	
	function init() {
		if ( defined( 'REGISTER_CUSTOM_MODERATION_STATUS' ) ) {
			register_post_status( 'approved', array(
				'labels'	  => array( 
					'name' 	  => __( 'Approved', 'approval-status' ),
					'publish' => esc_attr__('Approve'),
					'count' => _n_noop( 'Approved <span class="count">(%s)</span>', 'Approved <span class="count">(%s)</span>' ),
				),
				'protected'   => true,
				'moderation'  => true,
				'show_in_admin_status_list' => true,
			) );
		}

		if ( defined( 'REGISTER_CUSTOM_PRIVATE_STATUS' ) ) {
			register_post_status( 'secret', array(
				'labels'	  => array( 
					'name' 	  => __( 'Secret', 'approval-status' ),
					'caption' => __( 'Secretly Published', 'approval-status' ),
					'count' => _n_noop( 'Secret <span class="count">(%s)</span>', 'Secret <span class="count">(%s)</span>' ),
				),
				'private'   => true,
				'show_in_admin_status_list' => true,
			) );
		}
	}
	
	function define_post_caps() {
		global $wp_post_types, $current_user;
		
		// don't force custom cap definition if logged user is of Administrator role (extra preacaution to ensure Admins are not hindered)
		if ( in_array( 'administrator', $current_user->roles ) )
			return;

		$post_types = array_diff_key( get_post_types( array( 'public' => true ), 'object' ), array( 'attachment' => true ) );
		foreach( $post_types as $_type => $post_type_obj ) {
			if ( $custom_stati = get_post_stati( array( 'internal' => false, '_builtin' => false ), 'object' ) ) {
				$status_caps = array();	
				
				foreach( $custom_stati as $_status => $_status_obj ) {
					$status_caps = array_merge( $status_caps, array( "set_{$_status}_posts" => "set_{$_status}_{$_type}s", "edit_{$_status}_posts" => "edit_{$_status}_{$_type}s", "delete_{$_status}_posts" => "delete_{$_status}_{$_type}s" ) );
		
					if ( $_status_obj->private )
						$status_caps[ "read_{$_status}_posts" ] = "read_{$_status}_{$_type}s";
				}

				foreach( $status_caps as $post_cap_name => $type_cap_name ) {
					if ( empty( $wp_post_types[$_type]->cap->$post_cap_name ) )
						$wp_post_types[$_type]->cap->$post_cap_name = $type_cap_name;
				}
			}
		}
	}

	function add_wp_roles() {
		global $wp_roles;
		if ( !isset( $wp_roles ) ) $wp_roles = new WP_Roles();
		
		if ( ! get_role( 'reviewer') ) {
			$caps = $wp_roles->get_role('contributor')->capabilities;
			$wp_roles->add_role( 'reviewer', 'Reviewer', $caps );
		}
		
		if ( ! get_role( 'super') ) {
			$caps = $wp_roles->get_role('editor')->capabilities;
			$wp_roles->add_role( 'super', 'Super Editor', $caps );
		}
	}
	
	function supplement_wp_role_caps() {
		global $wp_roles;
		
		$role_names = array( 'reviewer', 'editor', 'super', 'administrator' );
		
		foreach( $role_names as $role_name ) {
			if ( isset( $wp_roles->roles[$role_name] ) ) {
				$post_types = array_diff_key( get_post_types( array( 'public' => true ), 'object' ), array( 'attachment' => true ) );
				
				foreach( $post_types as $_type => $_type_obj ) {
					$add_caps = array();
					$cap = $_type_obj->cap;
					
					if ( $custom_stati = get_post_stati( array( 'internal' => false, '_builtin' => false ), 'object' ) ) {
						foreach( $custom_stati as $_status => $_status_obj ) {
							if ( $_status_obj->private && ! in_array( $role_name, array( 'super', 'administrator' ) ) )
								continue;

							$status_caps = array_fill_keys( array( "set_{$_status}_{$_type}s", "edit_{$_status}_{$_type}s", "delete_{$_status}_{$_type}s" ), true );
							
							if ( $_status_obj->private )
								$status_caps[ "read_{$_status}_{$_type}s" ] = true;
	
							$add_caps = array_merge( $add_caps, $status_caps );
						}
						
						$caps = array_fill_keys( array( "edit_{$_type}s", "edit_others_{$_type}s", "delete_{$_type}s", "delete_others_{$_type}s" ), true );
						$add_caps = array_merge( $add_caps, $caps );
						
						$wp_roles->roles[$role_name]['capabilities'] = array_merge( $wp_roles->roles[$role_name]['capabilities'], $add_caps );
						$wp_roles->role_objects[$role_name]->capabilities = array_merge( $wp_roles->role_objects[$role_name]->capabilities, $add_caps );
					}
				}
			}
		}
	}
	
	
	function map_meta_cap( $caps, $meta_cap, $user_id, $args ) {
		static $defined_meta_caps;
	
		if ( ! isset( $defined_meta_caps ) ) {
			$defined_meta_caps = array();
	
			$post_types = array_diff_key( get_post_types( array( 'public' => true ), 'object' ), array( 'attachment' => true ) );
	
			foreach( $post_types as $type => $post_type_obj ) {
				$defined_meta_caps ['read'] []= $post_type_obj->cap->read_post;
				$defined_meta_caps ['edit'] []= $post_type_obj->cap->edit_post;
				$defined_meta_caps ['delete'] []= $post_type_obj->cap->delete_post;
			}
		}
	
		$matched_op = false;
		foreach( array_keys($defined_meta_caps) as $op ) {
			if ( in_array( $meta_cap, $defined_meta_caps[$op] ) ) {
				$matched_op = $op;
				break;	
			}
		}
		
		if ( ! $matched_op )
			return $caps;
	
		$_obj_id = ( is_array($args) ) ? $args[0] : $args;
		if ( ! $post = get_post( $_obj_id ) )
			return $caps;
	
		if ( in_array( $post->post_type, array( 'revision', 'attachment' ) ) )
			$post = get_post( $post->post_parent );	
			
		if ( ! $post_type_obj = get_post_type_object( $post->post_type ) )
			return $caps;
	
		if ( ! $post_status_obj = get_post_status_object( $post->post_status ) )
			return $caps;
	
		// if a capability is defined for this custom status, require it also
		if ( empty($post_status_obj->_builtin) ) {
			$status_cap_name = "{$op}_{$post->post_status}_posts";
			if ( ! empty( $post_type_obj->cap->$status_cap_name ) )
				$caps []= $post_type_obj->cap->$status_cap_name;
		}
	
		$caps = array_unique( $caps );
	
		return $caps;
	}


	// this serves as a 'map_meta_cap' function when publishing as a custom status which also has an additional set_status cap defined
	function translate_publish_cap( $caps, $meta_cap, $user_id, $args ) {
		static $defined_publish_caps;
	
		if ( ! isset( $defined_publish_caps ) ) {
			$defined_publish_caps = array();
	
			$post_types = array_diff_key( get_post_types( array( 'public' => true ), 'object' ), array( 'attachment' => true ) );
	
			foreach( $post_types as $_type => $post_type_obj )
				$defined_publish_caps [$_type]= $post_type_obj->cap->publish_posts;
		}
	
		$post_type = array_search( $meta_cap, $defined_publish_caps );
		if ( false === $post_type )
			return $caps;
	
		$_obj_id = ( is_array($args) ) ? $args[0] : $args;
		if ( ! $post = get_post( $_obj_id ) )
			return $caps;
	
		if ( in_array( $post->post_type, array( 'revision', 'attachment' ) ) )
			$post = get_post( $post->post_parent );	
			
		if ( ! $post_type_obj = get_post_type_object( $post->post_type ) )
			return $caps;
	
		$cap_name = "set_{$post->post_status}_posts";
		if ( ! empty( $post_type_obj->cap->$cap_name ) ) {
			$caps = array_diff( $caps, array( $publish_cap ) );
			$caps []= $post_type_obj->cap->$cap_name;
		}
	
		return $caps;
	}

	
	function post_moderation_status( $moderation_status, $post_id ) {
		// WP will be dropped this to 'pending' if user doesn't have set_approved_posts capability
		return 'approved';
		
		// === possible future use if more than one additional moderation status ===
		/* 
		$moderation_stati = get_post_stati( array( 'moderation' => true, 'internal' => false ), 'object' );
	
		$moderation_sequence = array();
		
		foreach( $moderation_stati as $_status => $_status_obj ) { 
			$set_cap = "set_{$_status}_posts";
			if ( ( $_status != $post_status ) && ( ! empty( $post_type_object->cap->$set_cap ) && ! current_user_can( $post_type_object->cap->$set_cap ) ) )
				unset( $moderation_stati[$_status] );
			else		
				$moderation_sequence[$_status] = ( isset( $_status_obj->moderation_step ) ) ? $_status_obj->moderation_step : 0;
		}
		
		if ( $moderation_sequence ) {
			asort( $moderation_sequence );
			$moderation_sequence = array_flip( $moderation_sequence );
			$moderation_status = array_pop( $moderation_sequence );
		}
	
		return $moderation_status;
		*/
	}
	
} // end class

?>