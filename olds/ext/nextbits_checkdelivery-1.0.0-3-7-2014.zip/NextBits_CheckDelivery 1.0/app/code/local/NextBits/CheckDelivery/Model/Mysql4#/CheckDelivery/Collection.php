<?php

class NextBits_CheckDelivery_Model_Mysql4_CheckDelivery_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('checkdelivery/checkdelivery');
    }
}