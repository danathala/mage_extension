jQuery(document).on('ready',function(){
	jQuery(document).on('submit','form#coupons',generateRows);
	// jQuery(document).on('submit','form#generateCoupon',handleRequest);
	jQuery(document).on('submit','form#generateCoupon',validateBothEnd);
	jQuery(document).on('click','button.remove_row',remove_row);
});

//creating random String
function randomString(length) {
	var chars	=	new Date().getTime() + 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	var result = '';
	for (var i = length; i > 0; --i) {
		result += chars[Math.round(Math.random() * (chars.length - 1))];
	}
	return result;
}

//creating coupon rows
function generateRows (e) {
	showHideMageLoader(true);
	e.preventDefault();
	var this_elem	=	e;
	var this_e		=	jQuery(this);
	var generate	=	jQuery('input.generate').val();
	//console.log(generate);

	var html	=	'';
	for($x = 0; $x < generate; $x++) {

		var row			=	document.createElement('div');
		
		row.className	=	'row';
		
		var single1		=	document.createElement('div');
		single1.setAttribute('class','row_' + $x + ' col_1 col');
		var code		=	document.createElement('input');
		code.setAttribute('class','code required-entry');
		code.setAttribute('type','text');
		code.setAttribute('value',randomString(8));
		code.setAttribute('name','code[' + $x + ']');
		// code.setAttribute('placeholder','Coupon Code');
		code.setAttribute('readonly',true);
		single1.appendChild(code);
		
		var single2		=	document.createElement('div');
		single2.setAttribute('class','row_' + $x + ' col_2 col');
		var serial		=	document.createElement('input');
		serial.setAttribute('class','serial required-entry');
		serial.setAttribute('type','text');
		serial.setAttribute('name','serial[' + $x + ']');
		serial.setAttribute('placeholder','Coupon Serial');
		single2.appendChild(serial);

		var single3		=	document.createElement('div');
		single3.setAttribute('class','row_' + $x + ' col_3 col');
		var cost		=	document.createElement('input');
		cost.setAttribute('class','cost required-entry validate-number');
		cost.setAttribute('type','text');
		cost.setAttribute('name','cost[' + $x + ']');
		cost.setAttribute('placeholder','Coupon Cost');
		single3.appendChild(cost);
		
		var single4		=	document.createElement('div');
		single4.setAttribute('class','row_' + $x + ' col_4 col');
		var removeButton		=	document.createElement('button');
		removeButton.setAttribute('class','cost button remove_row');
		removeButton.setAttribute('value','Remove Row');
		removeButton.setAttribute('type','button');
		removeButton.innerHTML	=	"<span>Remove Row</span>";
		single4.appendChild(removeButton);
		
		row.appendChild(single1);
		row.appendChild(single2);
		row.appendChild(single3);
		row.appendChild(single4);
		
		document.getElementById('rows').appendChild(row);
	}

	var button			=	document.createElement('button');
	button.setAttribute('type', 'submit');
	button.setAttribute('value', 'SubmitValues');
	button.setAttribute('class', 'submit SubmitValues');
	button.innerHTML	=	"<span>Submit Values</span>";
	//button.appendChild(span);
	document.getElementById('rows').appendChild(button);
	
	jQuery('.generate_mulitple').attr('disabled',true).addClass('disabled');
	
	showHideMageLoader(false);
	
	return false;

}

//saving the coupon rows to database;
function handleRequest () {
	// e.preventDefault();
	// var this_form	=	jQuery(this);
	var this_form	=	jQuery('form#generateCoupon');
	var form_data	=	this_form.serialize();
	// form_data.form_key	=	window.FORM_KEY;
	
	jQuery.ajax({
		/* beforeSend: function() {
			showHideMageLoader(true);
		}, */
		type: 'POST',
		url: this_form.attr('action'),
		data: form_data,
		dataType: 'json',
		success: function (response) {
			if(response.result == false) {
				console.log('result is false');
			} else {
				jQuery('div.rows .row').remove();
				jQuery('button.SubmitValues').remove();
				jQuery('.generate_mulitple').removeAttr('disabled').removeClass('disabled');
				show_message ('success', response.success, false);
			}
		},
		complete: function() {
			showHideMageLoader(false);
		}
	});
}

//removing coupon rows
function remove_row (e) {
	
	showHideMageLoader(true)
	
	e.preventDefault();
	var this_e		=	jQuery(this);
	var parent_row	=	this_e.parents('div.row');
	
	var delete_confirm	=	confirm("Are You sure");
	
	if(!delete_confirm) return false;
	
	parent_row.css('background-color', '#eee2be');
	
	parent_row.fadeOut('slow', function() {
		parent_row.remove();
	});
	
	show_message ('notice', 'Row Removed', true);
	
	showHideMageLoader(false)

}

//handling javascript messages
function show_message (type, message, autoHide) {
	
	var messageUnique	=	randomString(5);
	var html = '<ul class="messages ' + messageUnique + '">';

	if(type == 'success') {
		html	+=	'<li class="success-msg">';
	} else if (type == 'error') {
		html	+=	'<li class="error-msg">';
	} else if (type == 'warning') {
		html	+=	'<li class="warning-msg">';
	} else if (type == 'notice') {
		html	+=	'<li class="notice-msg">';
	}
	
	html	+=	'<ul><li><span>' + message + '</span></li></ul>';
	
	html +=	'</li></ul>';
	
	jQuery('div#messages').append(html);
	
	if(autoHide == true) {
		setTimeout(function(){
			jQuery('ul.messages.' + messageUnique).fadeOut('slow', function() {
				jQuery('ul.messages.' + messageUnique).remove();
			});
		}, 3000);
	}
}

//handling magento loader
function showHideMageLoader(show) {
	
	var this_e	=	jQuery('#loading-mask');
	
	if(show) {
		this_e.show();
	} else {
		this_e.hide();
	}
	
}