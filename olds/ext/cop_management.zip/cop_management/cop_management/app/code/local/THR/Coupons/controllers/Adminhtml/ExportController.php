<?php
class THR_Coupons_Adminhtml_ExportController extends Mage_Adminhtml_Controller_Action {
	
	public function indexAction() {
		$this->loadLayout();
		$this->_title($this->__("Coupon Management"));
			
			//$rule = Mage::getModel('salesrule/rule');
			
			//$collection	=	$rule->getCollection()->getSelect()->columns('rule_coupons.usage_limit')->group(array('rule_id'));
			// $collection	=	$rule->getCollection()->addFieldToSelect('rule_coupons.usage_limit');
			
			
			//echo $collection->__toString();
			
			// $collection->printLogQuery(true);
				// ->addAttributeToSelect(array('rule_id,name,code'));
			
			//print_r($collection);
			
			//$this->_getResults();
			
			
			$this->renderLayout();
	
		
	}
	
	public function postAction() {
		
		//print_r($_POST);
		$post	=	$this->getRequest()->getPost();
		
		if($post) {
			
			$from	=	date('Y-m-d', strtotime($post['from']));
			
			$date	=	strtotime($post['to']) + (60 * 60 * 24);
			$to	=	date('Y-m-d', $date);
			
			$result	=	$this->_getResults($from,$to);
			
			if(count($result['data']) > 0) {

				$message	=	'File successfully exported <a download href="' . Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB) . $result['file_name'] . '">Click Here</a> to download';
				Mage::getSingleton('adminhtml/session')->addSuccess($message);
			} else {
				Mage::getSingleton('adminhtml/session')->addError('No Records found matching this date range');
			}

			$this->_redirect('*/*/index');

		}

		$this->_redirect('*/*/index');

	}
	
	private function _getResults($from, $to) {
		
		$data	=	array();
		$data[]	=	array('Name','Discount Amount');
		$write = Mage::getSingleton('core/resource')->getConnection('core_write');
		$query	=	"SELECT main_table.*, rule_coupons.code,rule_coupons.created_at FROM `salesrule` AS main_table INNER JOIN salesrule_coupon AS rule_coupons ON main_table.rule_id = rule_coupons.rule_id WHERE rule_coupons.created_at BETWEEN '{$from}' AND '{$to}'";
		$readresult	=	$write->query($query);

		while($row = $readresult->fetch()) {
			
			/* $data[$row['rule_id']]['rule_id']	=	$row['rule_id'];
			$data[$row['rule_id']]['name']	=	$row['name'];
			$data[$row['rule_id']]['code']	=	$row['code'];
			$data[$row['rule_id']]['discount_amount']	=	number_format($row['discount_amount'],2);
			$data[$row['rule_id']]['created_at']	=	$row['created_at']; */
			
			
			$data[]	=	array(
				//'rule_id'			=> $row['rule_id'],
				'name'				=> $row['name'],
				//'code'				=> $row['code'],
				'discount_amount'	=> $row['discount_amount'],
				//'created_at'		=> $row['created_at'],
			);
			
		}
		
		
		//$file_path = '/your_dir_path/sample.csv'; //file path of the CSV file in which the data to be saved

		//$mage_csv = new Varien_File_Csv(); //mage CSV   
		$file_name	=	 'custom_export/file_' . date('d_m_y_h_i_s',time()) . '.csv';
		//write to csv file
		//$mage_csv->saveData($file_name, $data); //note $products_row will be two dimensional array

		
		//print_r($data);
		
		$fo = fopen($file_name, 'w');

		
		foreach ($data as $fields) {
			//print_r($fields);
		//	echo $put	=	$fields['name'] . '<br />';
			fputcsv($fo, $fields);
		}

		fclose($fo);
		
		
		return array('file_name' => $file_name,'data' => $data);
		
	}
	
	
	
	
}