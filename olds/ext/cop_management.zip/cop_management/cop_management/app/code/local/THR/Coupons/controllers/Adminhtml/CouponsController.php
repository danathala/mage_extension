<?php
class THR_Coupons_Adminhtml_CouponsController extends Mage_Adminhtml_Controller_Action {
	
	//var $_helper	=	Mage::helper('coupons');
	
	public function indexAction() {
		// echo 'hello';
		/* Mage::getSingleton('adminhtml/session')->addNotice('Warning message');
		Mage::getSingleton('adminhtml/session')->addSuccess('Warning message');
		Mage::getSingleton('adminhtml/session')->addError('Warning message');
		Mage::getSingleton('adminhtml/session')->addWarning('Warning message'); */
		$this->loadLayout();
		$this->_title($this->__("Coupon Management"));
		
		$this->renderLayout();
	}
	
	public function getRandomStringAction () {
		//code here
	}
	
	public function postAction() {
		
		if($this->getRequest()->getPost('form_key') == Mage::getSingleton('core/session')->getFormKey()) {
			$post		=	$this->getRequest()->getPost();
			$result	=	false;
			$message	=	'';
			unset($post['form_key']);
			$data	=	$this->_filterArray($post);
			
			$validateResult	=	$this->__validateFilteredData($data); 

			if($validateResult['result'] == true) {
				foreach ($data as $index => $coupon) {
					//print_r($coupon);
					$this->_createDynamicRule($coupon);
				}
				
				$message	=	'Coupons successfully created';
				$result	=	true;
			}
			
			$this->getResponse()->setBody(Mage::helper('core')->jsonEncode(array('result' => $result, 'errors' => $validateResult, 'success' => $message)));
		}
	}
	
	private function _filterArray($post) {
		
		$data	=	array();
		foreach($post as $key => $value) {
			//Concating the first value to sencond coupon vlaue;
			foreach ($value as $index => $ivalue) {
				if($key === 'code') {
					$data[$index]['coupon_code']	=	$ivalue;
				} else if ($key === 'serial') {
					$data[$index]['coupon_code']	.=	'_' . $ivalue;
				} else {
					$data[$index]['coupon_price']	=	$ivalue;
				}
			}
		}
		
		return $data;
	}
	
	public function isExistsAction() {
		
		if($this->getRequest()->getPost('isAjax') && $this->getRequest()->getPost('form_key') == Mage::getSingleton('core/session')->getFormKey()) {
			
			$post	=	$this->getRequest()->getPost();
			$response	=	array('result' => true);
			
			$exists	=	Mage::getResourceModel('salesrule/coupon')->exists($post['serialCode']);
			
			if($exists == true) {
				$response['result']	=	false;
			}

			$this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));
		}
	}
	
	/*
	*	Final checking
	*	@return bool;
	*/
	public function finalCheckAction () {
		
		if($this->getRequest()->getPost('form_key') == Mage::getSingleton('core/session')->getFormKey()) {
			
			$post			=	$this->getRequest()->getPost();
			$response	=	array('result' => true);
			
			$filtered	=	Mage::helper('coupons')->getCouponCodesOnly($post);
			
			$counts		=	array_count_values($filtered);
			$dups			=	array();
			foreach($filtered as $key => $value) {
				
				if($counts[$value] > 1) {
					$dups[$key]	=	$value;
				}
			}
			
			if(count($dups) > 0) {
				$response['result']	=	false;
				$response['dups']		=	$dups;
			}
			
			$this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));

		}
	}
	
	
	
	private function __validateFilteredData ($filtered) {
		
		$response	=	array();
		
		foreach($filtered as $index => $coupon) {
			
			// Mage_SalesRule_Model_Resource_Coupon::exists($coupon['coupon_code']);
			$exists	=	Mage::getResourceModel('salesrule/coupon')->exists($coupon['coupon_code']);
			
			if($exists == true) {
				$response[$index]	=	'This code is already exists!';
				$response['result']	=	false;
			} else {
				$response['result']	=	true;
			}
			
		}
		
		return $response;
		
	}
	
	public function generateAction($validated) { echo 'hello ji'; }
	
	/**
	* Create Shopping Cart Sales Rule with Specific Coupon Code
	*/
	private function _createDynamicRule ($coupon) {
		
		// All customer group ids
		$customerGroupIds = Mage::getModel('customer/group')->getCollection()->getAllIds();
		// SalesRule Rule model
		$rule = Mage::getModel('salesrule/rule');
		
		$code_name	=	explode('_',$coupon['coupon_code']);
		// Rule data
		$rule->setName($code_name[0])
		// ->setDescription($coupon['coupon_code'] . ' Rule description ')
		->setFromDate('')
		->setCouponType(Mage_SalesRule_Model_Rule::COUPON_TYPE_SPECIFIC)
		->setCouponCode($coupon['coupon_code'])
		->setUsesPerCustomer(1)
		->setUsesPerCoupon(1)
		->setCustomerGroupIds($customerGroupIds)
		->setIsActive(1)
		->setConditionsSerialized('')
		->setActionsSerialized('')
		->setStopRulesProcessing(0)
		->setIsAdvanced(1)
		->setProductIds('')
		->setSortOrder(0)
		->setSimpleAction(Mage_SalesRule_Model_Rule::CART_FIXED_ACTION)
		->setDiscountAmount($coupon['coupon_price'])
		->setDiscountQty(1)
		->setDiscountStep(0)
		->setSimpleFreeShipping('0')
		->setApplyToShipping('0')
		->setIsRss(0)
		->setWebsiteIds(array(1));
		// ->setStoreLabels(array('My Rule Frontend Label'));

		// Product found condition type
		/* $productFoundCondition = Mage::getModel('salesrule/rule_condition_product_found')
		->setType('salesrule/rule_condition_product_found')
		->setValue(1)               // 0 == not found, 1 == found
		->setAggregator('all');     // match all conditions */

		// 'Attribute set id 1' product condition
		/* $attributeSetCondition = Mage::getModel('salesrule/rule_condition_product')
		->setType('salesrule/rule_condition_product')
		->setAttribute('attribute_set_id')
		->setOperator('==')
		->setValue(1); */

		// Bind attribute set condition to product found condition
		/* $productFoundCondition->addCondition($attributeSetCondition); */

		// If a product with 'attribute set id 1' is found in the cart
		// //$rule->getConditions()->addCondition($productFoundCondition);
		// Only apply the rule discount to this specific product
		// //$rule->getActions()->addCondition($attributeSetCondition);
		
		// Here we go
		$rule->save();
		
	}
	
	
}