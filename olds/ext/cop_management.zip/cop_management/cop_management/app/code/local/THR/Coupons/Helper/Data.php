<?php
class THR_Coupons_Helper_Data extends Mage_Core_Helper_Abstract {
	
	public function getCouponCodesOnly($post) {
		
		$data	=	array();
		
		unset($post['form_key']);
		
		foreach($post as $key => $value) {
		
			//Concating the first value to sencond coupon vlaue;
			foreach ($value as $index => $ivalue) {
				if($key === 'code') {
					$data[$index]	=	$ivalue;
				} else if ($key === 'serial') {
					$data[$index]	.=	'_' . $ivalue;
				}
			}
		}
		
		return $data;
		
	}
	
}







