<?php
class THR_Coupons_Block_Adminhtml_Coupons extends Mage_Adminhtml_Block_Template {

}