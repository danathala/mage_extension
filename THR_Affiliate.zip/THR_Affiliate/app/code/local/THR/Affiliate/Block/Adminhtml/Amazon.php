<?php  

class THR_Affiliate_Block_Adminhtml_Amazon extends Mage_Adminhtml_Block_Template {

}