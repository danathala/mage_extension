<p><?php _e('The following settings represent the defaults for links on your site. You can also configure the settings for each link on your site individually.'); ?></p>
