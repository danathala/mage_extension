<h4><?php printf(__('Unlock these extra link options with EasyAzon Pro - <a href="%s" target="_blank">Upgrade Today!</a>'), 'http://easyazon.com/why-pro/?utm_source=easyazonplugin&utm_medium=link&utm_campaign=easyazonlinkcreate'); ?></h4>

<ol style="list-style: decimal; padding-left: 1em;">
	<li><?php _e('Automated link cloaking'); ?></li>
	<li><?php _e('Product pop ups (display product info via pop up box)'); ?></li>
	<li><?php _e('Add to cart functionality (increase cookie length - more time to earn commissions)'); ?></li>
	<li><?php _e('Link localization (earn commissions from previously wasted global traffic by automatically converting affiliate links to match the location your website is being visited from: e.g. UK visitors see Amazon.co.uk links)'); ?></li>
	<li><?php _e('Support for multiple affiliate tracking IDs'); ?></li>
</ol>
