<div class="wrap" id="easyazon-popup">
	<?php do_action('easyazon_popup_states'); ?>
</div>
