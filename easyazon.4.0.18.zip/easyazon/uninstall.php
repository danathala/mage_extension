<?php

if(!defined('ABSPATH')) { exit; }

if(!defined('WP_UNINSTALL_PLUGIN')) { exit; }

global $wpdb;

// Remove all EasyAzon related transients

// Remove the EasyAzon settings from the database

