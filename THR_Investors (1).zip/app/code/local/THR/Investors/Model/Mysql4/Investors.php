<?php
class THR_Investors_Model_Mysql4_Investors extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("investors/investors", "id");
    }
}