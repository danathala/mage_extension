<?php  

class THR_Investors_Block_Adminhtml_Investorsbackend extends Mage_Adminhtml_Block_Template {

}