<?php
$installer = $this;
$installer->startSetup();


$installer->addAttribute("catalog_category", "catpdf",  array(
    "type"     => "varchar",
    "backend"  => "catalog/category_attribute_backend_image",
    "frontend" => "",
    "label"    => "Upload PDF",
    "input"    => "image",
    "class"    => "catpdf",
    "source"   => "",
    "global"   => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
    "visible"  => true,
    "required" => false,
    "user_defined"  => false,
    "default" => "",
    "searchable" => false,
    "filterable" => false,
    "comparable" => false,
	
    "visible_on_front"  => false,
    "unique"     => false,
    "note"       => "Upload PDF file to show on investor section"

	));
$installer->endSetup();
	 