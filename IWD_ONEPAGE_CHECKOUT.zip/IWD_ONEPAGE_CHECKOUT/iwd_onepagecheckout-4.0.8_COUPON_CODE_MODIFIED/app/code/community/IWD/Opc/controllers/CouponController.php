<?php

class IWD_Opc_CouponController extends Mage_Core_Controller_Front_Action{
   
   const XML_PATH_DEFAULT_PAYMENT = 'opc/default/payment';
   
   /**
      * Retrieve shopping cart model object
      *
      * @return Mage_Checkout_Model_Cart
   */
   protected function _getCart(){
      return Mage::getSingleton('checkout/cart');
   }
   
   /**
      * Get checkout session model instance
      *
      * @return Mage_Checkout_Model_Session
   */
   protected function _getSession(){
      return Mage::getSingleton('checkout/session');
   }
   
   /**
      * Get current active quote instance
      *
      * @return Mage_Sales_Model_Quote
   */
   protected function _getQuote(){
      return $this->_getCart()->getQuote();
   }
   
   
   /**
      * Get payments method step html
      *
      * @return string
   */
   protected function _getPaymentMethodsHtml($use_method = false){
      
      /** UPDATE PAYMENT METHOD **/
      // check what method to use
      $apply_method = Mage::getStoreConfig(self::XML_PATH_DEFAULT_PAYMENT);
      if($use_method)
      $apply_method = $use_method;
      
      $_cart = $this->_getCart();
      $_quote = $_cart->getQuote();
      $_quote->getPayment()->setMethod($apply_method);
      $_quote->setTotalsCollectedFlag(false)->collectTotals();
      $_quote->save();
      
      $layout = $this->getLayout();
      $update = $layout->getUpdate();
      $update->load('checkout_onepage_paymentmethod');
      $layout->generateXml();
      $layout->generateBlocks();
      
      $output = $layout->getOutput();
      return $output;
   }
   
   public function couponPostAction(){
      
      $responseData = array();
      /**
         * No reason continue with empty shopping cart
      */
      if (!$this->_getCart()->getQuote()->getItemsCount()) {
         $this->_redirect('checkout/cart');
         return;
      }
      
      $couponCode = (string) $this->getRequest()->getParam('coupon_code');
      if ($this->getRequest()->getParam('remove') == 1) {
         $couponCode = '';
      }
      
      
      /* $customerEmail	=	$this->_getQuote()->getCustomerEmail(); */
      /* $customerEmail	=	$this->getBillingAddress()->getEmail(); */
      
      
      
      $customerEmail	=	$this->getRequest()->getParam('billing_email') ? $this->getRequest()->getParam('billing_email') : $this->_getQuote()->getCustomerEmail();
      
      
      
      
      
      $oldCouponCode = $this->_getQuote()->getCouponCode();
      
      if(empty($customerEmail)) {
         $responseData['message'] = $this->__('Please enter full address.');
         $responseData['pay_valid'] = '0';
         $responseData['emailError'] = '1';
         $this->getResponse()->setHeader('Content-type','application/json', true);
         $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($responseData));
         return;
      }
      
      
      if (!strlen($couponCode) && !strlen($oldCouponCode)) {
         $responseData['message'] = $this->__('Coupon code is not valid.');
         $responseData['pay_valid'] = '0';
         $this->getResponse()->setHeader('Content-type','application/json', true);
         $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($responseData));
         return;
      }
      
      /// get list of available methods before discount changes
      $methods_before = Mage::helper('opc')->getAvailablePaymentMethods();
      ///////
      
      try {
         $this->_getQuote()->getShippingAddress()->setCollectShippingRates(true);
         $this->_getQuote()->setCouponCode(strlen($couponCode) ? $couponCode : '')
         ->collectTotals()
         ->save();
         
         /// get list of available methods after discount changes
         $methods_after = Mage::helper('opc')->getAvailablePaymentMethods();
         ///////
         
         if ($couponCode) {
            
            /* THR */
            $resource = Mage::getSingleton('core/resource');
            $readConnection = $resource->getConnection('core_read');
            $query = "SELECT coupon_code FROM {$resource->getTableName('sales_flat_order')} WHERE coupon_code = '{$couponCode}' AND customer_email = '{$customerEmail}' AND status != 'canceled'";
            $results = $readConnection->fetchAll($query);
            
            if(count($results) > 0 ) {
               $this->_getQuote()->setCouponCode('')->collectTotals()->save();
               $responseData['message'] = $this->__('Coupon code already used by you.');
               $responseData['pay_valid'] = '0';
               $responseData['used']      = '1';
            }
            /* THR */
            
            else if ($couponCode == $this->_getQuote()->getCouponCode()) {
               $responseData['message'] = $this->__('Coupon code "%s" was applied.', Mage::helper('core')->htmlEscape($couponCode));
               /* THR */
               if(empty($oldCouponCode)) {
                  $responseData['pay_valid'] = '0';
                  } else {
                  $responseData['pay_valid'] = '1';
               }
               /* THR */
               }else {
               $responseData['message'] = $this->__('Coupon code "%s" is not valid.', Mage::helper('core')->htmlEscape($couponCode));
               $responseData['pay_valid'] = '0';
            }
            } else {
            $responseData['message'] =  $this->__('Coupon code was canceled.');
            $responseData['pay_valid'] = '0';
         }
         
         $layout= $this->getLayout();
         $block = $layout->createBlock('checkout/cart_coupon');
         $block->setTemplate('opc/onepage/coupon.phtml');
         $responseData['coupon'] = $block->toHtml();
         
         // check if need to reload payment methods
         $use_method = Mage::helper('opc')->checkUpdatedPaymentMethods($methods_before, $methods_after);
         if($use_method != -1)
         $responseData['payments'] = $this->_getPaymentMethodsHtml($use_method);
         /////
         
         } catch (Mage_Core_Exception $e) {
         $this->_getSession()->addError($e->getMessage());
         } catch (Exception $e) {
         $responseData['message'] =  $this->__('Cannot apply the coupon code.');
         Mage::logException($e);
      }
      
      
      $this->getResponse()->setHeader('Content-type','application/json', true);
      $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($responseData));
      
   }
}   